# CARS-1860 Research: Firefox Local Storage

Tested on Ben's PC (Windows 11, Firefox profile `u0mt223f.default-release`), 2026-10-23.
Firefox version: **158.0.1**.
Also checked against the AR2 `Computer:Firefox` evidence (Firefox 22 to 152).
Debrief with Vedant and Zubair: 2026-10-26.

Starting point: [CCL's Firefox Local Storage reader](https://github.com/cclgroupltd/ccl_mozilla_reader/blob/main/ccl_mozilla_reader/ccl_moz_localstorage.py) (linked from the ticket). CCL Group is a UK digital forensics company that publishes free browser-reading tools on GitHub.

---

## What the ticket is asking

Look into what useful info we can get from Firefox's Local Storage, since Firefox stores it differently from Chrome (so our Chrome code can't read it). Work out how it's stored, check whether it's worth adding, then build it on a separate ticket.

---

## Short answer

- **Worth having**, same kind of data as Chrome Local Storage (session IDs, account IDs, settings, ad tracking)
- **Two formats, both worth parsing:**
  - **New** (Firefox today): **one SQLite database per website** + a small binary file with the website's address and a "last used" time
  - **Old** (older Firefox): **one SQLite file for every website** (`webappsstore.sqlite`), plain text, no time. In 6 of the 7 Firefox profiles in the AR evidence
- **CCL's tool matches current Firefox**, but it reads one rare case wrong and doesn't read the old format (see "CCL check")
- Limits: **no timestamp per item**, and **deleted items are wiped** (you can only tell something was deleted)

---

## Where it's stored

```
Profiles\<profile>\storage\default\<website>\
    .metadata-v2        ← website address + "last used" time (binary, see below)
    ls\
        data.sqlite     ← the Local Storage items
    idb\                ← IndexedDB (different storage, we already support it)
```

- **Folder name** = website address with characters swapped: `https://www.minecraft.net` → `https+++www.minecraft.net`, `http://localhost:8000` → `http+++localhost+8000`
- Use `.metadata-v2` for the real address, not the folder name (CCL does the same)
- Some folders have a `^...` ending (containers, partitioned storage), see "Containers"
- Per Firefox source, `ls\` also has a small `usage` file (12 bytes: a check value + the total size). Not useful to examiners

---

## `data.sqlite`

Normal SQLite. Opens fine in SQLite Expert.

### `data` table (one row per saved item)

| Column | Meaning | Seen in tests |
|---|---|---|
| `key` | Name the website gave the item | `short_text`, `json_value` |
| `utf16_length` | Value length in characters, counted like JavaScript (emoji = 2) | `unicode_text` = 17 |
| `conversion_type` | How text is stored. **1** = UTF-8 (normal). **0** = raw UTF-16 (only for broken text). See "Conversion and compression types" | Always 1 except `broken_text` |
| `compression_type` | **0** = not compressed. **1** = Snappy compressed. See "Conversion and compression types" | 1 on long values |
| `last_access_time` | Meant to be a timestamp, but **Firefox never fills it in** | Always 0 |
| `value` | The saved data, as bytes ("blob") | |

### `database` table
One row of housekeeping (website address, total size, last vacuum time/size). Not useful to examiners.

### How Firefox writes it (from source)
- Saves changes **every few seconds in batches**, not straight away. Something saved and deleted in the same moment never reaches the file
- Deleting really removes the row (`DELETE FROM data`), no "deleted" flag
- Uses a rollback journal, **not WAL**, so there are no `-wal` files with older copies
- Tries to compress every value and only keeps the compressed version when it's worth it (`hello world` wasn't compressed, 10,000 × "a" was). Exact rule not checked

---

## Conversion and compression types (Firefox source)

Checked because the debrief asked: are there any types besides UTF-8 / UTF-16 and Snappy?

**Answer: no. Only two of each.**

| Column | Value | Name in Firefox | Means |
|---|---|---|---|
| `conversion_type` | 0 | `NONE` | Raw UTF-16 bytes, little-endian (broken text only) |
| `conversion_type` | 1 | `UTF16_UTF8` | UTF-8 (almost everything) |
| `compression_type` | 0 | `UNCOMPRESSED` | Not compressed |
| `compression_type` | 1 | `SNAPPY` | Snappy compressed |

- Defined in [LSValue.h#L38-L48](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/LSValue.h#L38-L48). Each list also has `NUM_TYPES = 2`, which is just a count, not a real type
- **Saving, text:** if the text is valid, save as UTF-8 (1). If not (e.g. half an emoji), save the raw UTF-16 bytes (0). [LSValue.cpp#L108-L118](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/LSValue.cpp#L108-L118)
- **Saving, compression:** always tries Snappy, keeps it (1) if Snappy gives a result, otherwise saves it uncompressed (0). [LSValue.cpp#L130-L138](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/LSValue.cpp#L130-L138)
- **Reading back:** Firefox assumes no other values exist (anything not 0 is treated as Snappy / UTF-8). [LSValue.cpp#L68-L88](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/LSValue.cpp#L68-L88)
- **For our parser:** handle all four. Any other number = corrupted row, log it and skip. If a new type ever turns up, add it then

---

## Test 1: normal values (test page)

`http://localhost:8000`, after "Write Records". Matched what Firefox showed in F12 → Storage.

| rowid | key | utf16_length | conversion | compression | Notes |
|---|---|---|---|---|---|
| 1 | `short_text` | 11 | 1 | 0 | Readable: `hello world` |
| 2 | `json_value` | 29 | 1 | 0 | `{"user":"testuser","id":1234}` |
| 3 | `unicode_text` | 17 | 1 | 0 | `héllo wörld 日本 😀`. 17 because 😀 counts as 2 |
| 4 | `long_repeated_text` | 10000 | 1 | **1** | **Compressed**, looks scrambled in SQLite Expert |
| 5 | `empty_value` | 0 | 1 | 0 | Empty |

- `to_be_deleted` (saved + deleted straight away): **no row and no gap**. Never reached the file (batched writes)
- `last_access_time` = 0 on every row

`short_text` raw bytes (type 1 = UTF-8, 1 byte per letter):
```
68 65 6c 6c 6f 20 77 6f 72 6c 64   = "hello world"
```

---

## Test 2: deletion

1. Saved `delete_me_later`, closed Firefox → row 6 in the file
2. Reopened Firefox, deleted it, closed Firefox

| | Before | After |
|---|---|---|
| Rows | 1-7 | 1-5, 7 |
| `delete_me_later` | rowid 6 | **gone, gap at 6** |

- **Gaps in row numbers = deleted items**
- Searched the whole `data.sqlite` for the deleted text (`I was deleted in a later session`): **not there**. Firefox wiped it, so deleted values can't be recovered from the file (in this test)

---

## Test 3: broken text (`conversion_type = 0`)

`broken_text` = `"abc\uD800def"` (`abc` + half an emoji on its own + `def`). Firefox can't store half an emoji as UTF-8, so it saves the raw UTF-16 instead.

- `conversion_type` = **0**, `utf16_length` = 7
- Raw bytes:
  ```
  61 00 62 00 63 00 00 d8 64 00 65 00 66 00
   a     b     c    (broken)  d     e     f
  ```
- 2 bytes per character, **letter first, then `00`** = **UTF-16 little-endian**
- **CCL reads this as big-endian** → would show `愀戀挀...` instead of `abc...def`. Our parser must use little-endian
- Rare in real data (needs broken text), but worth getting right

---

## Private windows

Saved the test items in a private window (Ctrl+Shift+P). They showed in F12 → Storage, but **nothing was written to disk**: no new website folder, `http+++localhost+8000` not changed, no `storage\private` folder. Private Local Storage is kept in memory only, so there's nothing for us to parse.

---

## Containers

Containers are a Firefox feature for separate "identities" in one browser (e.g. Personal and Work tabs, each with its own website data). On disk, each one gets its own website folder ending in `^userContextId=N`.

**Decision: leave them out.** The folder name is already in each row's source path, none of our other Firefox artifacts show containers, and Chrome Local Storage doesn't show its closest equivalent (profiles) either. Easy to add as a column later.

---

## `.metadata-v2`

Small binary file in each website folder. Not SQLite (that's why SQLite Expert won't open it and VS Code shows jumbled text). Numbers are **big-endian** (biggest byte first). Text = 4-byte length + the letters.

### Layout (from Firefox source) + Ben's `http+++localhost+8000` file

Raw (93 bytes):
```
00 06 5e 85 ad 27 b5 90 00 00 00 00 03 00 00 51 0d 00 00 00 00 00 00 00 09 6c 6f 63 61 6c 68 6f 73 74
00 00 00 15 68 74 74 70 3a 2f 2f 6c 6f 63 61 6c 68 6f 73 74 3a 38 30 30 30 00 ab cd 12 34 00 00 00 02
00 00 00 00 00 01 27 98 00 00 00 0d 43 36 35 35 33 36 20 4c 31 30 31 33 36
```

| Bytes | Field | Ben's file | Means |
|---|---|---|---|
| 8 | **Last used time** | `00 06 5e 85 ad 27 b5 90` | Microseconds since 1970 → **2026-10-23 17:54:48.986 UTC** (1:54 PM Eastern). Matches when Ben closed Firefox for the deletion test (file modified 13:54:54) |
| 1 | Persisted | `00` | Website asked Firefox to never auto-delete its storage? No |
| 4 | Flags | 3 | Internal |
| 4 | Last maintenance date | `00 00 51 0d` = 20749 | Days since 1970 → 2026-10-23 (Firefox housekeeping) |
| 4 + text | Old "suffix" | empty | Unused now. Holds Container / private info in the folder name's `^...` part |
| 4 + text | Old "group" | `localhost` | Unused now |
| 4 + text | **Website address** | `http://localhost:8000` | The real origin |
| 1 | Old "is private" | `00` | Unused now |
| 4 | Check value | `ab cd 12 34` | Always `0xABCD1234` |
| 4 | Version | 2 | |
| 8 | Total size of the website's storage | 75672 bytes | |
| 4 + text | Size per storage type | `C65536 L10136` | `L` = Local Storage: 10136 = total characters of all keys + values (checked: adds up exactly). `C` = another storage type (not checked) |

- All 93 bytes accounted for
- **This is the only timestamp we get.** It's when **the website's storage** (Local Storage, IndexedDB, cache...) was last used, not when each item was saved
- Like Safari, where we only have the file's modified time for the whole website

---

## Old format: `webappsstore.sqlite` (AR evidence)

```
C:\Users\<user>\AppData\Roaming\Mozilla\Firefox\Profiles\<profile>\webappsstore.sqlite
```

One SQLite file for **every website**, table `webappsstore2`. Plain SQLite, opens fine in SQLite Expert.

| Column | Meaning | Notes |
|---|---|---|
| `scope` | Website, backwards + scheme + port | Firefox 22-34. `moc.rettiwt.:https:443` = `https://twitter.com` |
| `originKey` | Same, newer name | Firefox 68. Use this if the table has it, otherwise `scope` |
| `key` | Name of the item | Read as is |
| `value` | The saved data | **Plain text**, never compressed |

- **No time** of any kind (not per item, not per website)
- Website reversed per Firefox source: [StorageDBUpdater.cpp#L26](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/storage/StorageDBUpdater.cpp#L26)
- Firefox 68 also has `-wal` / `-shm` files next to it (not checked for older copies of rows)
- **Current Firefox still creates the file but leaves it empty** (Ben's Firefox 158 profile: 0 rows)

### Example: Firefox 32 (`firefox.zip`)

```
D:\data\Computer\Firefox\evidence\firefox.zip\firefox\32.0\AppData - from User-AppData-Roaming\Mozilla\Firefox\Profiles\svj5jop4.default\webappsstore.sqlite
```

49 items across 16 websites, all plain text. Most are Twitter (14), LinkedIn (7) and YouTube (5).

| scope (website, backwards) | key | value |
|---|---|---|
| `moc.rettiwt.:https:443` | `__typeahead__:protocol` | `"https:"` |
| `moc.rettiwt.:https:443` | `__XHRNotes__:%2Fi%2Fusers%2Frecommendations` | `"f6ab5ac004c83336"` |
| `moc.rettiwt.:https:443` | `__typeahead_ttl__:userAdjacencyList` | `1410362592427` |

---

## AR data (`Computer:Firefox`)

Downloaded with `Scripts\download_data_baseline_from_S3.bat`. Evidence: `D:\data\Computer\Firefox\evidence` (9 zips).

| Zip | Firefox | Format | Items |
|---|---|---|---|
| `data from Jack.zip` | 22, 34 | Old | 5, 6 |
| `firefox.zip` | 29, 32, 68, Mac | Old | 69, 49, 9, 3 |
| `Firefox_IndexedDb_152.zip` | 152 | New | 120 across 10 websites |

Firefox 152 (new format):
- 29 of 120 values compressed
- All `conversion_type = 1`, all `last_access_time = 0`
- Every website folder has a `.metadata-v2`
- Several `^partitionKey=...` folders (storage a website saved while shown inside another website)

**Old format is in 6 of the 7 profiles**, so it's worth parsing too.

---

## CCL check

Compared `ccl_moz_localstorage.py` (v0.2.0) with current Firefox source. Per the debrief, CCL is the **benchmark** to compare our output against, not something to build from.

| | CCL | Firefox | OK? |
|---|---|---|---|
| Files | `<website>\ls\data.sqlite` + `.metadata-v2` | Same | ✅ |
| Table / columns | `data`: key, utf16_length, conversion_type, compression_type, last_access_time, value | Same (database version 5.0) | ✅ |
| Compression 0 / 1 | None / Snappy | Same (only these two exist) | ✅ |
| Conversion 1 | UTF-8 | UTF-8 | ✅ |
| Conversion 0 | **UTF-16 big-endian** | Raw UTF-16 = **little-endian** on PCs (Test 3) | ❌ |
| Website address | From `.metadata-v2` | Same | ✅ |
| `value` property | **Returns the key, not the value** (bug) | | ❌ |
| Old format (`webappsstore.sqlite`) | Not read | In 6 of 7 AR profiles | ❌ |
| `last_access_time` | Read but not used | Never filled in | ✅ (nothing to use) |

---

## Is it useful?

**Yes, worth having like Chrome Local Storage.**
- Same kind of data as Chrome: session IDs, account/user IDs, where the user came from, ad tracking IDs, app settings
- Firefox is a common browser, and we already support it for history, cookies, IndexedDB etc.
- Simple to read: normal SQLite + Snappy (we already have Snappy code) + a small binary file. Old format is plain SQLite

Limits for examiners:
- No time per item, only "website storage last used"
- Deleted items can't be recovered, only spotted as gaps
- Values are whatever the website saved (often JSON or IDs), so how useful it is depends on the website

### Chrome vs Firefox: what we can parse

Chrome columns from `Magnet.Artifacts/Chrome/ChromeLocalStorage.cs` (descriptions from `art_jsons/Computer/Chrome.json`). Chrome stores Local Storage in LevelDB (a log of changes), which is where its extra columns come from. Firefox stores it in plain SQLite, so it doesn't have them.

| Chrome column | What it means in Chrome | Firefox | Will try to parse? |
|---|---|---|---|
| Key | Name of the item | ✅ `data.key` | ✅ |
| Value | The saved data | ✅ `data.value` (decompress if `compression_type = 1`, decode by `conversion_type`) | ✅ |
| Domain | Website the item belongs to | ✅ Website address from `.metadata-v2` (folder name as backup) | ✅ |
| Batch Timestamp - UTC | When the item was written (to within 5-60+ s) | ❌ No time per item (`last_access_time` always 0) | ❌ |
| Batch Access Timestamp - UTC | When the item was last read (approx.) | ⚠️ Only "website storage last used" from `.metadata-v2`, for the whole website, not per item | ✅ As its own column, e.g. "Origin Last Accessed" (name not decided) |
| State | Live / Deleted / Unknown. Chrome keeps deleted items in its log | ❌ Only live items. Deleted ones are wiped (only a gap in row numbers) | ❌ Everything is Live |
| Sequence Number | Order of changes in Chrome's log | ❌ No equivalent. `rowid` is close-ish (order saved?), not tested | ❌ Probably not |
| *(not in Chrome)* | | Container ID (`^userContextId=N` in the folder name) | ❌ Not in first version, shows in the source path (see "Containers") |

So Firefox gets **Key, Value, Website address + one "website last used" time** (old format: no time). Same as what Safari Local Storage shows (`SafariLocalStorage.cs`: Key, Value, Origin, file modified time).

---

## Not tested yet

- **When Firefox switched** from the old to the new format (around version 92? not confirmed)
- **Android Firefox**: same storage engine, maybe just a different path
- Linux / macOS paths (should be the same layout under the profile)
- `C` in `.metadata-v2` size list
- `conversion_type = 0` in real (not made-up) data (all 120 AR values were 1)
- Repo Snappy code on this data (only checked with a throwaway Python script: `long_repeated_text` + 3 real-site values decompressed correctly)

---

## Sources

| Source | Link | Used for |
|---|---|---|
Firefox links pinned to commit `8a7f5001d25b58d4799e19bfed316f872dcc739c`, CCL links to `b3d0627f747a718e1e30ac02b92e82bdde354eb2` (2026-10-26).

| Source | Link | Used for |
|---|---|---|
| CCL Group, `ccl_moz_localstorage.py` (MIT) | [ccl_moz_localstorage.py](https://github.com/cclgroupltd/ccl_mozilla_reader/blob/b3d0627f747a718e1e30ac02b92e82bdde354eb2/ccl_mozilla_reader/ccl_moz_localstorage.py) | The tool the ticket links |
| CCL Group, `storage_common.py` | [#L55-L76](https://github.com/cclgroupltd/ccl_mozilla_reader/blob/b3d0627f747a718e1e30ac02b92e82bdde354eb2/ccl_mozilla_reader/storage_common.py#L55-L76) | CCL's `.metadata-v2` reader |
| Firefox, `dom/localstorage/ActorsParent.cpp` | [#L356](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/ActorsParent.cpp#L356) | `data` table layout |
| Firefox, `dom/localstorage/LSValue.h` | [#L38-L48](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/LSValue.h#L38-L48) | All conversion / compression types |
| Firefox, `dom/localstorage/LSValue.cpp` | [#L108-L138](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/LSValue.cpp#L108-L138) (saving), [#L68-L88](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/localstorage/LSValue.cpp#L68-L88) (reading) | When each type is used |
| Firefox, `dom/quota/DirectoryMetadata.cpp` (`WriteDirectoryMetadataHeader`) | [#L55-L73](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/quota/DirectoryMetadata.cpp#L55-L73) | `.metadata-v2` first fields (last used time at [#L60](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/quota/DirectoryMetadata.cpp#L60)) |
| Firefox, `dom/quota/ActorsParent.cpp` (`CreateDirectoryMetadata2`) | [#L3831-L3882](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/quota/ActorsParent.cpp#L3831-L3882) | `.metadata-v2` layout, website address |
| Firefox, `xpcom/io/nsBinaryStream.cpp` | [#L212-L222](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/xpcom/io/nsBinaryStream.cpp#L212-L222) (text), [#L186](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/xpcom/io/nsBinaryStream.cpp#L186) (big-endian) | How `.metadata-v2` writes text and numbers |
| Firefox, `dom/storage/StorageDBUpdater.cpp` | [#L26](https://github.com/mozilla-firefox/firefox/blob/8a7f5001d25b58d4799e19bfed316f872dcc739c/dom/storage/StorageDBUpdater.cpp#L26) | Old format, website backwards |
| Mozilla docs, PRTime | [prtime.html](https://firefox-source-docs.mozilla.org/nspr/reference/prtime.html) | Time = microseconds since 1970 UTC |
| Repo: `Magnet.Artifacts/Safari/SafariLocalStorage.md` | | Example format doc |
| Ben's tests | `D:\code\ff-localstorage-test\make_test_localstorage.html` | Tests 1-3, `.metadata-v2` |
| AR2 evidence | `D:\data\Computer\Firefox\evidence` | Old format, Firefox 152 new format |

---

## Next steps: implementation

### What we'll parse

For each website folder in `storage\default\`, one row per item:

| Column | From | How |
|---|---|---|
| Key | `ls\data.sqlite`, `data.key` | Read as is |
| Value | `ls\data.sqlite`, `data.value` | Decompress if `compression_type = 1` (Snappy), then read as UTF-8 if `conversion_type = 1`, or UTF-16 little-endian if `0`. Any other type = corrupted row, log + skip |
| Origin (website address) | `.metadata-v2` | Read the address text. Use the folder name if the file is missing or broken |
| Origin last accessed - UTC (name TBD) | `.metadata-v2` | First 8 bytes: microseconds since 1970 → UTC time. Same time on every row for that website |

The other columns and files (`utf16_length`, `last_access_time`, the `database` table, the `usage` file) aren't needed.

Old format (`webappsstore.sqlite`), same artifact:

| Column | From | How |
|---|---|---|
| Key | `webappsstore2.key` | Read as is |
| Value | `webappsstore2.value` | Read as is (plain text) |
| Origin | `webappsstore2.originKey`, else `scope` | Flip it: `moc.rettiwt.:https:443` → `https://twitter.com` |
| Origin last accessed | *(none)* | Empty |

### Where the code goes

| Piece | Goes in | Reference |
|---|---|---|
| **Parser**: reads `ls\data.sqlite` + `.metadata-v2`, decodes the values | `pkg-magnet-fileformats`, `Magnet.FileFormats/FireFox/LocalStorage/` (new) | Vedant's Firefox Cache2 PR ([85876](https://dev.azure.com/gauss-dev/Magnet/_git/pkg-magnet-fileformats/pullrequest/85876)), Chrome's `Chromium/LocalStorage/LocalStorageParser.cs`, `FireFox/Serialization/FirefoxSnappyHelper.cs` for compressed values |
| **`.metadata-v2` parser**: its own separate piece, not inside the Local Storage parser | `pkg-magnet-fileformats`, `Magnet.FileFormats/FireFox/` | Same file is in every website folder, so IndexedDB (`idb\`) etc. can reuse it (debrief) |
| **Hunter + artifact**: finds the files, turns results into rows | `lib-magnet-artifacts`, `Magnet.Artifacts/Firefox/` | `FirefoxIndexedDbStorageHunter.cs` (same folders), `Safari/SafariLocalStorage.cs` (same columns) |
| **Old-format hunter**: reads `webappsstore.sqlite`, flips the website | `lib-magnet-artifacts`, same artifact | Other Firefox SQLite hunters in `Magnet.Artifacts/Firefox/` |

- **CCL link:** benchmark to compare our output against, not copied. It's Python and has 2 bugs; Firefox's source code is what we trust
- **Open question:** repo rules say new SQLite artifacts should use the SQLite Intelligent Hunter, but values need decoding and the address is in a separate binary file, so a FileFormats parser (like Chrome) fits better. Confirm before starting
