# Firefox Local Storage: master notes

Everything on Firefox Local Storage in one file. Written to be the only file you need to read when
picking this up in a new chat, in either repo.

**Replaces these** (all in `zzzBensStuff/`, safe to delete once you trust this file):

| Old file | What it held |
|---|---|
| `CARS-1860.md` | Research ticket notes, history, test page, AR data |
| `CARS-1860-research-simplified.md` | Debrief version of the research |
| `CARS-1860-research-depth.md` | Byte layouts, raw test output, CCL check table |
| `CARS-2225.md` | FileFormats parser ticket, PR review round 1 |
| `CARS-2252.md` | Lib ticket, package notes, PR review round 2 |
| `FirefoxLocalStorage.md` | Format reference, **now stale** (see note below) |

> `FirefoxLocalStorage.md` was copied into the FileFormats repo as
> `Magnet.FileFormats/FireFox/LocalStorage/README.md`. The repo copy has since been edited several
> times. **The repo copy is the live one.** The `zzzBensStuff` copy is a snapshot from 2026-10-26.

Last updated 2026-11-05.

---

## Debrief notes (CARS-2252, screen share)

**Order:** ticket → the two formats → code → testing → side notes

**1. Ticket**
- Last of 3 tickets for Firefox Local Storage: CARS-1860 research → CARS-2225 FileFormats parser → **CARS-2252 hunters + artifact (this one)**
- Goal: take the FileFormats parser and turn its output into an artifact, plus read the old format
- Local Storage = small key/value items websites save in the browser (`localStorage`)

**2. The two formats** (show [FirefoxLocalStorage.md](../Magnet.Artifacts/Firefox/FirefoxLocalStorage.md))
- **New** (current Firefox): one folder per website, `storage\default\https+++twitter.com\`
  - `ls\data.sqlite` = the items
  - `.metadata-v2` = the real website address + a last accessed time
  - Read by the FileFormats parser (CARS-2225)
- **Old** (Firefox 22 to 68): one `webappsstore.sqlite` for every website, plain text, no time
  - Website stored backwards: `moc.rettiwt.:https:443` = `https://twitter.com`
  - Plain SQLite, so read in lib, no parser needed (Vedant's call)
- Two formats → **two hunters, one artifact**

**3. Code** (in the PR's file order, formalities quick)
- `art_jsons/Computer/Firefox.json` (line 145): show the 4 columns and their descriptions. Mac copy is the same
- `Directory.Packages.props`: FileFormats is still on the PR build `7.8.2-PullRequest108255.11`. Swap to the release once !108255 merges
- Skip: `ArtifactDescriptors.cs`, `ArtifactStrings.resx`, both `ArtifactStrings.Designer.cs` (formalities, see "If asked" below)
- `FirefoxLocalStorage.cs` (the artifact)
  - Lines 31-37: our columns: Key, Value, Origin, Last Accessed
  - Lines 39-50: capabilities: display order + Super Timeline (Browser Usage)
  - Lines 52-56: two hunters. First = new format, second = old format
- `FirefoxLocalStorageOriginDirectoryHunter.cs` (new format)
  - Line 32 + 43-44: CFLs, where it's usually found (`storage/default/**/ls/data.sqlite`)
  - Line 41: registers with our regex → **show `FirefoxLocalStorageOriginDirectoryRegex.cs`** line 10: matches `storage\default\<one website folder>\ls\data.sqlite`
  - Back to the hunter, lines 52-53: the engine gives us `data.sqlite`. Go up 2 levels (`ls` → website folder), e.g. `...\storage\default\https+++twitter.com`
  - Lines 55-59: **this is where we call FileFormats.** Wrap the website folder, ask DI for `IFirefoxLocalStorageParser`, `.Parse(folder)`. It reads `data.sqlite` + `.metadata-v2` and hands back the entries + the metadata
  - Lines 68-79 (loosely): Origin + Last Accessed come from `.metadata-v2`, built once, shared by every item on that site. File missing → left empty
  - Lines 81-93: the `foreach` turns each entry into a hit: Key + Value from the entry, plus the shared Origin + time. Value that couldn't be decoded → empty, but the row is kept
- `FirefoxLocalStorageWebappsStoreHunter.cs` (old format)
  - Line 26: a `SqliteIntelligentHunter`, the standard SQLite base
  - Line 48: registers on the file name `webappsstore.sqlite`
  - Lines 61-74: maps database columns to ours. Two table layouts: older Firefox has the website in `scope`, Firefox 68 in `originKey`. The base class picks the right one from the table's columns
  - Lines 77-105: each row becomes a hit
  - Line 91: website is backwards → calls the helper → **show `FirefoxWebappsStoreOriginHelper.cs`**
    - Line 41: split on `:` → `moc.rettiwt.` / `https` / `443`
    - Line 47 (`ReverseHost`): flip the letters, drop the dot → `twitter.com`
    - Lines 62-64 (`ShouldShowPort`): drop default ports (443, 80) → `https://twitter.com`, same as the new format writes it
    - Lines 56-58: Firefox's own pages have no port: `emoh.:about` → `about:home`
    - Not the right shape → null
  - Back to the hunter, lines 92-99: null → no Origin, the row still comes through. No time in this format, so Last Accessed stays empty

**4. Testing**
- **Local AR2 `Computer:Firefox`** (`Output_20261105_160311`, with the scenario's options file)
  - 13,645 hits vs baseline 13,379 → **266 new, all Firefox Local Storage, 0 missing**. Schema change: "New artifact: Firefox Local Storage". Nothing else changed

  | Evidence | Hits | Format |
  |---|---|---|
  | `Firefox_IndexedDb_152.zip` | 120 (10 websites) | New. Same 120 as the FileFormats Runner and CCL |
  | `firefox.zip` | 132 | Old |
  | `data from Jack.zip` | 14 | Old. 11 live rows + 3 recovered deleted copies (see side notes) |

  - **Empty Last Accessed on all 146 old-format hits**: expected, that format has no time
  - **Empty Value on 2 hits** (allrecipes.com, `PublicProfileStateModel` + `CurrentUserStateModel`, Firefox 29): opened the database, both really are empty text. Not a bug
  - Every new-format hit has all 4 columns
- Solution builds, Firefox unit tests + blackbox tests pass
- Not run: `macOS:Firefox` (downloaded, not run yet)

**5. Side notes / questions**
- **Old format can recover deleted items.** `SqliteIntelligentHunter` recovers old copies from free space in the database. Jack's Firefox 22 file has 5 live rows but gave 8 hits (rowids 8-10 are older copies of `geoLastUpdated`, `snippets`, `snippets-last-update`). The research said "neither keeps deleted items", which was only tested on the new format
- **"Last Accessed" isn't user activity.** It's the last time Firefox opened or let go of the site's storage, and it covers the whole site (IndexedDB, Cache too), not just Local Storage. See section 6. Column name could be clearer
- First AR2 run without the options file → 2 Firefox Logins rows came back `<Encrypted Data>` (master-password profile in `76.0.zip`). Not our change. Fixed by adding `OptionsFilePath`
- Local AR setup: had to copy the new `Magnet.FileFormats.dll` into the AR tool's `bin`, and set AR2's `ArtifactsVersion` to `14.5.*` after merging fury (local only, not committed)
- Still open from FileFormats review: Veronica's rowid question (section 9)

**If asked**
- **`ArtifactStrings.resx`**: holds the display text "Firefox Local Storage" under the name `Artifact_Firefox_Local_Storage`
- **`ArtifactStrings.Designer.cs` (Properties)**: hand-added code property so C# can use that string. Step 2 of the repo's 3-step string rule
- **`ArtifactStrings.Designer.cs` (project root)**: the same, regenerated by TextTransform. Step 3 of the rule
- **`ArtifactDescriptors.cs`**: one line, the artifact's ID (`4ed65d9f…`), its name string and `Priority.Primary`
- **Tests** (not shown in the debrief):
  - `Magnet.Artifacts.Tests/Artifacts/Firefox/FirefoxWebappsStoreOriginHelperTests.cs`: website conversion. Works: twitter, bbc.co.uk, localhost:8000, about:home, odd ports. Returns null: empty, no scheme, no host, extra fields
  - `Magnet.Artifacts.Tests/Artifacts/Firefox/FirefoxLocalStorageOriginDirectoryHunterRegistrationTests.cs`: the path regex. Matches Windows + Mac paths. Skips `idb\`, `-wal`, folders nested too deep

---

## 1. Where this stands

Three tickets, one feature.

| Ticket | What | Repo | Status |
|---|---|---|---|
| **CARS-1860** | Research spike | none | ✅ Done, debriefed 2026-10-26 |
| **CARS-2225** | Local Storage parser | `pkg-magnet-fileformats` | ✅ Approved, all review comments resolved 2026-11-05. Not merged yet |
| **CARS-2252** | Hunters + artifact | `lib-magnet-artifacts` | ⏳ **This is what's left** |

PR for CARS-2225: [!108255](https://dev.azure.com/gauss-dev/Magnet/_git/pkg-magnet-fileformats/pullrequest/108255),
branch `CARS-2225` → `fury`.

---

## 2. What's left to do (CARS-2252)

**AC:**
- [ ] New-format hunter (calls the FileFormats parser)
- [ ] Old-format hunter (`webappsstore.sqlite`, read entirely in lib)
- [ ] One artifact covering both
- [ ] art-json, strings, AR baselines
- [ ] Update FileFormats `docs/ARTIFACTS_TESTING_LOG.md`

**Do it in this order:**

1. **Old-format hunter first.** `webappsstore.sqlite` is plain SQLite read entirely in lib. No parser,
   no package, nothing to wait on, and immune to anything that happens to !108255.
2. **New-format hunter second.** It can't compile without the package reference, since it needs
   `IFirefoxLocalStorageParser`. So "write it then test" doesn't apply to this half.
3. **`ARTIFACTS_TESTING_LOG.md` last.** That file lives in `pkg-magnet-fileformats`, not lib. There's an
   `artifacts-testing-log` skill in that repo that regenerates it by scanning a lib checkout, so it needs
   the hunters to exist first.

**Before you start the new-format hunter, do this grep.** Two public API members changed on 2026-11-05
and anything in lib touching them will break on adoption:

```bash
grep -rn "IsValueDecoded\|RawValue\|IFirefoxOriginMetadataV2Parser" --include=*.cs .
```

---

## 3. The API FileFormats gives you

**Current as of 2026-11-05.** This is the authoritative version; older notes in the replaced files are wrong.

```
IFirefoxLocalStorageParser.Parse(ISourceDirectory originDirectory)
  → pass ONE website folder, e.g. storage\default\http+++localhost+8000
  → returns IFirefoxLocalStorageResultSet

IFirefoxLocalStorageResultSet
  Metadata : IFirefoxOriginMetadataV2                          // NULL if .metadata-v2 missing or shorter than its header
  Entries  : IReadOnlyCollection<IFirefoxLocalStorageEntry>    // empty, never null

IFirefoxLocalStorageEntry : ISourceResult
  Key             : string
  Value           : string      // NULL means it would not decode
  OriginalValue   : byte[]      // the value column exactly as stored, still compressed if CompressionType says so
  CompressionType : long
  ConversionType  : long
  Source, Offset                // data.sqlite path + row offset

IFirefoxOriginMetadataV2 : ISourceResult
  Origin              : string           // NULL if the file was truncated before it could be read
  LastAccessTime      : DateTimeOffset?
  LastMaintenanceDate : DateTimeOffset?
  Persisted           : bool
  Flags               : uint
  Source, Offset                         // .metadata-v2 path, offset 0
```

Resolve `IFirefoxLocalStorageParser` from DI via `AddFileFormatsServices()`. Don't `new` it.

### API changes you need to know about

| Date | Change | Impact on lib |
|---|---|---|
| 2026-11-05 | **`IsValueDecoded` removed** | Was redundant: the decoder sets the text to null on every failure path, so `Value is null` already means "didn't decode". Replace any `!entry.IsValueDecoded` with `entry.Value is null` |
| 2026-11-05 | **`RawValue` renamed to `OriginalValue`** | Rename only, same bytes, same meaning |
| 2026-11-05 | **`IFirefoxOriginMetadataV2Parser` is now `internal`** | You can no longer resolve it from lib. Nothing in lib needed it; metadata arrives on the result set. If you genuinely need to parse a `.metadata-v2` directly, it has to go public again |
| 2026-11-05 | **Truncated `.metadata-v2` now returns partial metadata** | Previously returned null and you lost both timestamps. Now returns the timestamps with `Origin = null`. So `Metadata != null` no longer guarantees `Origin != null` |
| 2026-11-04 | `IsPrivate`, `Suffix`, `Group` removed from the metadata interface | Firefox no longer fills them in. Read and discarded |
| 2026-11-04 | Snappy decoding is single-block only | Firefox only writes single-block Snappy for Local Storage, so real values are unaffected. A framed-layout value now comes back with a null `Value` and bytes on `OriginalValue` |

### Columns map to

| Artifact column | Source |
|---|---|
| Key | `Entry.Key` |
| Value | `Entry.Value` |
| Origin | `Metadata.Origin` |
| Origin Last Accessed - UTC | `Metadata.LastAccessTime` (new format only) |

### Hunter gotchas

- `Metadata` can be null → still emit the entries, just blank Origin and no timestamp.
- `Metadata.Origin` can be null even when `Metadata` isn't (truncated file). The folder name is named
  after the site, so you can fall back to it if you want, but the parser deliberately does not.
- `LastAccessTime` and `LastMaintenanceDate` are both `DateTimeOffset?`. Either can be null.
- `Entry.Value` null → the bytes are on `OriginalValue`.
- `Parse()` handles **one** website folder per call. Enumerate `storage\default` yourself.
- Old format has no last-accessed time at all. That column is new-format only.
- `Entry.Key` can be null in theory (if the `key` column isn't text). The entry is still returned.

### How the hunter calls it

```csharp
var result = parser.Parse(originDirectory);          // one website folder
foreach (var entry in result.Entries)
    → row: entry.Key, entry.Value, result.Metadata?.Origin, result.Metadata?.LastAccessTime
// entry.Value is null → value couldn't be decoded; stored bytes are on entry.OriginalValue
```

---

## 4. The package

```
Magnet.FileFormats  <newest PullRequest108255.*>
```

- Feed: `Magnet/Engineering` (Azure Artifacts, **not** JFrog — ignore the Artifactory tab, the pipeline
  has zero JFrog tasks; "Build Info is not published to Artifactory" is just an empty extension state).
- PR builds publish packages automatically. Nothing to request from Vedant.
- `7.8.1-PullRequest108255.1` is from the 2026-11-02 build and is **far out of date** — it predates every
  API change in the table above. Grab the newest `PullRequest108255.*` off the feed.
- Says 7.8 not 7.7 because `fury` picked up !108459 (CARS-2243) which bumped `AssemblyVersion`. ADO PR
  builds compile the *merge* of the branch into current `fury`.
- Point lib's `Directory.Packages.props` (`Magnet.FileFormats` line) at it.
- **Don't merge lib pinned to a `PullRequest108255` prerelease.** Once !108255 lands on `fury` there'll be
  a clean `7.8.x`. Swap to that before the lib PR goes in.

---

## 5. Format reference

### What it is

Websites save small key/value items in the browser (HTML5 `localStorage`). Firefox has used two formats:

| Format | Firefox | Storage |
|---|---|---|
| **New** | Current | One SQLite database **per website** + a binary `.metadata-v2` holding the website address and a last-used time |
| **Old** | Seen 22 to 68 | One SQLite database for **every website** (`webappsstore.sqlite`), plain text |

Neither format has a per-item time, and neither keeps deleted items: deleting removes the row and the
value is not left behind. Private window Local Storage is never written to disk.

### Locations

Let `$PROFILE = C:\Users\<user>\AppData\Roaming\Mozilla\Firefox\Profiles\<profile>`.

| File | Path |
|---|---|
| New format, items | `$PROFILE\storage\default\<website>\ls\data.sqlite` |
| New format, website info | `$PROFILE\storage\default\<website>\.metadata-v2` |
| Old format | `$PROFILE\webappsstore.sqlite` |

- The `<website>` folder name is the address with characters swapped (`https://www.minecraft.net` →
  `https+++www.minecraft.net`, `http://localhost:8000` → `http+++localhost+8000`). `.metadata-v2` holds
  the real address, so the folder name is a lossy fallback only.
- Some folders end in `^userContextId=N` (containers, e.g. Work/Personal tabs) or `^partitionKey=...`
  (storage a site saved while embedded in another site).
- The same `.metadata-v2` is in every website folder, so it also describes that site's IndexedDB (`idb\`).
- Current Firefox still creates `webappsstore.sqlite` and `storage\ls-archive.sqlite` but leaves them
  empty. `ls-archive.sqlite` isn't in the AR evidence at all.

### New format: `ls\data.sqlite`

Standard SQLite, rollback journal (**no WAL**, so no `-wal` file exists — opened with
`JournalType.None` deliberately). One row per item in the `data` table (`CreateDataTable` in
`dom/localstorage/ActorsParent.cpp`):

| Column | Meaning | Needed? |
|---|---|---|
| `key` | Item name, plain text | ✅ |
| `utf16_length` | Value length in UTF-16 code units | ❌ |
| `conversion_type` | How the value bytes are encoded | ✅ to decode |
| `compression_type` | Whether the value is compressed | ✅ to decode |
| `last_access_time` | Never filled in by Firefox, always 0 | ❌ |
| `value` | The item value, as a blob | ✅ |

The `database` table is housekeeping only.

**Decoding `value`:** decompress first, then turn bytes into text. Only these values exist
(`LSValue::CompressionType` / `LSValue::ConversionType` in `dom/localstorage/LSValue.h`):

| Column | Value | Meaning |
|---|---|---|
| `compression_type` | 0 | Not compressed |
| `compression_type` | 1 | Raw Snappy, single block, no framing |
| `conversion_type` | 1 | UTF-8. Almost every value |
| `conversion_type` | 0 | Raw UTF-16 **little-endian**. Only when the text isn't valid UTF-16 |

- Firefox tries Snappy on every value and keeps the compressed bytes only when Snappy returns a result,
  so in practice only longer values are compressed.
- `conversion_type = 0` happens when the text can't be converted to UTF-8, e.g. half an emoji on its own.
  **Never seen in real data** (all real-site and all 120 AR values were type 1). Only reproducible with
  the test page. This is where CCL has a bug.
- Example: `"abc\uD800def"` stores as type 0, bytes `61 00 62 00 63 00 00 d8 64 00 65 00 66 00`.

### New format: `.metadata-v2`

Binary. Numbers **big-endian**. Text is a 4-byte big-endian length followed by that many bytes
(`nsBinaryInputStream::ReadCString`). Layout from `ReadDirectoryMetadataHeader`
(`dom/quota/DirectoryMetadata.cpp`) and `CreateDirectoryMetadata2` (`dom/quota/ActorsParent.cpp`).

```
offset   size   field
------   ----   -----
+0       8      last_access_time       (int64, microseconds since 1970 UTC)   ← needed
+8       1      persisted              (bool)
+9       4      flags                  (uint32)
+13      4      last_maintenance_date  (int32, days since 1970)
+17      4+N    suffix                 (text, unused, usually empty)
         4+M    group                  (text, unused)
         4+L    origin                 (text, the website address)            ← needed
         1      is_private             (bool, unused)
         4      check value            (always 0xABCD1234)
         4      version
         8      total storage size of the website
         4+K    size per storage type  (text, e.g. "C65536 L10136")
```

The text fields vary in length, so you must read them in order to reach `origin`.

Everything from the check value onward is **optional** (only newer files have it, Firefox treats it as
optional) and unused, so the parser stops after `is_private`.

**Real example**, `http+++localhost+8000\.metadata-v2`, 93 bytes:

```
00 06 5e 85 ad 27 b5 90                  last_access_time = 2026-10-23 17:54:48.986 UTC
00                                       persisted = false
00 00 00 03                              flags = 3
00 00 51 0d                              last_maintenance_date = 20749 (2026-10-23)
00 00 00 00                              suffix = ""
00 00 00 09  "localhost"                 group
00 00 00 15  "http://localhost:8000"     origin
00 · ab cd 12 34 · 00 00 00 02 · 00 00 00 00 00 01 27 98 · 00 00 00 0d "C65536 L10136"
```

Reader position through those 93 bytes: header → 17, suffix `""` → 21, group `"localhost"` → 34,
origin `"http://localhost:8000"` → 59, is-private → 60, stop. Last 33 bytes unread.

### Old format: `webappsstore.sqlite`

Standard SQLite, table `webappsstore2`, one row per item for every website:

| Column | Meaning |
|---|---|
| `scope` (FF 22-34) / `originKey` (FF 68) | Website, reversed + scheme + port. Use `originKey` if present, else `scope` |
| `key` | Item name, plain text |
| `value` | Item value, plain text, never compressed |

The website is stored backwards (`StorageDBUpdater.cpp`): `moc.rettiwt.:https:443` =
`https://twitter.com`. There is no time in this format.

Firefox 68 also has `-wal`/`-shm` files next to `webappsstore.sqlite`.

---

## 6. What `LastAccessTime` actually means

Researched 2026-11-05 from Firefox source, because Veronica asked and the answer wasn't documented
anywhere. **This is the single most misread field in the artifact.**

Firefox's own words, from the pref that controls it
(`dom.quotaManager.temporaryStorage.updateOriginAccessTime`, default on, in `StaticPrefList.yaml`):

> the access time is updated only when an origin is accessed by a quota client for the first time during
> a session or when the last quota client stops accessing the origin. This allows eviction based on the
> LRU policy.

So it is written at exactly two moments:

1. the first time anything touches that site's storage in a browser session
2. when the last thing using that site's storage lets go of it

Code path: `QuotaManager::OpenClientDirectory` sets up a "first access" save and
`ClientDirectoryLockHandleDestroy` fires the "last access" save when the final lock on that origin is
released. The write itself is `SaveOriginAccessTimeOp::DoDirectoryWork` in
`dom/quota/OriginOperations.cpp`, which rewrites the whole `.metadata-v2` and sets the `accessed` bit in
`Flags`. Only non-persistent (i.e. `storage/default`) origins — persistent ones get the timestamp once
at directory creation and never again.

**What this means forensically:**

- **It is not user activity.** The trigger is "a quota client opened or closed this origin's storage".
  A quota client is Local Storage, IndexedDB, the Cache API. Any page load touches it, including a
  background tab or a service worker. No user gesture anywhere in the path.
- **It is not a modification time.** A page that only *reads* its Local Storage moves it. A page that
  writes nothing still moves it.
- **It is not Local Storage specific.** It covers the whole site's storage, so IndexedDB or cache
  activity moves it even if Local Storage was never touched.
- **It doesn't move on every visit.** Ten visits in one browser session produce one first-touch write
  and one final-release write, nothing in between.
- **Relationship to the real last write is loose both ways.** Usually it lands *after* the last write,
  because the closing write happens when storage is released. Site open all day, write at 9am, browser
  closed at 6pm → timestamp says 6pm. If Firefox was killed before the closing write, the timestamp can
  sit *earlier* than the last modification.

Closest honest description: **"the last time the browser opened or let go of this site's storage."**

`LastMaintenanceDate` is Firefox's own housekeeping, never a user action, day precision.

**Worth raising on the lib side:** the field is called `LastAccessTime` and the column is "Origin Last
Accessed - UTC". Both invite the reading the docs carefully avoid. Something like "Site Storage Last
Accessed" would carry the right meaning without needing a footnote. That's a lib naming decision.

---

## 7. Where the code lives (FileFormats, CARS-2225)

```
Magnet.FileFormats/
  Api/
    Parsers/IFirefoxLocalStorageParser.cs          public  ← the only thing lib calls
    Models/FireFox/IFirefoxLocalStorageEntry.cs    public
    Models/FireFox/IFirefoxLocalStorageResultSet.cs public
    Models/FireFox/IFirefoxOriginMetadataV2.cs     public
  FireFox/Quota/
    IFirefoxOriginMetadataV2Parser.cs              internal (moved here 2026-11-05)
    FirefoxOriginMetadataV2Parser.cs               internal
    FirefoxOriginMetadataV2.cs                     internal record
  FireFox/LocalStorage/
    FirefoxLocalStorageParser.cs                   internal
    FirefoxLocalStorageEntry.cs                    internal record
    FirefoxLocalStorageResultSet.cs                internal record
    LSValueDecoder.cs                              internal static
    LSValueCompressionType.cs / LSValueConversionType.cs
    README.md                                      ← the live format doc
  Common/Extensions/FileFormatsServiceExtensions.cs  DI registration
Magnet.FileFormats.Tests/FireFox/{Quota,LocalStorage}/
FileFormatsRunner/Runners/FirefoxLocalStorageRunner.cs   testing tool only, not production
```

**Why `FireFox/Quota/`:** `.metadata-v2` is written by Firefox's quota manager (`dom/quota`) and is
shared by every storage type (`ls\`, `idb\`, `cache\`), not Local Storage only. Follows the upstream
module name. `Metadata` would be ambiguous since cache2 and IndexedDB have their own. It's a code folder
name, not a folder on disk.

### How the parser works

`FirefoxLocalStorageParser.Parse(originDirectory)`:
1. `GetChild(".metadata-v2")` → hands it to the metadata parser **once**. Every entry shares it.
   Missing or unreadable → `Metadata = null`, carry on.
2. `GetChildDirectories("ls")` → `data.sqlite`. Not there → return empty entries (site just has no
   Local Storage).
3. Opens it with the repo's SQLite tool (`IDatabaseOpener`, `JournalType.None`), gets rows of `data`.
4. `BuildEntry` per row, adds to a list. Corrupt page part-way → keeps what it read, stops the table,
   one warning with the count.
5. Returns a result set: metadata once + the entries.

`BuildEntry(row)` → one entry, or null if the row is unusable:
- Needs all four columns and both type columns to be numbers. Otherwise returns null and the row is
  skipped (counted, **one warning per database**, not per row).
- Reads the value bytes. Empty values are stored as empty TEXT, and the SQLite reader hands back one
  leftover `0x0D` byte rather than none, which would decode as `\r`. Caught inline. **This was found by
  comparing with CCL's reader.**
- Hands bytes + types to `LSValueDecoder.TryDecode`. Failure leaves `Value` null; the entry still comes
  back with `OriginalValue`.

`LSValueDecoder.TryDecode` fails (→ null `Value`) in six ways: unknown compression number, unknown
conversion number, bad Snappy header, Snappy failure, decompressed size over the 15 MiB cap (Firefox's
default 5 MiB-character quota × 3 UTF-8 bytes per character), or UTF-16 bytes with an odd count. Each
logs a warning.

UTF-16 is copied two bytes at a time on purpose rather than via `Encoding.Unicode`, so a lone surrogate
survives instead of becoming U+FFFD. Firefox does the same with `memcpy` in `PutCStringBytesToString`.

**Bad data never crashes it.** Undecodable values come back with a null `Value`, unusable rows are
skipped, missing metadata leaves website and time empty.

---

## 8. Decisions (don't re-litigate)

**Scope and split**
- Research on CARS-1860, implementation split FileFormats (CARS-2225) + lib (CARS-2252). Vedant OK'd both.
- New format parsed in FileFormats; old format is a **hunter in lib** (plain text, plain SQLite, no
  decoding needed). Vedant, 2026-10-27.
- Parse both formats, one artifact. Old rows have no time.
- Containers / `^partitionKey=` left out: already in the source path, no other Firefox artifact or Chrome
  shows the equivalent, easy to add later.
- Older `data.sqlite` layout (before table version 5.0) left out, not in AR data.
- `ls-archive.sqlite` left out, not in the AR evidence.

**Behaviour**
- **Website comes only from `.metadata-v2`.** No folder-name fallback — `https+++site` → address is lossy.
- **Undecodable values are kept, not skipped:** null `Value`, bytes on `OriginalValue`. Follows the
  architecture guide's "Error and Input Contract". This replaced "log + skip" from the research.
- **A truncated `.metadata-v2` keeps what it read** (2026-11-05). Firefox rejects such a file, but the
  timestamps are in the fixed header before the texts, so they're returned with a null `Origin` and a
  warning. Only a missing file or one shorter than its 17-byte header returns null.
- **A file ending before the is-private byte keeps its origin**, since the origin text was already read
  in full. Only warns.
- **`.metadata-v2` is read up to and including is-private, then stops.** Those bytes are read anyway to
  reach the origin. The section after is optional, unused, and has its own format.
- **`ISourceFile.Stream` is assumed seekable** (Chen + Vedant's call). The WebKit `ReadAsSeekableStream`
  wrapper was deleted rather than copied into every parser; the requirement is documented on
  `ISourceFile.Stream` and in `docs/CONSUMER_FILESYSTEM_INTEGRATION.md`.

**Sources**
- **CCL is a benchmark, not a source.** Known CCL bugs: reads `conversion_type = 0` as big-endian, its
  `value` property returns the key, and it doesn't read the old format. Firefox's source is the truth.
- Doc comments cite Firefox **function names** and link the `searchfox.org/firefox-main` file with no
  line numbers (CLAUDE.md rule, because line anchors go stale on every upstream commit).

**Not concerns**
- **Code coverage 68.81%** — no gate in the pipeline, no threshold, no failure condition. The 70% in
  FileFormats CLAUDE.md is a target. The dip is `Magnet.FileFormats.McpServer` (1,003 lines at 12.36%),
  which isn't even in the NuGet package; back it out and the library is ~75%. Real cause is McpServer
  having no `[ExcludeFromCodeCoverage]`. Worth raising with Vedant separately.
- **Artifactory tab** — the pipeline has zero JFrog tasks, it publishes to Azure Artifacts. The warnings
  are an empty extension state, not a failure.

---

## 9. PR review history (!108255)

Reviewers: Vedant Kanabar, Eric Hornby, Veronica Spicer, Chen Li, Zubair.

### Round 1 (2026-10-29/30)

| From | Comment | Outcome |
|---|---|---|
| Eric | `uint` → `int` cast on text length could flip negative | ✅ Added `length > int.MaxValue` check before the cast |
| Eric | Why `long` not `int` for the type columns? | ✅ No change. SQLite hands every INTEGER back as 64-bit. `long` avoids a cast and preserves a corrupt out-of-range value instead of wrapping it into a valid 0/1. Eric: *"Got mixed up with MSSQL there for a second, my bad"* |
| Eric | Avoid the word "current" in the doc comment | ✅ Both describe the layout instead |
| Eric | Make `Remaining` a method on `FileFormatsBinaryReader` | ✅ Added `public long Remaining`, deleted our private copy. ~20 other hand-written copies left for a follow-up |
| Vedant | "nit: weird formatting" on decoder signatures | ✅ One parameter per line |
| Vedant | Could a value be null? Is it an error? | ✅ No change. A website can't store a real null (`setItem(k, null)` stores `"null"`) and Firefox's table is `value BLOB NOT NULL`. So null = damaged row |
| Vedant | Name it V2, since it parses `.metadata-v2`? | ✅ Renamed. v1 existed: `StorageOperationBase::CreateDirectoryMetadata` wrote `.metadata` with a different layout |
| Vedant | Metadata duplicated on every entry → result set? | ✅ `Parse` returns `IFirefoxLocalStorageResultSet`, modelled on the repo's `IIndexedDbResultSet` |
| Veronica | `LastMaintenanceDate` — parse it properly | ✅ `int` → `DateTimeOffset?` via `TryParse(days, Epoch.Unix, Resolution.Days, …)`. Lands at midnight UTC |
| Veronica | "wym by 'not be converted'" | ✅ Reworded to "Null if the stored number is not a valid date, which in practice means a corrupt or truncated file" |
| Chen | Add a count of entries processed when a read fails | ✅ Warning now ends `after {EntryCount} entries` |

### Round 2 (2026-11-04)

| From | Comment | Outcome |
|---|---|---|
| Zubair | Snappy size cap was leaky | ✅ `56ad655` — calls Snappy directly, single block only |
| Vedant | Why `FireFox.Quota` not `FireFox.Metadata` | ✅ Explained, no change. Upstream module name; `Metadata` is ambiguous |
| Vedant | Should we read `data.sqlite-wal`? | ✅ No. Local Storage uses a rollback journal, not WAL, so no `-wal` exists. Firefox *IndexedDB* is the WAL one |
| Vedant | Validate expected columns up front and bail on schema change | ✅ Declined the early exit. Columns are looked up by name, not position, so a schema change can't shift onto wrong data, and bailing on extra columns would lose a readable database. Took the logging half → `6d79b42` |
| Vedant | Arrange/Act/Assert in tests | ✅ Done for the three files this PR owns. Not swept repo-wide (77 instances across 17 files, out of scope) |
| Eric | Enum backing type (Slack FYI) | ✅ No change. Changing the backing type doesn't remove the casts; enum→number is always explicit in C#. Left alone |
| Vedant | Legacy metadata fields | ✅ `2e56945` dropped `IsPrivate`, `Suffix`, `Group` |

### Round 3 (2026-11-05) — the last round

| From | Comment | Outcome |
|---|---|---|
| Veronica | `RawValue` — is it useful to return, especially when compressed? If two fields, maybe drop the bool. Naming nit | ✅ Dropped `IsValueDecoded` (redundant with `Value is null`), renamed `RawValue` → `OriginalValue`. Kept both fields: the row is still worth returning without a decoded value, since the key, site and time tell you the item existed |
| Veronica | Output a sequence number / rowid, so you could deduce a timeframe from it | ⏳ **Still open.** Replied asking what she meant. Facts gathered: the `data` table isn't `WITHOUT ROWID` so `__rowid__` should resolve (unlike Firefox IndexedDB's `object_data`), and the repo already reads it at `SqliteIndexedDbBackingStoreProvider.cs`. But her premise is wrong (the metadata timestamp is a last-access, not a first-access) and a rowid gives ordering only, not times. **Two unanswered questions if she pushes:** does Firefox's rowid survive an item being updated (in-place UPDATE keeps it, INSERT OR REPLACE doesn't), and does maintenance vacuum these files (a vacuum renumbers rowids into key order, destroying write order). Both answerable from `dom/localstorage/ActorsParent.cpp` |
| Veronica | Do we have the semantics for these timestamps documented? What action updates them, user or application? | ✅ Researched from Firefox source and documented. See section 6. Added `<remarks>` to `IFirefoxOriginMetadataV2` and a bullet to the Local Storage README |
| Veronica | "reduce comments" on `FirefoxOriginMetadataV2Parser` | ✅ Class doc 18 lines → 8, `TryReadCString` 5 → 3. Kept the Firefox symbol references and `<seealso>` links (CLAUDE.md requires them); dropped the byte-layout recital since the README has the full table |
| Veronica | `IFirefoxOriginMetadataV2Parser` could be internal? | ✅ Made internal and moved to `FireFox/Quota/`. Nothing outside the library used it. It was public by habit, matching the other parsers, not because a consumer needed it |
| Veronica | Does `ReadValueBytes` need to be a separate method? | ✅ Inlined into `BuildEntry` and deleted its two direct tests. `BuildEntry_EmptyTextValue_DecodesToEmptyString` still covers the `0x0D` case |
| Veronica | Do we still want the timestamps even if we don't get the origin? | ✅ Changed. Previously a truncated file returned null and you lost both timestamps even though they're in the first 17 bytes. Now returns them with a null `Origin` |
| Chen → Vedant | "is ISourceFile not seekable?" | ✅ Resolved. Chen: it's an API contract thing, don't re-wrap in every parser. Vedant: drop the helper and note the assumption on the API. Did that, plus fixed `docs/CONSUMER_FILESYSTEM_INTEGRATION.md` which still said not to assume seekable |

### Commits (newest last)

```
round 1:  Put decoder method parameters one per line
          Reject .metadata-v2 text lengths too big for an int
          Describe the Local Storage format by its layout instead of as current
          Move Remaining onto FileFormatsBinaryReader for reuse
          Rename origin metadata parser to V2 to match .metadata-v2
          Return Local Storage results as a result set with the metadata once
          Parse the origin metadata maintenance date into a DateTimeOffset
          Clarify when the metadata timestamps are null
          Log how many entries were read before a database read failed
round 2:  1d54e37  Share one seekable-stream helper between the SQLite parsers
          2e56945  Drop the legacy origin metadata fields Firefox no longer fills in
          7f82fd0  Assume ISourceFile streams are seekable
          56ad655  Call Snappy directly for Local Storage values
          949c4f4  split Local Storage decoder tests into arrange act assert format
          940fb38  split origin metadata tests into arrange act assert format
          f466970  split Local Storage parser tests into arrange act assert format
          6d79b42  log skipped Local Storage rows once per database instead of per row
          68a9f13  update readme
round 3:  rename RawValue to OriginalValue and drop the redundant IsValueDecoded flag
          document what updates the origin access and maintenance timestamps
          trim metadata parser docs/comments
          note that source file streams must be seekable in the consumer guide
          make the origin metadata parser interface internal
          inline the value bytes helper into BuildEntry
          keep the metadata timestamps when the origin text is truncated
```

### Still open in FileFormats (won't block lib)

- Veronica's rowid question, above.
- No test yet for a framed Snappy value being rejected. Behaviour is correct, test is missing.
- `FirefoxSnappyHelper`'s framed path still has no total-output cap for its remaining caller,
  `SpiderMonkeyValueDeserializer` (Firefox IndexedDB). Same blow-up, different entry point. Raised with
  Zubair, undecided. Unrelated to Local Storage.
- E2E validation in Artifacts/AR is a manual step per FileFormats CLAUDE.md, and this PR spans Firefox
  Local Storage, WebKit IndexedDB and Chromium Session Storage across 65 files.
- `CLAUDE.md` merge conflicts have bitten twice on `fury` merges (add/add near the Runner command block).
  Keep both blocks.

### Follow-up tickets to create

| Ticket | Why | Priority |
|---|---|---|
| **Shared `ILocalStorageEntry` (FileFormats)** | Vedant's comment: a common `ILocalStorageEntry` (Key, Value, Source, Offset) with `IChromiumLocalStorageEntry` + `IFirefoxLocalStorageEntry` on top. Separate ticket because Chrome's shape already uses the name and lib's Chrome hunter depends on it | Low |
| *Maybe:* `Remaining` sweep | `BaseStream.Length - BaseStream.Position` is written out ~20 more times across the repo | Low |

---

## 10. Test data

**Test page:** `D:\code\ff-localstorage-test\make_test_localstorage.html`

1. `py -m http.server 8000 --directory "D:/code/ff-localstorage-test"` (Python is `py` on Ben's PC)
2. Open http://localhost:8000/make_test_localstorage.html in Firefox
3. Click buttons, then **close Firefox fully** (writes are batched and the file is locked while open)
4. Open `...\storage\default\http+++localhost+8000\ls\data.sqlite` in SQLite Expert. F12 → Storage →
   Local Storage to compare

| Button | Saves |
|---|---|
| Write Records | `short_text`, `unicode_text`, `empty_value`, `json_value`, `long_repeated_text` (10,000 × "a", compressed) |
| Write Then Delete One | `to_be_deleted`, deleted straight away (never reaches the file) |
| Clear All | Deletes everything |
| Deletion Test 1: Write / 2: Delete | `delete_me_later`, deleted in a later session → gap at rowid 6, text wiped |
| Write Broken Text | `broken_text` (forces `conversion_type = 0`) |

**AR2 `Computer:Firefox`:** evidence `D:\data\Computer\Firefox\evidence` (9 zips, 1.3 GB), baseline
`D:\baseline\Computer\Firefox`. Downloaded with `Scripts\download_data_baseline_from_S3.bat` (C → C →
`Firefox`). There's also a `macOS/Firefox` scenario in S3, not downloaded.

| Zip | Firefox | Format | Items |
|---|---|---|---|
| `data from Jack.zip` | 22, 34 | Old | 5, 6 |
| `firefox.zip` | 29, 32, 68, Mac | Old | 69, 49, 9, 3 |
| `Firefox_IndexedDb_152.zip` | 152 | New | 120 across 10 websites (29 compressed, all type 1, `last_access_time` 0, all have `.metadata-v2`, several `^partitionKey=` folders) |

Old-format copy outside the zip: `D:\temp\CARS1860\old-format (Firefox 32)\webappsstore.sqlite`
(49 rows, 16 websites, Twitter 14, LinkedIn 7, YouTube 5).

**CCL comparison script** (takes ~30 s, any PowerShell window):

```powershell
powershell -ExecutionPolicy Bypass -File D:\code\tools\ccl-compare\run_compare.ps1
```

Step 1 runs our Runner on the unzipped AR2 `Firefox_IndexedDb_152` → `Total: 10 websites, 120 items,
0 not decoded`. Step 2 runs CCL's reader on the same data and compares item by item → `Same value: 120`,
`Value differs: 0`. Other data: add `-StorageDirectory "<folder>\storage\default"`. Script + CCL live in
`D:\code\tools\`, outside the repo.

**Testing results for CARS-2225:** 43 unit tests, Runner on the test page + AR evidence (matches the
research), CCL identical on AR except CCL's known UTF-16 bug. The CCL check is what found our empty-value
bug. No AR2 diff — that runs through the lib artifact, i.e. CARS-2252.

**Don't commit `ffls.txt`.** It's Runner output with personal browsing in it and it sits at the repo root,
so `git add -A` catches it. Add specific folders instead.

**Build gotcha:** the `magnet-fileformats` MCP server locks `Magnet.FileFormats.dll`, so a solution build
fails with MSB3027 while a Claude session has it attached. The test project references the MCP server, so
`dotnet test` hits it too. Fix: `taskkill /PID <pid> /F` or
`Get-Process Magnet.FileFormats.McpServer | Stop-Process -Force` (PowerShell — single slashes, not the
Git Bash doubled form).

---

## 11. Things explained (kept from the research notes)

- **Encoding:** the rule for turning letters into bytes. UTF-8: `a` = `61` (1 byte, others 2-4).
  UTF-16: `a` = `61 00` (2 bytes).
- **`conversion_type`:** which encoding Firefox saved the value in. Websites hold text as UTF-16; Firefox
  converts to UTF-8 to save space (type 1, almost everything). If it can't convert, it saves raw UTF-16
  (type 0).
- **"Broken" text:** emoji are stored in UTF-16 as two halves. Half an emoji on its own has no UTF-8
  version → type 0. Whole emoji convert fine. Size doesn't matter, only whether it's whole.
- **Big vs little-endian:** only matters when a character or number is more than 1 byte. UTF-8 has no byte
  order. UTF-16 type 0 is always little-endian. Big-endian is only for the **numbers** in `.metadata-v2`.
  `conversion_type` doesn't choose the byte order.
- **Why CCL's bug only shows with broken text:** CCL uses big-endian only for type 0, and type 0 only
  happens with broken text.
- **Seekable:** can you jump to any point in the file, or only read it start to finish? A DVD is seekable,
  a cassette tape isn't. SQLite hops between pages all over the file, so it needs the DVD version.
- **Vacuum:** a SQLite command that rebuilds the file. Deleting rows doesn't shrink a SQLite file, it just
  marks the space reusable, so a vacuum writes a fresh compact copy. Side effect: row numbers aren't real
  data, they're positions, so a vacuum hands out new ones in whatever order it reads the rows.
- **Parser vs hunter vs artifact:** a **parser** (FileFormats) takes raw bytes → tidy pieces of info plus
  where each came from, and decides nothing about meaning or display. A **hunter** (lib) finds the right
  files in evidence, hands them to the parser, turns results into rows. An **artifact** (lib) is the
  definition of what the investigator sees: name plus columns.
- **Why two repos:** `lib-magnet-artifacts` is product code. `pkg-magnet-fileformats` is a toolbox for
  reading tricky file types, shipped as a package, so changes there only reach lib after a new package
  version.

---

## 12. Repo rules that shape the FileFormats code

From `docs/CODING_STANDARDS.md`, `docs/ARCHITECTURE_AND_API_GUIDE.md`, `CLAUDE.md`:

- Public "front door" interface in `Magnet.FileFormats/Api/`, real code `internal sealed` behind it.
  Internal interfaces live next to their implementation in the format folder, never in `Api/`.
- Registered in `AddFileFormatsServices` so lib can ask for it by name.
- Results implement `ISourceResult` (Source = file path, Offset = position in file). ADR-005.
- Result objects in their own files, `internal sealed record`.
- No unexplained numbers: `sizeof`, named constants, enums. Check lengths against bytes left before reading.
- Bad data → skip or salvage plus log, never crash. The guide prefers returning the record with the
  unreadable part nulled over silently skipping.
- Use the format's own names (Firefox's terms).
- Doc comments cite upstream **function names** wrapped in `<c>`, prefixed with the vendor, and link the
  file in `<seealso>` with no line numbers. `<c>Foo</c>` after a vendor prefix is theirs and unchecked;
  `<see cref="Foo"/>` is ours and the build verifies it.
- Main branch is **`fury`**, not `main`. Azure DevOps, use `az repos pr`.

---

## 13. How Ben wants to work

- Plain, simple language, no format jargon in chat. Explain terms or avoid them. **Short** answers.
- **One file at a time.** Explain what it is and why → Ben OKs → write it. Never several files at once.
- Explain what a review comment is actually asking before proposing a fix. Don't assume Ben knows what the
  reviewer means.
- Big picture before details. Explain code with concrete bytes and examples.
- Cite sources with links. Be honest about what was tested and how.
- **Give git/build/test commands for Ben to run.** Don't run them.
- **Commit messages:** one short `-m` line, no ticket number, no body, no Co-Authored-By.
- Doc comments and code comments: short and plain, not in-depth explanations.
- Log calls, arguments and comments each stay on one line, no wrapping.
- **PR replies in Ben's voice:** all lowercase (a stray capital `I` is fine), spaced hyphen ` - ` instead
  of commas or em dashes, no trailing periods on short lines, typos left in, no AI polish, no opener that
  compliments the reviewer. Sample he actually posted:

  > i'm not sure i fully understand. firefox does have a rowid - are you suggesting we could use it to get
  > the order entries were added in, and match them more closely to the timeline?
  >
  > also I wanted to note thayt the timestamp from the metadata file is the last access time, not the first

- Work in FileFormats from its own VS Code window so its `CLAUDE.md` and skills load; lib work from the
  lib window.

---

## 14. Sources

Firefox source. No official write-up exists for any of this; the spec is the code. Canonical host is
`searchfox.org/firefox-main`.

| What | Symbol | File |
|---|---|---|
| `data` table schema | `CreateDataTable` | `dom/localstorage/ActorsParent.cpp` |
| Compression and text types | `LSValue::CompressionType`, `LSValue::ConversionType` | `dom/localstorage/LSValue.h` |
| Value read/write | `LSValue::Converter`, `LSValue::InitFromString`, `PutCStringBytesToString` | `dom/localstorage/LSValue.cpp` |
| `.metadata-v2` header | `ReadDirectoryMetadataHeader`, `WriteDirectoryMetadataHeader` | `dom/quota/DirectoryMetadata.cpp` |
| `.metadata-v2` rest + write | `ReadFullOriginMetadataFromMetadataV2File`, `CreateDirectoryMetadata2` | `dom/quota/ActorsParent.cpp` |
| Access time trigger | `QuotaManager::OpenClientDirectory`, `ClientDirectoryLockHandleDestroy`, `QuotaManager::UpdateOriginAccessTime` | `dom/quota/ActorsParent.cpp` |
| Access time write | `SaveOriginAccessTimeOp::DoDirectoryWork` | `dom/quota/OriginOperations.cpp` |
| Access time pref + docs | `dom.quotaManager.temporaryStorage.updateOriginAccessTime` | `modules/libpref/init/StaticPrefList.yaml` |
| Text format | `nsBinaryInputStream::ReadCString` | `xpcom/io/nsBinaryStream.cpp` |
| Old format reversed website | `StorageDBUpdater.cpp` | `dom/storage/StorageDBUpdater.cpp` |
| Default quota | `dom.storage.default_quota` | `modules/libpref/init/StaticPrefList.yaml` |

Other:
- Time unit: [PRTime](https://firefox-source-docs.mozilla.org/nspr/reference/prtime.html), microseconds
  since 1970 UTC. The repo's `VendorFormats.Mozilla` expects exactly that.
- [CCL Group `ccl_moz_localstorage.py`](https://github.com/cclgroupltd/ccl_mozilla_reader/blob/main/ccl_mozilla_reader/ccl_moz_localstorage.py)
  — comparison benchmark, **not authoritative**. CCL Group is a UK forensics company that publishes free
  browser-reading tools.
- Vedant's Firefox Cache2 PR as a pattern:
  [85876](https://dev.azure.com/gauss-dev/Magnet/_git/pkg-magnet-fileformats/pullrequest/85876).
- Lib references for the hunter: `FirefoxIndexedDbStorageHunter.cs` (same folders),
  `Chrome/Hunters/ChromeLocalStorageHunter.cs` (calls a FileFormats parser),
  `Safari/SafariLocalStorage.cs` (same columns), other Firefox SQLite hunters (old format).
- Lib's own Snappy: `GeneralCompressionHelper.SnappyDecompress`
  (`Magnet.Artifacts.Common/Compression/Helpers/GeneralCompressionHelper.cs`).
