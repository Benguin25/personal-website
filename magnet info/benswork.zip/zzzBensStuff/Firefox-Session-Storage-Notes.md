# Firefox Session Storage: notes

Everything from our chats on Firefox Session Storage, in one place. Read this first when picking it
up in a new chat.

Last updated 2026-11-25.

**Sections:** Debriefs first: **CARS-2272 debrief (after the FileFormats move) jot notes** → **FileFormats debrief (CARS-2285) jot notes** → Lib debrief notes (CARS-2272, older) → Debrief (CARS-1861, for presenting) → then **LIB CHAT — START HERE (CARS-2272 switch-over)** → CARS-2285 PR review + next work → **CARS-2285 done → CARS-2272 step 2 (lib) — start here** → CARS-2285 handoff (FileFormats) → **CARS-2272 implementation (2026-11-15/16) — start here** → Where we left off (2026-11-12) → Summary → Ticket → Plan → Status → What is Session
Storage → CCL → Our current code → Ground truth (tools, capture steps, results) → AR2 check →
Vedant's add-on (Chrome comparison, bugs, field inventory, Chrome mapping, parser approach) → Mozilla
source → Reading the JSON → **Chat 2026-11-11 (files explained, Axiom code walkthrough, AR2 per
profile, proof links, parsing approach)** → CARS-2252 side work done in the same chat.

---

## CARS-2272 debrief (after the FileFormats move) — jot notes

Ben's talk track, in his own words (from his dry run, 2026-11-25). Aim ~5 min. Order: how the ticket came about →
what Session Storage is → the files → FileFormats PR → code → AR2 results. Older version of these notes (before
the FileFormats move): "Lib debrief notes (CARS-2272, screen share)" further down.

### 1. Intro

- "hey everyone, this is the debrief for CARS-2272"
- "how i'm gonna go about it: how this ticket came about, what we've already done, i'll touch on the code for like a
  minute, and then i'll show the testing results from AR2"

### 2. What is Session Storage

- "session storage is pretty much key value pairs that the browser saves temporarily"
- "an example could be what step you're on in onboarding, or anything temporary the website wants to save. so it's
  just key value pairs"

### 3. How Firefox stores it (show the profile folder)

- show `C:\Users\bprobert\AppData\Roaming\Mozilla\Firefox\Profiles\0qwa47l9.cars1861\` and the 5 files:
  - `sessionstore.jsonlz4`
  - `sessionstore-backups\recovery.jsonlz4`, `recovery.baklz4`, `previous.jsonlz4`, `upgrade.jsonlz4-<build id>`
- "each of these session files hold session storage. they all have the same format, they're just snapshots of your
  browser taken at slightly different times"
- "so this ticket is basically asking for a session storage artifact. the best things we can pull from these files
  are the key, the value, the origin, which is the website, the last accessed time, and the sources, so which
  session store file it came from"
- "this ticket also touches the session store artifact. session storage is different from session store, i'll explain
  that more when i go over the code"

### 4. The FileFormats PR

- show FileFormats PR !111540
- "half of this was done in file formats. this PR is approved and the comments are resolved, i just haven't merged it
  yet. i'm waiting to debrief this and then i'll merge both at the same time so we don't get a version mismatch"
- "the file formats PR does the parsing for us. it takes one of the session files i showed you earlier and first
  turns it into readable JSON, because most of them are compressed with LZ4 (old firefox wrote plain JSON, and
  encrypted ones just get skipped). then it goes through that JSON and pulls out the session storage: the key value
  pairs, the last accessed time, the origin, and which file it came from, and returns that as an object"
- "so what we have left to do on the lib side:"
  - "the actual artifact, with key, value, origin, last accessed and sources"
  - "read in all the files"
  - "and the main thing, merge duplicates, because it'll find the same key value pairs across a bunch of these files.
    under the sources fragment i just list which file or files it came from"
- "this PR also touched the session store hunter. that hunter gets the tabs, so the page titles and URLs. it reads the
  same files as session storage, but in the past it missed some: it didn't look for `sessionstore.jsonlz4`, and it
  couldn't read the upgrade files. so we fixed that as well"

### 5. The code (~1 min)

All in `Magnet.Artifacts/Firefox/`.

- **`FirefoxSessionStorage.cs`** (lines 33-37): "this is our artifact, we state our five fragments right here"
- **`Helpers/FirefoxSessionFiles.cs`** (`Register`, 50-55): "this is a shared file, used by both session storage and
  session store. it finds these five files and registers them"
- **`Hunters/FirefoxSessionStorageHunter.cs`**:
  - (line 50) "this hunter is called once per file. but whenever it's called, we call get profile session files, which
    gives us all five files, sorted alphabetically"
  - (lines 54-56) "and we only keep going if the current file is the first one. we do this because of duplicates. if
    each call just did its own file, we couldn't merge them. so it gets called five times, but the real work only
    runs on one of those five. that's what this yield break does"
  - (line 61) "from there it reads every file with the file formats parser and adds the items to one list"
  - (line 70) "then we call the merger with all the found items"
- **`Helpers/FirefoxSessionStorageMerger.cs`**:
  - (lines 36-37) "this checks if the item has the same origin, key, value and last accessed time as one we've already
    got. if not, we add it as a new item"
  - (line 44) "then outside the if statement we add the file it came from. so if it's a duplicate, the file just gets
    added onto the existing item, and you can see every file it came from"
- **`Hunters/FirefoxSessionStoreParsedHunter.cs`** (38-40): "not gonna spend much time here. i just changed it to call
  the file formats session store parser instead of its own, so it picks up all the files now instead of missing a couple"

### 6. Testing (AR2)

- "what we'd expect: new hits for firefox session storage, with key value pairs, origin, last accessed time and at
  least one source for each. we might also see new hits for session store, since we're searching more files"

**`Computer:Firefox`** (`Output_20261125_092702`)

| Artifact | Expected | Got |
|---|---|---|
| Firefox Session Storage | new hits | **+17** |
| Firefox SessionStore Artifacts | some new hits | **+34 / −28** |

- session storage +17: "all new since it's a new artifact. they all come from one evidence file, old firefox 29 and 32,
  and it matches a manual count. and the merging works: 5 google.ca items were in two files, so we get 5 hits, not 10,
  and sources lists both"
- session store +34 / −28: "28 of these are the same hits, the title just got fixed. the old code read the old plain
  files with the wrong encoding, so `Magnet ForensicsÂ®` is now `Magnet Forensics®`. AR sees a changed value as one
  missing and one new. the other 6 are actually new, from two upgrade files the old code couldn't read"
- "every hit is exactly the same as my run before i moved the code to file formats, locations included, so the move
  didn't change anything"
- if anyone asks about the Cache Records +1 / −1: "not from this ticket, it came in when i merged fury. one cache entry
  now gets a last sync date, probably the datetime package bump"

**`macOS:Firefox`** (`Output_20261125_094939`)

- "no changes. session storage ran but found nothing, which is right, the mac session files don't have any session storage"

### 7. Closing

- "next i'll merge the file formats PR, point lib at the released version, run AR2 again, then merge lib"
- "one known limitation: if a site saves half an emoji, we show a `�` for that half. that's a follow-up ticket: <ticket number>"
- "any questions?"

### Possible questions

- **Why read all 5 files?** "an older file can still have an item the newest one lost. merging keeps it to one hit"
- **Why `Sources` and not `Source`?** "`Source` is reserved by Axiom Examine, the blackbox test catches it"
- **Encrypted files?** "firefox 160+ can encrypt them, it's off by default. file formats logs it and skips the file"
- **Why is the location a JSON path and the offset 0?** "the items only exist after decompressing, so there's no byte
  in the file to point to"
- **Open vs closed tab, page URL / title?** "left out on purpose, could be future artifacts"

---

## FileFormats debrief (CARS-2285) — jot notes

For Ben to talk from, 2026-11-19. Separate from the lib (CARS-2272) debrief. Order: tickets → code → runner →
results (raw → JSON → items) → live Firefox → what's next.

### 1. Overview: how the tickets came about

**Opening:** "hey everyone, this is the debrief for CARS-2285"

**a) CARS-1861, the research ticket** (Firefox Session Storage spike)
- briefly show what came out of it: where Firefox keeps Session Storage
- Firefox has no Session Storage database. it saves each tab's Session Storage inside its **session store files**
- session store files = snapshots of the open windows and tabs, so Firefox can restore them after a restart or crash
- they're JSON. current Firefox compresses them with LZ4 (`.jsonlz4`), very old Firefox wrote plain JSON
- show the files in my test profile (`D:\demo\cars1861-profile`), **5 files**, all the same layout, all hold Session Storage. only difference = when the snapshot was taken:

| File | When it's written |
|---|---|
| `sessionstore.jsonlz4` (profile folder) | when Firefox closes |
| `sessionstore-backups\recovery.jsonlz4` | about every 15 seconds while Firefox is running |
| `sessionstore-backups\recovery.baklz4` | the recovery snapshot before that one |
| `sessionstore-backups\previous.jsonlz4` | the close snapshot from the time before |
| `sessionstore-backups\upgrade.jsonlz4-<build id>` | when a new Firefox version first runs |

- so: same item often shows up in several files, just from different moments

**b) CARS-2272, the first build (lib repo)**
- original plan: put everything in lib: the reader, the parser and the hunter
- built it, ran AR2, opened the PR
- Veronica's comment on the PR: wouldn't the reader/parser make more sense in FileFormats, with the other Firefox formats (Local Storage, IndexedDB, Cache2)?
- agreed, it belongs there. should have done it that way first

**c) CARS-2285, this ticket**
- moving the **reader and parser** from lib into FileFormats. the hunter stays in lib
- goal: **move, not rewrite**. same behaviour, just FileFormats packaging (public interfaces, DI, `ISourceFile`)
- CARS-2272 is blocked on this one. once this is in, lib switches over to use it

**Transition:** "so this is the code, there's two main files..." → section 2

### 2. The code (2 pieces)
- **reader** (`IFirefoxSessionFileReader`): session file in → JSON text out
  - checks the first bytes: `mozLz40` = compressed (decompress with LZ4), `mozEnc` = encrypted (skip + warn), else plain text (old Firefox)
  - picks by header, not file name, because upgrade copies have odd names (`upgrade.jsonlz4-<build id>`)
- **parser** (`IFirefoxSessionStorageParser`): session file in → one item per key out
  - calls the reader, then walks the JSON: windows → tabs → `storage` → website → key
  - looks in open tabs, closed tabs, closed windows, and the previous session
  - each item: website, key, value, tab last accessed time, Location (JSON path), Source (file), Offset
- **Offset is always 0**: items only exist after decompressing, so there's no spot in the file to point to. Location says where it is instead
- what changed for FileFormats: public interfaces + DI, `ISourceFile` in, plain log warnings, named constants, Firefox source links (searchfox)
- same pattern as Firefox Local Storage
- **changed in review**: the reader is internal, and lib's Session Store title/URL parser moved to FileFormats too (`IFirefoxSessionStoreParser`), so lib only calls the two parsers (Veronica: FileFormats only exposes parsers)
- the title/URL parser is copied from lib as-is: finds any JSON object with a `url` and `title`. returns `about:` pages too, the lib hunter skips those
- folder `FireFox/SessionStore/`, named after the file, since both parsers read it
- how the parser walks the JSON: see the talk track in "CARS-2285 PR review" → "Explanations given to Ben"
- review changes worth mentioning: entry extends the shared `ISessionStorageEntry`, time goes through `Magnet.Datetime`, Newtonsoft kept on purpose

### 3. Tests
- 11 unit tests, all pass
- reader (7): compressed, plain text, encrypted, header cut off, garbage data, impossible size, no file
- parser (4): items in every tab location with exact Locations, dates stay text + half emoji, not JSON, reader gave nothing
- 8 moved from lib, 3 new for edge cases

### 4. The runner (how I tested on real data)
- FileFormatsRunner = command-line tool in the repo, runs a parser on real files without Artifacts/Axiom/AR
- new command: `ffss <profile> -o ffss.txt -j <json folder>`
- per file it shows: size, first bytes (raw), JSON length, every item
- `-j` saves each file's decompressed JSON, indented, so you can find an item's Location in it
- items listed per file, not merged (merging is lib's job)

### 5. Results on my CARS-1861 test profile (copy in `D:\demo\cars1861-profile`, Firefox closed)
- **5 files, 93 items, 0 not readable**
  - `sessionstore.jsonlz4`, `previous`, `recovery`, `recovery.baklz4`: 23 items each
  - `upgrade.jsonlz4-20261022150525`: 1 item (from 2026-11-09)
- **raw**: `sessionstore.jsonlz4` is 10,868 bytes, first bytes `6D 6F 7A 4C 7A 34 30 00 ...` = `mozLz40` then junk (compressed)
- **JSON**: decompresses to 33,132 characters (~3x bigger). open `D:\demo\ffss-json\sessionstore.jsonlz4.json`
- **items**: `D:\demo\ffss.txt`. example:
  - `http://localhost:8000` / `p8000_short_text` = `hello from port 8000`
  - Location `windows[0].tabs[1].storage['http://localhost:8000'].p8000_short_text`
  - last accessed 2026-11-19 18:47:46 UTC
- **show it**: open the `.jsonlz4` in VS Code (scrambled) → `First bytes` line → the `.json` → Ctrl+F `p8000_short_text`, it's at that Location
- things worth pointing at:
  - `p8000_broken_text` = `abc�def`: half emoji replaced, known limitation (follow-up ticket)
  - `p8000_written_at` stays text, not turned into a date
  - a real site shows up too: Firefox's own crossword widget, with `^partitionKey=...` on the website (storage saved inside another page)
  - same item in several files = same layout, different moments. that's why lib merges

### 6. Live Firefox
- open the test pages (`localhost:8000` / `8001`), DevTools → Storage → Session Storage
- show the same keys/values as `ffss.txt`
- if writing new values live: Firefox saves `recovery.jsonlz4` about every 15 sec. close Firefox (or wait), copy the files again, rerun `ffss`

### 7. What's next (closing)
- wanted to debrief this before the lib side
- next: switch the two lib hunters to call this FileFormats API, delete the old lib copies, rerun AR2 (CARS-2272)
- getting this reviewed now so it isn't a blocker when the lib side is done

### Possible questions
- **why Offset 0?** item is in decompressed text, no byte in the file to point to. Location covers it
- **why Newtonsoft?** gives the JSON path (Location) for free, same as the old parser. half emoji is the known trade-off
- **encrypted files?** Firefox 160+, off by default. logged and skipped
- **why does the JSON say 33,164 in the header but 33,132 characters?** header counts bytes, emoji/accents are more than 1 byte each

---

## Lib debrief notes (CARS-2272, screen share)

**Order:** ticket → what Session Storage is → how Firefox stores it → code (quick) → testing → questions

**1. Ticket** (~30 s)
- CARS-2272: implement Firefox Session Storage. Follow-up to the CARS-1861 research (debriefed a few days ago)
- Similar to Local Storage (CARS-2252), which I'd already done
- PR [!110739](https://dev.azure.com/gauss-dev/Magnet/_git/lib-magnet-artifacts/pullrequest/110739)

**2. What Session Storage is** (~1 min)
- Temporary key/value items a website saves **per tab**
- Kept when the tab reloads, gone when the tab closes
- Example: the step a user is on in onboarding (`onboarding_step = 2`). Should survive a reload, doesn't matter days later
- vs Local Storage: shared by all tabs and kept until cleared (e.g. dark mode)

**3. How Firefox stores it** (~1 min, show the folder)
- Open `C:\Users\bprobert\AppData\Roaming\Mozilla\Firefox\Profiles\0qwa47l9.cars1861\`
- No database of its own. Firefox saves it **inside its session files**: snapshots of the whole browser (windows, tabs, pages), so it can restore tabs after a restart or crash. Session Storage is one piece of each snapshot
- **5 files**, all the same format, taken at different times:

  | File | When it's saved |
  |---|---|
  | `sessionstore.jsonlz4` (profile folder) | When Firefox closes |
  | `sessionstore-backups\recovery.jsonlz4` | About every 15 s while Firefox is open (when something changed) |
  | `sessionstore-backups\recovery.baklz4` | The autosave before that one |
  | `sessionstore-backups\previous.jsonlz4` | The close snapshot from the time before |
  | `sessionstore-backups\upgrade.jsonlz4-<build id>` | When a new Firefox version first ran. Can be months old |

- **How we handled it:** read **all 5** files, then **merge** the duplicates
  - Most items are the same in several files (the 15 s autosave and the close snapshot often match)
  - But they can differ: an older file can still hold an item a newer one lost
  - So reading only one file could miss items. Reading all + merging is the safe option
  - One hit per item. **Sources** lists every file it was found in
- No time per item. Last Accessed = when the item's tab was last selected

**4. Code** (quick, take questions). Data flows: file → JSON → items → merged → hits
- `FirefoxSessionStorage.cs`: the artifact. Columns Key, Value, Origin, Last Accessed, Sources (lines 31-38)
- `FirefoxSessionFiles.cs`: which files count as session files (lines 50-55). Shared with the existing SessionStore hunter
- `FirefoxSessionFileReader.cs`: file → JSON text. Unzips compressed files, reads old plain-text ones, skips encrypted ones (lines 47-55). Also shared
- `FirefoxSessionStorageParser.cs`: JSON → items. Reads open tabs, closed tabs, closed windows and the previous session (lines 52-63, `AddTab` 98-123)
- `FirefoxSessionStorageMerger.cs`: "same item" = Origin + Key + Value + Last Accessed (line 34). Two tabs with the same key have different Last Accessed, so they stay separate
- `FirefoxSessionStorageHunter.cs`: runs once per file, but only the profile's **first** file does the work (lines 48-53): reads all files (55-64), merges, one hit per item (66-92)
- `FirefoxSessionStoreParsedHunter.cs` (existing hunter): now uses the shared file list + reader, so it picks up files it used to miss

**5. Testing and why the results make sense**
- **AR2 `Computer:Firefox`** (`Output_20261117_100706`)
  - **Firefox Session Storage: +17 new**
    - New artifact, so every hit is new
    - All from `firefox.zip` (Firefox 29 + 32 profiles). Matches a manual count of every `storage` entry in the evidence
    - Merging works: 5 google.ca items were in both `previous.js` and `upgrade.js-20151216175450` → 5 hits, not 10, Sources lists both
    - Every other session file in AR2 has no Session Storage
  - **Firefox SessionStore Artifacts (existing artifact): 34 new / 28 missing**
    - 28 / 28 = the same hits, title text fixed: `Magnet ForensicsÂ®` → `Magnet Forensics®`. Old code read plain-text files with the wrong encoding. AR sees a changed value as "1 missing + 1 new"
    - +6 = two `upgrade.jsonlz4-<build id>` files, 3 pages each. Old code only unzipped files ending in `lz4`, so it skipped these
  - Schema change: commonly found locations (fixed a `sessionstore.back` typo, added `sessionstore.jsonlz4`)
- **AR2 `macOS:Firefox`** (`Output_20261117_101800`): no changes. Session Storage ran, 0 hits, correct: the Mac session files have no Session Storage
- Unit + blackbox tests pass. art-json reviewed by Mary, suggestions applied

**6. Known limitation: broken text** (decided with Vedant)
- A website can save text with half an emoji in it (test page: `abc\ud800def`). Firefox writes it as-is, but Newtonsoft swaps the broken half for `�` when reading, so we show `abc�def`
- Normal emoji (🦊) are fine. Only half-characters are affected, and they're very rare
- Key, website, rest of the value and time are all still there
- **Decision:** keep `�` for now, noted as a limitation in the doc. Follow-up ticket: **<ticket number>** to keep the original value
- Options looked at (asked on Motherboard):
  - Switch the parser to System.Text.Json (`GetRawText()` keeps the original): needs the whole parser rewritten and the location paths built by hand
  - Add an extra `\` to broken halves before parsing: small, but a workaround

**If asked**
- **Encrypted files**: Firefox 160+ can encrypt session files (off by default). We log it and skip the file
- **Not included on purpose**: open vs closed tab, the tab's page URL / title (could be future artifacts)
- **Why `Sources` and not `Source`**: `Source` is reserved by Axiom Examine (blackbox test `ExamineReservedFragmentNames`)
- **AR2 viewer** adds its own `Sources` value to hits, so the column may look different there. Axiom not affected
- **Plumbing**: `ArtifactStrings.resx` + both `Designer.cs` (display name), `ArtifactDescriptors.cs` (artifact ID `57e6de5b…`), `DataFormat.cs` (`Lz4` for unzip logs), both art-jsons (line 178 Computer, 149 Mac)
- **Unit tests** (`Magnet.Artifacts.Tests/Artifacts/Firefox/`):
  - `FirefoxSessionFileReaderTests`: compressed, plain, encrypted, cut-off header, corrupt compressed data
  - `FirefoxSessionFilesTests`: which file names count as session files
  - `FirefoxSessionStorageParserTests`: every place tabs are read from, date + broken text values, bad JSON
  - `FirefoxSessionStorageMergerTests`: same item merged, same key in two tabs kept apart

---

## Debrief (for presenting, 2026-11-11)

Keep it simple. One real example per point, from the test profile. Detail is in the sections below.

**1. The ticket.** Is Axiom's Firefox Session Storage support up to date? Vedant added: what else
is in the same Firefox file (like Chrome's Current / Last Session)? **Answer: not up to date.
Axiom has no Firefox Session Storage at all**, and the file holds several more useful artifacts.

**2. Three terms.**
- **Session Storage**: `name = value` notes a website saves **per tab** (e.g. `checkout_step = 2`).
  Gone when the tab closes, kept on reload. Local Storage is the long-lived, shared one (dark mode).
- **Session Store**: Firefox's set of **snapshot files** of the browser (windows, tabs, pages), so
  it can reopen tabs after a crash or restart.
- Firefox puts each tab's Session Storage **inside** those snapshot files. (Chrome keeps it in its
  own folder.)

**3. Where the files are** (show in Explorer):
`C:\Users\bprobert\AppData\Roaming\Mozilla\Firefox\Profiles\0qwa47l9.cars1861\`

| File | What it is |
|---|---|
| `sessionstore.jsonlz4` | Snapshot taken when Firefox closed |
| `sessionstore-backups\recovery.jsonlz4` | Autosave every ~15 s while running |
| `sessionstore-backups\recovery.baklz4` | The autosave before that |
| `sessionstore-backups\previous.jsonlz4` | The close snapshot from the run before |
| `sessionstore-backups\upgrade.jsonlz4-<build>` | Copy made when a new Firefox version first ran. Can be months old |

All are the **same kind of snapshot, same layout**, taken at different moments. Often near-copies.
Older ones can hold things the newest one lost.

**4. Opening one** (show live): files are compressed, so decode first:
Firefox uses LZ4, a common compression method, plus a small 12-byte header. A short Python script
skips the header and unpacks the rest with the standard `lz4` Python library.
`D:/code/tools/ccl-venv/Scripts/python.exe -I D:/code/tools/ff-sessionstore-dump/dump_sessionstore.py <profile folder> <output folder>`.
Open `D:\code\ff-sessionstorage-test\decoded-claude\2-closed\sessionstore.jsonlz4.json`, `Ctrl+F`
`"storage"`, go to **line 1136**: tab `SS test 8001` (line 1116), website `http://localhost:8001`,
`p8001_short_text = "hello from port 8001"` (line 1143). Optional: show the same items in Firefox
F12 → Storage → Session Storage.

**5. What we can get from the files**

**For a Session Storage artifact** (one row per item):
- Website, Key, Value
- From the tab it belongs to: page URL and title, time the tab was last used
- Open or closed tab (and when it was closed)
- Which file it came from

Not in the files: when each item was written, old values, deleted items.

**Other artifacts from the same files** (not Session Storage):
- **Open tabs**: URL, title, last used time
- **Tab history**: the back/forward pages in each tab
- **Recently closed tabs and windows**, with the time they were closed
- **Previous session**: the tabs from the time Firefox ran before
- **Form text typed but not submitted** (passwords and card numbers are excluded)
- **Address bar text typed but not entered**
- **Session cookies**

**6. What Axiom does today.** One artifact, "Firefox SessionStore Artifacts". It lists the URL and
title of every page in the files. That's it: no Session Storage, no times, no open vs closed tab.
It also misses some files (including the main `sessionstore.jsonlz4`).

**7. How we know.** Our own test profile (3 captures + restart check), Firefox's source code and
bug tracker (Bug 883609 = backups folder in Firefox 33, Bug 934967 = compression in Firefox 56), CCL's
reader as a second opinion, AR2 data (only old Firefox: 22 Session Storage items, all 2014).

**8. Questions for the group**
1. **Duplicates.** The same item is in up to 5 files (e.g. `p8001_short_text` = 8 hits in 4
   files). Read all files and merge identical items (recommended), or only read the newest file
   (loses items)? What counts as "the same"?
2. **Test data.** AR2 only has old Firefox (2014, 22 items). Use our own captures as new test data?
3. **Follow-up tickets.** Proposed:
   1. Fix the existing hunter's bugs (missed files)
   2. One proper reader for the session file
   3. Firefox Session Storage artifact
   4. Open / closed tabs and previous session artifacts (Chrome-style)
   5. Form data and session cookies
   6. Add our captures to AR2

---

## LIB CHAT — START HERE (CARS-2272 switch-over, written 2026-11-24)

For a new Claude chat opened in `D:\code\lib-magnet-artifacts`, branch `CARS-2272` (lib PR !110739). The FileFormats
side (CARS-2285, PR !111540) is finished, reviewed, debriefed and **not merged yet on purpose**.

### Merge order (Vedant, Slack 2026-11-24)
"I would wait for the artifacts PR since it is just plug and play and if you are able to fully verify the results,
merge both in order, this is just incase something unexpected comes up when plugging and play". So:
1. Lib uses the **PR package `8.1.1-PullRequest111540.9`** (file `Magnet.FileFormats.8.1.1-PullRequest111540.9.nupkg`).
2. Switch both hunters, delete lib's copies, build, unit tests, AR2 `Computer:Firefox` + `macOS:Firefox`.
3. If something about the FileFormats API doesn't fit, fix it in the FileFormats PR (new PR build → new version).
4. When verified: merge FileFormats → bump lib to the released FileFormats version → merge lib.

### What FileFormats now gives lib (public API, all in `Magnet.FileFormats`)

| Lib asks DI for | Call | Gets back |
|---|---|---|
| `IFirefoxSessionStorageParser` (`Magnet.FileFormats.Api.Parsers`) | `Parse(ISourceFile sessionFile)` | `IFirefoxSessionStorageResult` with `IReadOnlyList<IFirefoxSessionStorageEntry> Entries` |
| `IFirefoxSessionStoreParser` (`Magnet.FileFormats.Api.Parsers`) | `Parse(ISourceFile sessionFile)` | `IReadOnlyList<IFirefoxSessionStoreEntry>` |

- `IFirefoxSessionStorageEntry` (`Magnet.FileFormats.Api.Models.FireFox`) extends the shared `ISessionStorageEntry`:
  `Origin`, `SessionId` (always null), `Key`, `Value`, plus `LastAccessed` (`DateTimeOffset?`), `Location` (JSON path),
  `Source` (file path), `Offset` (always 0). Same names as lib's old `FirefoxSessionStorageItem`.
- `IFirefoxSessionStoreEntry`: `Title`, `Url`, `Referrer`, `Location` (was `Path` in lib's `SessionStoreItem`), `Source`, `Offset` (0).
- Both parsers call the (internal) reader themselves: lib passes the raw session file, never sees the JSON.
- Both parsers never return null. Encrypted/broken/not-JSON files → empty, logged by FileFormats.
- The reader (`IFirefoxSessionFileReader`) is **internal**: lib can't and shouldn't call it (Veronica: FileFormats only
  exposes parsers).
- The Session Store parser is lib's `SessionStoreParser` copied as exactly as possible (same search, same
  `JsonConvert.DeserializeObject` default settings, same output). It returns `about:` URLs too; **the lib hunter keeps
  its `about:` filter**.

### Lib changes (plan, confirm each with Ben before coding, one file at a time)

1. **Package**: `Directory.Packages.props:49`, `Magnet.FileFormats` `8.0.1` → `8.1.1-PullRequest111540.9`.
2. **`Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStorageHunter.cs`**:
   - get the parser via `FeatureServiceProvider.GetRequiredService<IFirefoxSessionStorageParser>()` (pattern:
     `FirefoxLocalStorageOriginDirectoryHunter.cs` ~line 57)
   - `AddItems` (lines 162-169) takes a `Stream` today. Wrap the file as an `ISourceFile` with lib's existing
     `Magnet.Artifacts.Common/FileFormats/Helpers/SourceFile.cs` (`new SourceFile(searchable, name, extension)`,
     pattern: `BinaryLogs/Hunters/BinaryLogHunter.cs:44`, `FaillogsHunter.cs:44`). So `ReadSessionFile`/`AddItems` pass
     the `ISearchable` (`context.Searchable` or the `IRequestedSearchable`) instead of its stream
   - `parser.Parse(sourceFile).Entries`; type `FirefoxSessionStorageItem` → `IFirefoxSessionStorageEntry` (lines 56,
     143, 162, 165). Keep the `(FilePath, Item)` tuple to keep the diff small
3. **`Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStoreParsedHunter.cs`** (lines 32-55):
   - get `IFirefoxSessionStoreParser` via DI, wrap `context.Searchable` in `SourceFile`, call `Parse(sourceFile)`
     instead of `FirefoxSessionFileReader.ReadJson(...)` + `new SessionStoreParser(Logger)`
   - drop the `if (data == null) yield break;` (the parser handles it, returns empty)
   - keep the `about:` filter (line 42) and the fragments; `item.Path` → `item.Location` (line 55)
4. **`Magnet.Artifacts/Firefox/Helpers/FirefoxSessionStorageMerger.cs`** (lines 18, 27) + `FirefoxSessionStorageMergerTests.cs`
   (`CreateItem`, line 45): type → `IFirefoxSessionStorageEntry`. **Catch:** the FileFormats record is internal, so the
   test needs a tiny test-only class implementing `IFirefoxSessionStorageEntry` (incl. `SessionId`, `Source`, `Offset`), or a Moq mock.
5. **Delete** (all only on the CARS-2272 branch; the reader + Session Storage parser were never merged to `fury`):
   - `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionFileReader.cs`
   - `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionStorageParser.cs` (also holds the `FirefoxSessionStorageItem` record)
   - `Magnet.Artifacts/Firefox/Hunters/SessionStoreParser.cs` (`SessionStoreParser` + `SessionStoreItem`, existing code from `fury`)
   - `Magnet.Artifacts.Tests/Artifacts/Firefox/FirefoxSessionFileReaderTests.cs`, `FirefoxSessionStorageParserTests.cs`
   - in `Magnet.Artifacts.Tests/Artifacts/Firefox/SessionStoreTests.cs`: delete only `Parser_Success` + `AssertItems`
     (moved to FileFormats). **Keep `Hunter_Plaform_Validate`** (it tests the hunter)
   - `Magnet.Artifacts/Firefox/FirefoxSessionStorage.md` (FileFormats `FireFox/SessionStore/README.md` replaces it)
   - check whether `artifact-testdata/Firefox/SessionStore/sessionstore.js` is still used by anything else before deleting it (FileFormats has its own copy now)
6. **Remove `Lz4`** from `Magnet.Artifacts.Common/Logging/Enums/DataFormat.cs` if nothing else uses it. Also check
   whether `GeneralCompressionHelper.Lz4Decompress` is still used elsewhere (don't delete it if it is).
7. Build, Ben runs tests in Test Explorer (merger tests, `SessionStoreTests`, Firefox hunter tests, whole suite).
8. AR2 `Computer:Firefox` and `macOS:Firefox`. Expect the same as the last CARS-2272 run (Lib debrief notes section 5):
   Session Storage +17, SessionStore +34 / −28, Mac no changes. **Locations must be identical** (both parsers keep the
   same JSON paths). AR gotcha for prerelease packages: "Getting the PR package" further down.

**Known, no action:** for files over 2 GiB, lib's `SourceFile.Stream` returns the searchable's own stream and the
FileFormats reader disposes it. Session files are a few MB. **Known limitation (README):** Session Store `Referrer`
is likely null on current Firefox (`referrerInfo` vs `referrer`), same as before the move.

### How Ben works (short version, full list in the sections below)
- Plan first, numbered, plain words. Wait for a clear "do it". One file at a time, explain input → output.
- Don't build or run tests. Ben runs tests in VS Test Explorer: name the test classes.
- Give git commands, never run them. After every decent change: `git add <those files>` + `git commit -m "..."`, short
  lowercase, no ticket number, no AI attribution. Never `git add .`.
- **Moving code: copy exactly, don't optimize what works.** Flag problems instead of fixing them.
- Explain tests and code in plain words, avoid jargon. Short lowercase casual drafts for Slack/PR replies.

---

## CARS-2285 PR review + next work (2026-11-19 → 11-24)

FileFormats PR **!111540** (`pkg-magnet-fileformats`, branch `CARS-2285` → `fury`):
https://dev.azure.com/gauss-dev/Magnet/_git/pkg-magnet-fileformats/pullrequest/111540
Reviewers so far: Veronica Spicer (Forensics Spice), Eric Hornby. Lib PR for CARS-2272 is !110739.

### Where it's at (2026-11-24)

- **Session Store parser move is written (FileFormats side), not yet built/tested by Claude.** Done in 3 commits:
  A) `make session file reader internal` + parser (`IFirefoxSessionStoreParser`, `FirefoxSessionStoreParser`, DI line,
  `IFirefoxSessionStoreEntry`, `FirefoxSessionStoreEntry`), B) tests (`Testdata/SessionStore/sessionstore.js` copied from
  lib `artifact-testdata/Firefox/SessionStore/`, csproj `None Include="Testdata\SessionStore\**\*"`,
  `FirefoxSessionStoreParserTests.Parser_Success`), C) README + these notes.
- **Ben's rule for the move: copy lib's code as exactly as possible, don't optimize what works.** The parser keeps
  lib's `URL`/`Title` constants, `"referrer"` inline, instance `ExtractString`/`ExtractSessionItems`, lib comments,
  `JsonConvert.DeserializeObject` with default settings (so **dates in titles behave like lib**, decision closed), and
  `yield return`. Only added: outer `Parse(ISourceFile)` (reader → null check like the hunter's line 35 → lib's
  `Parse(json)` made private → `.ToList()`), DI constructor, `_logger?.Debug` → `_logger?.LogDebug(e, "Couldn't parse
  SessionStore JSON {Path}", path)`, `SessionStoreItem` → `FirefoxSessionStoreEntry` (`Path` → `Location`, plus
  `Source`, `Offset = 0`), doc comment + Firefox link (`SessionHistory.serializeEntry`, checked on searchfox).
- **Found, not fixed (kept as moved):** current Firefox writes `referrerInfo`, not `referrer`, so `Referrer` is likely
  null on current files. In the README limitations. Possible follow-up.
- Ben to build and run all `FireFox.SessionStore` tests in Test Explorer (reader, Session Storage parser, Session Store
  parser), since the reader became internal and the epoch parser/line-break/inline changes weren't run either.
- All PR review comments below are handled. The reader-internal one is handled by this move.
- **Vedant's comment (2026-11-24, README "Where the items are"):** session files hold other session/tab info too, so return
  a result object instead of a list so a future ticket can add those artifacts. **Done:** `IFirefoxSessionStorageParser.Parse`
  now returns `IFirefoxSessionStorageResult` (new, `Api/Models/FireFox/`) with `IReadOnlyList<IFirefoxSessionStorageEntry> Entries`,
  backed by internal record `FirefoxSessionStorageResult`. Same idea as Local Storage's `IFirefoxLocalStorageResultSet`.
  Tests and runner read `.Entries`. **Lib impact:** the Session Storage hunter uses `parser.Parse(file).Entries`.
  Reply: "good call, changed it to return an IFirefoxSessionStorageResult with Entries for now so we can add tab/session info in a follow up without breaking the interface"

### Review comments and what we did

| # | Who | File | Comment | Outcome |
|---|---|---|---|---|
| 1 | Veronica | `IFirefoxSessionStorageEntry.cs` | link to `Api/Models/SessionStorage/ISessionStorageEntry.cs` | **Done.** Entry now extends the shared `ISessionStorageEntry` (like `IChromiumSessionStorageEntry`). `Origin`/`Key`/`Value`/`SessionId` come from it, Firefox adds `LastAccessed`, `Location`. `SessionId` always null (no per-tab id in the file), documented on the interface + README |
| 2 | Veronica | `IFirefoxSessionFileReader.cs` | rename `ReadJson` to `Parse`, or if it only reads JSON make it internal | **Becomes new work.** Slack thread below. Decision: move the Session Store title/URL parser to FileFormats as well, then the reader is internal |
| 3 | Veronica | `FirefoxSessionFileReader.cs` | `ReadAllBytes`: "is this... necessary?" | **Done.** Read as "does it need its own function". Inlined into `ReadJson` (same `MemoryStream` copy, option 1). Reply: "nope, inlined it since it was only used once" |
| 4 | Veronica + Eric +1 | `FirefoxSessionStorageParser.cs` | "nit but use System.Text.Json pls" | **Keep Newtonsoft.** Eric on Slack (after seeing Vedant's 11:23 screenshot): "if it's a big lift then yea i'd just throw a comment on the PR saying that and go ahead with newtonsoft... definitely don't want to be rewriting all the json handling code as a side effect". Reasons: FileFormats has zero STJ (27 files use Newtonsoft), Location comes from `JToken.Path`, STJ's `JsonNode.GetPath()` formats as `$.windows[0]...` so every Location would change. STJ = follow-up. (Eric: STJ came out ~2019 with .NET Core 3.0, strong opinions both ways) |
| 5 | Veronica | `FirefoxSessionStorageParser.cs` | `AddSession`: "seems unnecessary" | **Done.** Inlined: `Parse` calls `AddWindows` for `windows` + `_closedWindows`, then again under `lastSessionState`. Reply: "inlined it" |
| 6 | Veronica | `FirefoxSessionStorageParser.cs` | `ToDateTime`: "use datetime pkg pls" | **Done.** Uses `IEpochDatetimeParser` from `Magnet.Datetime` via DI: `TryParse((decimal)ms, Epoch.Unix, Resolution.Milliseconds, out IDatetimeRecord record)` → `record.DateTimeOffset`. Same pattern as `FirefoxOriginMetadataV2Parser`. `AddWindows`/`AddTab`/`ToDateTime` no longer `static` (they use `_epochParser`). Test passes `TestEpoch.NewParser()`. Reply: "switched to the epoch parser from magnet.datetime" |
| 7 | Eric | `FirefoxSessionStorageParser.cs` | "Nit, linebreaks pls" (long `if`) | **Done.** `ToDateTime`'s `if` split one `&&` condition per line. Reply: "done". Reviewer asking for breaks overrides Ben's one-line style, only where asked |
| 8 | Eric | `FirefoxSessionFileReader.cs` | return partial decompressed data instead of null? | **Replied, no change (unless Eric wants it).** "we could, but it wouldn't be useful here. even if we returned the partial text, half a json file can't be parsed, so it'd get thrown out anyway and we'd still get no items. happy to add it regardless though if you think it's worth it, what do you think?" Background: K4os `LZ4Codec.Decode` returns -1 on corrupt data, so we can't tell how much is good |

### Slack thread with Veronica on comment 2 (2026-11-23)

- Ben: lib has its own copy of the reader right now, pretty much the same code. Plan was to switch the Session Store
  hunter to the FileFormats `ReadJson` and delete the lib copy.
- Veronica: "generally we only expose the single Parser (except for IndexedDB just to provide a querying interface).
  is there a way to encapsulate the JSON reading within the main parser so that interface doesn't need to be called
  outside of FF?"
- Ben: move the Session Store title/URL parser into FileFormats as well, matching the Session Storage key/value
  parser, then the reader can be internal. Veronica: makes sense. Ben: in retrospect it makes more sense for both to
  live in FileFormats together. Veronica: "hindsight is 20/20". Ben: "haha i feel that" / "thanks for the help!"
- Why it makes more sense: both parsers read the same session store file (one pulls Session Storage key/values, the
  other tab titles/URLs), so all session file format code lives in one place and lib only keeps Axiom logic.

### Session Store parser move (DONE 2026-11-24, see "Where it's at"; the plan below is kept for history)

Source: lib `Magnet.Artifacts/Firefox/Hunters/SessionStoreParser.cs` (~110 lines, `SessionStoreParser` +
`SessionStoreItem(Title, Url, Referrer, Path)`), test `Magnet.Artifacts.Tests/Artifacts/Firefox/SessionStoreTests.cs`
(expects e.g. `("Welcome to Firefox", "https://www.mozilla.org/en-US/firefox/41.0.1/firstrun/", "windows[0].tabs[0].entries[0]")`).
How it works: `JsonConvert.DeserializeObject` the JSON, then recursively walk every object and return any object that
has both a child path ending in `url` and one ending in `title` (stops descending there). Reads `url`, `title`,
`referrer` via `ExtractString` (first child whose path ends with the key). `item.Path` is the JSON path.

**Stays in lib:** the hunter (`FirefoxSessionStoreParsedHunter`), including its "skip `about:` URLs" rule (line 42),
because that's about what Axiom shows, not the format.

Steps (FileFormats):
1. **Reader internal**: move `IFirefoxSessionFileReader` from `Api/Parsers/` to `FireFox/SessionStore/`, make it
   `internal`. DI registration, parser and tests keep working (`InternalsVisibleTo` tests + `DynamicProxyGenAssembly2`).
2. **Entry interface** (new, public) `Api/Models/FireFox/IFirefoxSessionStoreEntry.cs`: `Title`, `Url`, `Referrer`,
   `Location` (lib called it `Path`, renamed to match the Session Storage entry), `Source`, `Offset` (always 0).
3. **Entry record** (new, internal) `FireFox/SessionStore/FirefoxSessionStoreEntry.cs`.
4. **Parser interface** (new, public) `Api/Parsers/IFirefoxSessionStoreParser.cs`: `IReadOnlyList<IFirefoxSessionStoreEntry> Parse(ISourceFile sessionFile)`.
5. **Parser** (moved) `FireFox/SessionStore/FirefoxSessionStoreParser.cs`: same search, calls the reader first, reader +
   `ILogger<T>` via DI, plain warnings (lib used `Debug`), named constants.
6. **DI**: one line in `FileFormatsServiceExtensions.cs`.
7. **Tests** (moved): lib `SessionStoreTests` adapted (fake file, fake reader, `AssertionScope`).
8. **README, these notes, PR description**: both parsers live here, reader internal.

**Open decision: dates in titles.** Lib uses `JsonConvert.DeserializeObject` with default settings, which turns
date-looking text into dates (a title `2026-11-09T15:12:36Z` would come back reformatted). Options: keep identical to
lib (safest for AR2), or use `DateParseHandling.None` like the Session Storage parser (Claude's pick: shown exactly
as stored, date-like titles are very rare). Ben hasn't picked yet.

Optional (Claude suggested skipping unless wanted for the debrief): runner output for titles/URLs.

**Lib side changes because of this** (CARS-2272 step 2, updated): the Session Store hunter calls
`IFirefoxSessionStoreParser.Parse(sourceFile)` instead of `ReadJson` + its own parser, keeps the `about:` filter,
`item.Path` → `item.Location`. Delete lib `SessionStoreParser.cs` and `SessionStoreTests.cs` too.

### Explanations given to Ben this chat (for reuse)

**Pieces CARS-2272 built (lib) and where they end up:**

| Piece | Job | After CARS-2285 |
|---|---|---|
| File list (`FirefoxSessionFiles`) | which files Axiom looks at | stays in lib |
| Reader (`FirefoxSessionFileReader`) | file → JSON text (decompress) | FileFormats, internal |
| Session Storage parser | JSON → key/value items | FileFormats |
| Session Store title/URL parser (`SessionStoreParser`, older, not from 2272) | JSON → titles/URLs | FileFormats (new work) |
| Merger (`FirefoxSessionStorageMerger`) | same item across files → 1 hit | stays in lib |
| Hunters (Session Storage, Session Store) | run the above, make Axiom hits | stay in lib |

Rule of thumb: FileFormats = reading the file format, lib = what Axiom does with it.

**"Missing files" confusion:** the old Session Store hunter (before CARS-2272) missed `sessionstore.jsonlz4`. CARS-2272
already fixed it (shared file list `FirefoxSessionFiles` + new reader). Nothing is wrong with lib's current reader, it's
the same code that moved. Switching lib to FileFormats is only so there's one copy, not two.

**`internal` vs `public`:** internal = only code inside the FileFormats project can see it. Lib uses FileFormats as a
package, so it can't call internal types (`InternalsVisibleTo` only covers FileFormats tests, runner, MCP server).

**`static`:** a static function can't use anything stored on the object (like `_epochParser`), only its arguments.
Chain `Parse → AddWindows → AddTab → ToDateTime → _epochParser`, so all three lost `static`.

**How the Session Storage parser walks the JSON** (talk track for debrief section 2):
> "the parser walks down the JSON. first it's split into windows and closed windows [Parse]. each window has tabs and
> closed tabs [AddWindows], and every tab goes to AddTab. in AddTab, each tab has a storage section split by website,
> and each key under a website is one session storage entry. this is where we actually get the data: website, key,
> value, the tab's last accessed time, and the JSON path as the location"

4 levels: windows (`windows`, `_closedWindows`, and again under `lastSessionState`) → tabs (`tabs`,
`_closedTabs[].state`) → websites (`storage` keys) → keys (one entry each).

### How Ben works (additions this chat)

- When Ben pastes a PR comment: explain what it means in plain English, give options (before/after code when it's a
  code change), recommend one, draft a reply. Don't change code until he picks.
- Comments can be read two ways (e.g. "is this necessary?" = the function, not the code). Ask/offer both, Ben decides.
- Slack/PR replies: short, lowercase, casual, Ben's voice. Not condescending, keep it about his own code. Ben tweaks
  wording himself, so offer 1-2 short versions.
- Line breaks only where a reviewer asks; one-line style everywhere else.

---

## CARS-2285 done → CARS-2272 step 2 (lib) — start here

Written 2026-11-19 at the end of the FileFormats chat, for a new chat opened in the lib repo. The FileFormats side
(CARS-2285) is written, all tests pass, and it's pushed. Next: make lib (CARS-2272) use the FileFormats PR package.
The older "CARS-2285 handoff" section below is the original brief and is still the source for the rules.

### How Ben works (same as below, plus)

- Everything in "How Ben works" in the CARS-2285 handoff section still applies: plan first, number the changes, wait
  for a clear "do it", plain short answers, no builds/tests unless asked, give git commands instead of running them,
  casual lowercase commits, no AI attribution lines.
- **One file at a time.** Explain the change (input → output), wait for OK, write it, then move to the next.
- **Give git commands after every decent size change**, unprompted: `git add <those files>` + `git commit -m "..."`.
  Never `git add .`, Ben keeps untracked scratch files.
- **After writing tests, explain what each one tests in plain words** (what goes in, what it proves). Avoid jargon
  like "Moq logger" without explaining it ("a pretend logger that remembers warnings so the test can check them").
- When Ben asks "what does X do", trace it: input and output first, then each code block, then a worked example.
- Ben runs tests in VS Test Explorer: name the test classes to run.

### What was built in FileFormats (branch `CARS-2285`, pushed)

All under `D:\code\pkg-magnet-fileformats`. Folder `Magnet.FileFormats/FireFox/SessionStore/` (named after the file
Firefox calls "session store", because the reader serves both hunters, not only Session Storage).

| File | What it is |
|---|---|
| `Api/Parsers/IFirefoxSessionFileReader.cs` | Public for now, **moving to `FireFox/SessionStore/` as internal** (review). `string ReadJson(ISourceFile sessionFile)`: session file in, JSON text out, null if encrypted/broken (logged) |
| `FireFox/SessionStore/FirefoxSessionFileReader.cs` | `internal sealed`, `ILogger<T>` via DI. Checks first bytes: `mozEnc` → warn + null; `mozLz40\0` → size at byte 8, K4os `LZ4Codec.Decode` from byte 12, null + warn if bytes written ≠ header size; else plain UTF-8. Opens and disposes the stream itself (`ISourceFile.Stream` makes a new stream per call, caller disposes) |
| `Api/Models/FireFox/IFirefoxSessionStorageEntry.cs` | Public entry, extends `ISessionStorageEntry` since review (adds `SessionId`, always null). Fields: `Origin`, `Key`, `Value`, `LastAccessed` (`DateTimeOffset?`), `Location`, plus `Source` (file path) and `Offset` (always 0) |
| `FireFox/SessionStore/FirefoxSessionStorageEntry.cs` | `internal sealed record` with `{ get; init; }`. **Internal, so lib cannot `new` it** |
| `Api/Parsers/IFirefoxSessionStorageParser.cs` | Public. `IReadOnlyList<IFirefoxSessionStorageEntry> Parse(ISourceFile sessionFile)`, never null |
| `FireFox/SessionStore/FirefoxSessionStorageParser.cs` | `internal sealed`, gets the reader + `IEpochDatetimeParser` + `ILogger<T>` via DI (epoch parser added in review). Calls the reader, then the same JSON walk as lib (Newtonsoft, `DateParseHandling.None`, `JToken.Path`). JSON names are named constants. Invalid JSON → one warning, empty list |
| `Common/Extensions/FileFormatsServiceExtensions.cs` | Registers both as singletons, after `IFirefoxLocalStorageParser` |
| `FireFox/SessionStore/README.md` | Lib `FirefoxSessionStorage.md` moved, plus searchfox links and an "In this repo" section. The "items are merged" sentence now says merging is up to the caller |
| `Magnet.FileFormats.Tests/FireFox/SessionStore/FirefoxSessionFileReaderTests.cs` | 7 tests: mozLz4, plain text, encrypted, header cut off, corrupt data, size too large (new), null file (new) |
| `Magnet.FileFormats.Tests/FireFox/SessionStore/FirefoxSessionStorageParserTests.cs` | 4 tests: every tab location (exact paths + Source + Offset 0), date-like + broken text, invalid JSON, reader returns null (new). Uses a fake (Moq) reader so it only tests the JSON walk |

Tests use Moq `ISourceFile` + `Mock<ILogger<T>>` checked with the repo's `VerifyLogging` helper
(`Magnet.FileFormats.Tests/Utilities/LoggingMockExtensions.cs`), assertions inside `AssertionScope`. Behaviour is the
same as lib except: null file now logs a warning (lib returned null silently), and no try/catch around LZ4 (K4os
returns a negative number instead of throwing).

### Decisions made (2026-11-18/19)

1. ~~**Reader is public too**~~ (superseded by 9: reader becomes internal, Session Store parser moves to FileFormats).
2. **Offset is always 0.** Items come from decompressed JSON, so there is no byte position in the file. `Location`
   (the JSON path) says where the item is. Documented in the XML docs and README. Explained to Ben as: offset is
   "a page number in the file", and a compressed file has no page number for the item.
3. **Parser takes `ISourceFile`** and calls the reader itself (matches `IUtmpParser`, `IFaillogParser`,
   `ISpotlightParser`), so callers don't pass JSON text around and `Source` is always set by the parser.
4. **FileFormatsRunner command added after all** (2026-11-19, for the FileFormats debrief and running on Ben's own
   Firefox): `ffss <profile> -o ffss.txt [-j <json-dir>]` (`FileFormatsRunner/Options/FirefoxSessionStorageOptions.cs`,
   `Runners/FirefoxSessionStorageRunner.cs`, `Program.cs`, `CLAUDE.md`, root `README.md`). Reads `sessionstore.*` in
   the profile + every file in `sessionstore-backups\`. Per file: size, first 16 bytes (hex + text, shows `mozLz40`),
   JSON length, items (Origin, Key, Value, Last Accessed, Location, Source, Offset), not merged. `-j` saves each file's
   JSON indented (dates kept as text) so a Location can be found in it. Copy the profile (Firefox closed) for demos.
   **Separate debriefs**: one for the FileFormats work (use the runner), one for the lib work.
7. **Newtonsoft stays, again** (2026-11-20). Veronica: "nit but use System.Text.Json pls", Eric +1. Eric on Slack after seeing Vedant's 11:23 decision: "if it's a big lift then yea i'd just throw a comment on the PR saying that and go ahead with newtonsoft". Reasons given: FileFormats uses Newtonsoft everywhere (no STJ in the library), and Location comes from `JToken.Path`. STJ does have `JsonNode.GetPath()` but formats it as `$.windows[0]...`, so every Location would change. STJ = follow-up ticket.
8. **`ReadAllBytes` inlined** into `ReadJson` (Veronica: "is this... necessary?", read as "does it need to be its own function"). Same MemoryStream copy, just moved.
9. **Reader becomes internal (2026-11-23, replaces decision 1):** Veronica: FileFormats only exposes parsers. Agreed on Slack to move lib's Session Store title/URL parser into FileFormats too, then the reader is internal. See "Session Store parser move" in the START HERE section.
10. **Time via `Magnet.Datetime`** (`IEpochDatetimeParser`), not `DateTimeOffset.FromUnixTimeMilliseconds` (Veronica).
11. **`AddSession` inlined** (Veronica).
6. **Entry extends the shared `ISessionStorageEntry`** (Veronica's PR comment, 2026-11-19), like `IChromiumSessionStorageEntry`. `Origin`/`Key`/`Value`/`SessionId` come from it; Firefox adds `LastAccessed` and `Location`. `SessionId` is always null (no per-tab id in the session file). For lib, nothing changes, since the names are the same.
5. Property names kept the same as the lib item (`Origin`, `Key`, `Value`, `LastAccessed`, `Location`) so lib barely
   changes. Entry interface named `IFirefoxSessionStorageEntry` to match Local Storage.

### FileFormats PR (open it first, if not done yet)

Target `fury`. Text Ben approved:

**Title:** `CARS-2285: add firefox session file reader and session storage parser`

- moved the firefox session file reader and session storage parser from lib (CARS-2272) into FileFormats, same behaviour
- reader handles mozLz4, plain json (old firefox) and skips encrypted files
- parser returns website, key, value, tab last accessed and json path per item. offset is always 0 since items come from decompressed json, use Location
- public interfaces + DI registration, same pattern as firefox local storage
- reader + parser tests and readme moved over, plus 3 new tests for the null / too big cases
- new runner command `ffss` to parse a firefox profile's session files and optionally save the json
- moved the session store title/url parser into fileformats too (same logic as lib), reader is now internal so artifacts only calls the two parsers

### Getting the PR package

- Opening the PR runs `pipelines/azure-pipelines.yml`, which publishes a **prerelease** to the Engineering feed named
  `<AssemblyVersion>.<patch>-PullRequest<PR id>.<build>`, e.g. `8.0.5-PullRequest111500.0` (`AssemblyVersion` is `8.0`
  in `Directory.Build.props`). Get the exact version from the PR pipeline log ("Packing NuGet") or the feed.
- Local lib build + unit tests can use that version directly in `Directory.Packages.props`.
- **AR2 gotcha** (FileFormats `Magnet.FileFormats/README.md`, "Testing Gotcha"): a FileFormats prerelease doesn't reach
  AR through Artifacts directly. For AR: make a prebuild Artifacts package from the lib PR, swap Axiom's Artifacts
  references to it (dngrep), push an Axiom PR with `+archive_process`, use that build in AR, abandon both PRs after.
  If Ben ran AR2 for CARS-2272 another way before, that route should still work with the new package.

### CARS-2272 step 2: lib changes (SUPERSEDED by "LIB CHAT — START HERE" at the top, kept for history)

Checked every lib use of the old code on 2026-11-19.

1. **Package version**: `Directory.Packages.props:49`, `Magnet.FileFormats` `8.0.1` → the PR prerelease version.
2. **`Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStorageHunter.cs`**:
   - get the parser via `FeatureServiceProvider.GetRequiredService<IFirefoxSessionStorageParser>()` (pattern:
     `FirefoxLocalStorageOriginDirectoryHunter.cs` ~line 57)
   - `AddItems` (lines 162-169) currently takes a `Stream`. Wrap the file as an `ISourceFile` with lib's existing
     `Magnet.Artifacts.Common/FileFormats/Helpers/SourceFile.cs` (`new SourceFile(searchable, name, extension)`,
     pattern: `BinaryLogs/Hunters/BinaryLogHunter.cs:44`, `FaillogsHunter.cs:44`). So `ReadSessionFile`/`AddItems`
     pass the `ISearchable` (`context.Searchable` or the `IRequestedSearchable`) instead of its stream.
   - call `parser.Parse(sourceFile).Entries` (returns `IFirefoxSessionStorageResult` since Vedant's review); item type `FirefoxSessionStorageItem` → `IFirefoxSessionStorageEntry`
     (lines 56, 143, 162, 165). The `(FilePath, Item)` tuple can stay as is to keep the diff small (entry `Source`
     also has the path).
3. **`Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStoreParsedHunter.cs:34`** (UPDATED 2026-11-23): get
   `IFirefoxSessionStoreParser` via DI, wrap `context.Searchable` in `SourceFile`, call `Parse(sourceFile)` instead of
   `ReadJson` + lib's `SessionStoreParser`. Keep the `about:` filter. `item.Path` → `item.Location`.
   Also delete lib `Magnet.Artifacts/Firefox/Hunters/SessionStoreParser.cs` and `Magnet.Artifacts.Tests/Artifacts/Firefox/SessionStoreTests.cs`.
4. **`Magnet.Artifacts/Firefox/Helpers/FirefoxSessionStorageMerger.cs`** (lines 18, 27) + `FirefoxSessionStorageMergerTests.cs`
   (`CreateItem`, line 45): type → `IFirefoxSessionStorageEntry`. **Catch:** the FileFormats record is internal, so the
   test needs a tiny test-only class implementing `IFirefoxSessionStorageEntry`, or a Moq mock.
5. **Delete**: `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionFileReader.cs`, `FirefoxSessionStorageParser.cs`
   (also holds the `FirefoxSessionStorageItem` record), `Magnet.Artifacts.Tests/Artifacts/Firefox/FirefoxSessionFileReaderTests.cs`,
   `FirefoxSessionStorageParserTests.cs`, and `Magnet.Artifacts/Firefox/FirefoxSessionStorage.md` (FileFormats README replaces it).
6. **Remove `Lz4`** from `Magnet.Artifacts.Common/Logging/Enums/DataFormat.cs`. Only the old reader used it (grep on
   2026-11-19). Re-check before deleting.

Then: build lib, run tests in Test Explorer (merger tests, Firefox hunter tests, whole suite), then AR2
`Computer:Firefox` and `macOS:Firefox`. Expect the same as before (Debrief notes section 5): Session Storage +17,
SessionStore +34 / −28, Mac no changes. **Locations must be identical.**

**Small known thing (no action):** for files over 2 GiB, lib's `SourceFile.Stream` returns the searchable's own
stream instead of a copy, and the FileFormats reader disposes the stream it gets, so it would close the hunter's
stream. Session files are a few MB at most, so it won't happen. Mention only if a reviewer asks.

### Gotchas from the FileFormats chat

- **VS build errors MSB3027/MSB3021/CS0006** ("file is locked by Magnet.FileFormats.McpServer"): the Claude Code
  magnet-fileformats MCP server runs from `bin\Debug` and locks the DLL. Disable it via `/mcp` or end the process in
  Task Manager, then Rebuild. Not a code problem. The 101 warnings were already there.
- Firefox source paths checked on searchfox: `xpcom/ioutils/IOUtils.h` (`IOUtils::MozLZ4`, `IOUtils::Encryption`,
  both `MAGIC_NUMBER`), `browser/components/sessionstore/TabState.sys.mjs` (`TabStateData`, `copyFromCache`).

### Standup line used (2026-11-19)

- moved cars-2272 to blocked while i move the firefox session file reader and session storage parser into fileformats
- working on cars-2285 (fileformats side). code + tests written, building and running tests now, then opening the pr

---

## CARS-2285 handoff (FileFormats)

Written 2026-11-18 for a new chat opened in the FileFormats repo. Everything needed to do CARS-2285 is in this
section. The rest of this file is background.

### How Ben works (read first)

- **Plan before editing.** List every change in plain words, number them, wait for an OK. Agreeing with an idea
  ("I think X is easier") is **not** a go-ahead. Only edit on a clear "do it" / "make the change".
- **Plain language, short answers.** Big picture first, then step by step with input → output. Define unfamiliar
  terms. Ben says when an answer is too long.
- **Don't build or run tests** unless asked. Ben runs tests in **Visual Studio Test Explorer**: name the tests to run,
  no `dotnet test` commands.
- **Git: give the commands, don't run them.** Casual lowercase commit messages, e.g. `add session file reader`.
  No AI attribution lines (no "Generated with Claude Code", no Co-Authored-By) in commits or PRs.
- **Messages to people** (Slack, PR replies): short, lowercase, casual.
- Keep scope tight: only what was asked.

### The ticket

**CARS-2285 "Add Firefox session file parser to FileFormats"**, blocks CARS-2272. Raised by Veronica Spicer
(Forensics Spice) on the CARS-2272 PR: the session file reader/parser belongs in FileFormats with the other Firefox
format readers (Local Storage, IndexedDB, Cache2). She agreed it's net new, so: new FileFormats ticket, CARS-2272
blocked on it, add to FileFormats now.

Ticket AC (as written in Jira):
- Session file reader in FileFormats: mozLz4, plain JSON, detects encrypted files and skips them
- Session Storage parser in FileFormats: returns each item's website, key, value, tab last accessed time and JSON location
- Public interfaces + DI registration, same as Firefox Local Storage
- Unit tests and format README moved over
- New FileFormats package version for CARS-2272 to use

**Goal: move, not rewrite.** The logic is done and tested in CARS-2272. Same behaviour, FileFormats packaging.

### Repos and branches

| Repo | Path | Branch | State |
|---|---|---|---|
| FileFormats | `D:\code\pkg-magnet-fileformats` | `CARS-2285` (created from `fury`) | empty, nothing done yet. Untracked `ffls.txt` is Ben's, leave it |
| Artifacts (lib) | `D:\code\lib-magnet-artifacts` | `CARS-2272` | PR [!110739](https://dev.azure.com/gauss-dev/Magnet/_git/lib-magnet-artifacts/pullrequest/110739), last commit `25f24591aa`. Uses `Magnet.FileFormats` **8.0.1** (`Directory.Packages.props:49`) |

### What moves (lib → FileFormats)

All paths in the lib repo. Read these first, they are the source to port.

| Lib file | Lines | Moves? | What it does |
|---|---|---|---|
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionFileReader.cs` | 98 | **Yes** | File → JSON text. `mozEnc` prefix → log + null. `mozLz40\0` → 4-byte LE size at byte 8, raw LZ4 block from byte 12. Else plain UTF-8 (old Firefox). Picks by header, not name |
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionStorageParser.cs` | 146 | **Yes** | JSON → items. Newtonsoft, `DateParseHandling.None`. Walks `windows[].tabs[]`, `windows[]._closedTabs[].state`, `_closedWindows[]`, and the same under `lastSessionState`. Item = Origin, Key, Value, LastAccessed (tab `lastAccessed`, ms since 1970 UTC), Location (`JToken.Path`) |
| `Magnet.Artifacts/Firefox/FirefoxSessionStorage.md` | 49 | **Yes**, as the format `README.md` | Format doc |
| `Magnet.Artifacts.Tests/Artifacts/Firefox/FirefoxSessionFileReaderTests.cs` | 104 | **Yes** | 5 tests: mozLz4, plain, encrypted, header cut off, corrupt data |
| `Magnet.Artifacts.Tests/Artifacts/Firefox/FirefoxSessionStorageParserTests.cs` | 89 | **Yes** | 3 tests: every tab location (asserts exact paths), date-like + broken text values, invalid JSON |
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionStorageMerger.cs` (+ tests) | 63 | **No** | Merges items across a profile's files. Artifact logic |
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionFiles.cs` (+ tests) | 75 | **No** | Hunter file registration + CFLs |
| `Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStorageHunter.cs` | | **No**, but changes in step 2 | Calls reader + parser at lines 164-165 |
| `Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStoreParsedHunter.cs` | | **No**, but changes in step 2 | Calls the reader only (line 34), then its own `SessionStoreParser` (Title/URL) |

### What must change when it moves (FileFormats rules)

Read in the FileFormats repo: `CLAUDE.md`, `docs/FORMAT_DEVELOPMENT_CHECKLIST.md`, `docs/CODING_STANDARDS.md`,
`docs/ARCHITECTURE_AND_API_GUIDE.md`, `docs/CONSUMER_FILESYSTEM_INTEGRATION.md`, `docs/TESTING_GUIDE.md`.
Copy the shape of **Firefox Local Storage** (CARS-2225, same author):
`Magnet.FileFormats/FireFox/LocalStorage/` + `Api/Parsers/IFirefoxLocalStorageParser.cs` +
`Api/Models/FireFox/IFirefoxLocalStorage*.cs` + tests in `Magnet.FileFormats.Tests/FireFox/LocalStorage/`.

| Lib version | FileFormats version |
|---|---|
| `internal static class`, called directly | Public interface in `Api/Parsers/`, `internal sealed` class, constructor-injected `ILogger<T>`, registered in `Magnet.FileFormats/Common/Extensions/FileFormatsServiceExtensions.cs` (next to `IFirefoxLocalStorageParser`, ~line 65) |
| Takes a `Stream` + path | Takes `ISourceFile` (`Path`, `Stream`; caller disposes the stream) |
| Lib `LogEvents` (`DecryptionNotSupported`, `FormatParsingFailed`, `FormatParsingException`, `DataFormat.Lz4`) | Plain `_logger?.LogWarning("... {Path}", ...)` like `FirefoxLocalStorageParser.cs` |
| `GeneralCompressionHelper.Lz4Decompress` (lib only, lz4net, throws) | `K4os` `LZ4Codec.Decode(src, srcOffset, srcLen, dst, dstOffset, dstLen)`, returns a negative number on failure instead of throwing (see `Apple/Spotlight/SpotlightBlockDecompressor.cs:112`). So the try/catch can probably go |
| Item record with `Location` | Public interface for the entry implementing `ISourceResult` (`Source`, `Offset`) + internal record in its own file (DTOs in separate files) |
| Magic bytes as `u8` literals | Named constants, explicit magic checks (no magic numbers) |
| Doc comments cite `SessionFile.sys.mjs`, `IOUtils.h` etc. | Firefox references as symbols (not line numbers) with `<seealso href>` to `searchfox.org/firefox-main/source/...` |
| Tests use lib `FakeLogger` + `ShouldHaveLoggedEventName` | Use whatever FileFormats tests use for loggers (check `FirefoxLocalStorageParserTests.cs`) |

New folder suggestion: `Magnet.FileFormats/FireFox/SessionStore/` (Firefox calls the files "session store").

### Decisions already made (keep)

- **Keep Newtonsoft** in the parser (FileFormats already references it). Vedant's call 2026-11-18: broken half-emoji
  text (`abc\ud800def`) becomes `abc�def` because Newtonsoft's reader swaps unpaired surrogates for U+FFFD. Known
  limitation, follow-up ticket to come. Do not switch to System.Text.Json: no `JToken.Path` equivalent, paths would
  have to be rebuilt by hand. Test expects `"abc\uFFFDdef"`, keep that.
- **Locations stay `JToken.Path`**, e.g. `windows[0].tabs[3].storage['https://app.box.com']['History.store']`. Not lib
  `JsonLocations` (its line 71 turns every `.` into ` > `, mangling website names). AR2 depends on these strings.
- **Encrypted files** (`mozEnc` prefix, version byte left out so later versions still count): log and skip, not decrypted.
- Date-like strings stay text (`DateParseHandling.None`).
- Value: strings as-is, anything else as compact JSON (`ToString(Formatting.None)`).
- Tests: independent assertions inside `using (new AssertionScope())` (Savan's review comment on CARS-2272).

### Open decisions (RESOLVED 2026-11-19, see "CARS-2285 done" section above)

1. **Make the reader public too** (e.g. `IFirefoxSessionFileReader` returning the JSON text). The old SessionStore
   hunter needs the JSON, not Session Storage items. Proposed: yes.
2. **Offset**: FileFormats wants `Source` + `Offset` on results (ADR-005). Items come from **decompressed** JSON, so
   there is no byte offset in the file. Proposed: `Offset = 0`, keep the JSON path as its own property. Say so in the
   PR and the XML docs.
3. **Parser input**: proposed `Parse(ISourceFile sessionFile)` doing read + parse, so consumers don't pass JSON text
   around. Or keep `Parse(string json, ...)` and let the hunter call the reader. Ben to pick.
4. FileFormatsRunner command (like `firefoxlocalstorage`): optional, only if useful.

### Step 2, back in lib (CARS-2272) after the FileFormats PR

Superseded by the more detailed list in "CARS-2285 done → CARS-2272 step 2" above. Kept for history.

1. Bump `Magnet.FileFormats` in `Directory.Packages.props` (topic package first, release version later).
2. Both hunters get the reader/parser via DI: `FeatureServiceProvider.GetRequiredService<IFirefox...>()`, like
   `FirefoxLocalStorageOriginDirectoryHunter.cs` (~line 57). Wrap the file as an `ISourceFile` the way that hunter
   wraps its directory (`SourceDirectory.Create(...)`). Check how lib builds an `ISourceFile` before writing one.
3. Delete lib `FirefoxSessionFileReader.cs`, `FirefoxSessionStorageParser.cs`, their 2 test files, and
   `FirefoxSessionStorage.md` if the README replaces it.
4. Remove `Lz4` from lib `Magnet.Artifacts.Common/Logging/Enums/DataFormat.cs` if nothing else uses it.
5. Re-run AR2 `Computer:Firefox` and `macOS:Firefox`. Expect the same as before (see Debrief notes, section 5):
   Session Storage +17, SessionStore +34 / −28, Mac no changes. Locations must be identical.

### CARS-2272 status (2026-11-18)

- AR2 done (Computer + Mac), results in Debrief notes section 5. Debrief not done yet.
- Review: Mary approved with art-json suggestions (applied). Savan: AssertionScope (done), "is Newtonsoft intentional"
  (answered: yes, same as old parser + free paths). Veronica: move to FileFormats → **this ticket**.
- Still to create: follow-up ticket for broken half-emoji text. Caleb suggested making it a sweep of all Newtonsoft
  JSON reading in Artifacts (≈591 files) plus one common helper.

---

## CARS-2272 implementation (2026-11-15/16) — start here

Ticket **CARS-2272 "Firefox Session Storage artifact"** (assigned to Ben), follow-up to CARS-1861.
Branch **`CARS-2272`** (from `fury` on 2026-11-15). **All code done, tests pass, AR2 Computer:Firefox
checked.** Not pushed, no PR yet.

### Next steps
1. *(Optional, recommended)* AR2 **macOS:Firefox** too (both hunters are Computer + Mac; CARS-2252 ran
   both). Swap `D:\code\local_ar_config.json` back: Platform `macOS`, EvidencePath
   `D:\data\macOS\Firefox\evidence`, BaselineCaseFolderPath `D:\baseline\macOS\Firefox`, remove
   OptionsFilePath (no macOS options file exists).
2. Push + PR. Claude to write the description (Session Storage artifact, old hunter reads all files,
   upgrade files fixed, encoding fix, AR2 numbers below). Ben creates it in Azure.
3. Offered: end-of-ticket walkthrough doc (file layout + block-by-block trace).

### Decisions made in this chat
| Decision | Choice |
|---|---|
| Hunters | **New** hunter for Session Storage; old SessionStore hunter kept, fixed, shares code with it |
| Shared pieces | One file reader (unzip), one file list (registration + CFLs). No copy-paste |
| Encrypted files (`mozEnc`) | Log `DecryptionNotSupported` (path in the text), skip. Not decrypted |
| Unzip failure log | Added `Lz4` to `DataFormat`, use `FormatParsingFailed` / `FormatParsingException` |
| Upgrade file | Kept (cheap, can be oldest snapshot). Caught by the backups-folder rule |
| Dedupe | **In the hunter**: merge on Origin + Key + Value + Last Accessed (same = one snapshot item repeated; different Last Accessed = different tab) |
| Which file does the work | Hunter runs once per session file; only the **alphabetically first** file of the profile reads all files (others return nothing) |
| Sources column | **File names only**, comma-separated. Named **`Sources`** because `Source` is reserved by Axiom Examine (blackbox test) |
| Origin | Fragment `Origin` (matches Local Storage / Chrome), full string kept incl. `^partitionKey=…` |
| JSON location | Newtonsoft `JToken.Path` (like old parser). `JsonLocations` turns `.` into ` > ` and mangles origins (`JsonLocations.cs:71`) |
| Open vs closed tab, tab URL/title | Not included (Ben's call) |
| Descriptor GUID | `57e6de5bbcaf47f2b5be2960fcd829ef` (Ben provided) |
| Hunter tests | None; rely on AR2 (fake file system would only test our own fake paths) |
| Tests | Simple, one case per decision |

### Commits (oldest first)
1. `5fe3dbda3e` reader + `Lz4` in DataFormat
2. `050bdc91cb` reader tests
3. `d0b9dc257d` old hunter uses shared reader
4. `89fa5443fb` shared registration/CFLs + root `sessionstore.jsonlz4`
5. `ddf910f216` file pattern tests
6. `ad80aa25e9` Session Storage parser
7. `0d1b32af45` parser tests
8. `b70ecc9df8` artifact string + descriptor
9. `6c3ea483d5` `IsSessionFile` + test
10. `f77de99069` merger
11. `64330d3317` merger tests
12. `623211f684` hunter + artifact class
13. `f2b74f6d3f` art-jsons
14. `b69c877755` rename Source → Sources

### Files and what each does
**Chain:** session file → `FirefoxSessionFileReader` (JSON text) → `FirefoxSessionStorageParser` (items) →
`FirefoxSessionStorageMerger` (merged items) → `FirefoxSessionStorageHunter` (Axiom rows).

| File | What it does |
|---|---|
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionFileReader.cs` | `ReadJson(stream, path, logger)` → JSON text or null. By first bytes: `mozEnc` → log + null; `mozLz40\0` → read size at byte 8, unzip from byte 12; else plain UTF-8 (old Firefox) |
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionFiles.cs` | Which files are session files. `Register` (exact names `sessionstore.jsonlz4`/`.js`/`.bak` + regex `sessionstore.bak-<digits>` + any file directly in `sessionstore-backups\`), `GetCommonlyFoundLocations` (typo `.back` fixed), `IsSessionFile(path)` (same rules) |
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionStorageParser.cs` | `Parse(json, path, logger)` → items (Origin, Key, Value, LastAccessed, Location). Walks `windows[].tabs[]`, `windows[]._closedTabs[].state`, `_closedWindows[]`, `lastSessionState`. `DateParseHandling.None` keeps date-like values as text. Bad JSON → log `FormatParsingException` |
| `Magnet.Artifacts/Firefox/Helpers/FirefoxSessionStorageMerger.cs` | `Merge((filePath, item)…)` → one merged item per Origin+Key+Value+LastAccessed, `FoundAt` = every (file, location). Line 42 adds the location whether the row is new or existing |
| `Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStorageHunter.cs` | Builds the profile's sorted session file list (profile = file's folder, or one up from `sessionstore-backups`); stops unless current file is #1; reads all files (current via `context`, others via `Gatherer.RequestFile`), merges, one hit per item with every fragment pointing to all locations |
| `Magnet.Artifacts/Firefox/FirefoxSessionStorage.cs` | Artifact: Key, Value, Origin, Last Accessed (all `.Dedupe()`), Sources (not dedupe). WebDisplayOrder + SuperTimeline BrowserUsage, NoConnections. Copied from Local Storage |
| `Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStoreParsedHunter.cs` (changed) | Old hunter: own unzip code deleted, uses reader + shared registration/CFLs |
| `Magnet.Artifacts.Common/Logging/Enums/DataFormat.cs` | `Lz4` added |
| `Magnet.Artifacts.Common/Metadata/ArtifactDescriptors.cs` | `FirefoxSessionStorage` descriptor |
| `ArtifactStrings.resx` + 2 Designer files | `Artifact_Firefox_Session_Storage` = "Firefox Session Storage" (TextTransform run; reverted its 17→18 version noise + lost final newline) |
| `art_jsons/Computer/Firefox.json`, `art_jsons/macOS/Firefox.json` | New "Firefox Session Storage" entry before SessionStore. Sources described as "saved browser snapshots" (no file names, rule 16) |
| Tests in `Magnet.Artifacts.Tests/Artifacts/Firefox/` | `FirefoxSessionFileReaderTests` (5), `FirefoxSessionFilesTests` (3 tests), `FirefoxSessionStorageParserTests` (3), `FirefoxSessionStorageMergerTests` (2) |

Header bytes (checked in Firefox `xpcom/ioutils/IOUtils.h` and on real files): compressed =
`6d 6f 7a 4c 7a 34 30 00` (`mozLz40\0`) + 4-byte little-endian size + LZ4 block; plain = starts `{"`;
encrypted = `mozEnc0\0` (byte 6 = version) + locked data.

### Test results (2026-11-16, VS Test Explorer)
- All tests: **170,928 passed, 0 failed**. Blackbox 1,510 pass after the Sources rename.
- First blackbox run failed `ExamineReservedFragmentNames`: `Source` is reserved (list: Tags,
  Comments, Category, Source, Location, Evidence Number, Deleted Source, Recovery Method).
- "Errors" in Test Explorer = VS trying to find tests in `Magnet.Artifacts.TestHelpers` (not a test
  project). Ignore.

### AR2 Computer:Firefox (2026-11-16, output `D:\artifact-regression-output\Output_20261116_181058`)
Exit code 1 = differences found (normal). Summary script:
`C:\Users\bprobert\AppData\Local\Temp\claude\ar2-check\summarize.ps1 -DiffFolder <output>\Diff`.

| Artifact | Diff | Meaning |
|---|---|---|
| **Firefox Session Storage** | +17 | All expected: FF32 = 10 (myspace 2, app.box.com 1, cnet 3, twitter 1, youtube 3), FF29 google.ca = 7 unique. CCL's 22 counted per file. Merging works on real paths (google.ca rows `Sources: previous.js, upgrade.js-20151216175450`). Last Accessed e.g. ticks 635457854681400000 = 2014-09-08 15:04:28 |
| **Firefox SessionStore Artifacts** | +34 / −28 | 28/28 = **encoding fix**: baseline `Magnet ForensicsÂ®` (mojibake) → now `Magnet Forensics®` (UTF-8). +6 from `upgrade.jsonlz4-20170926190823` / `-20190717172542` (2 files × 3 URLs, as predicted). `sessionstore.bak-20140421221237` read but only holds `about:home` (skipped on purpose) |
| Firefox Local Storage | +266 | Not this ticket: baseline (2026-10-23) predates the CARS-2252 merge |
| Everything else | none | |

Heads-up: the AR2 viewer stamps its own synthetic `Sources` fragment on hits (AR2 `CLAUDE.md`
line 47), so our Sources column may show AR2's value in the viewer. Axiom not affected; 3 other
artifacts already use `Sources`.

### Environment notes from this chat
- Only `Magnet.Artifacts.slnx` is needed to build/test. FileFormats not touched. Build in **Debug**
  (not NoAnalyzer) so style errors show.
- `D:\code\local_ar_config.json` now = **Computer:Firefox** with OptionsFilePath
  `D:\data\Computer\Firefox\options\Firefox.json`. AR2 run from VS (AR2 - Debug profile).
- AR2 repo (`D:\code\artifact-regression`): Ben discarded his local `ArtifactsVersion 14.5.*` edit and
  pulled `fury` (now `14.6.*`, PR CARS-2244). Rebuild hit **NU1007** (missing
  `sdk\10.0.112\PortableRuntimeIdentifierGraph.json`): SDK 10.0.112 no longer installed but stale
  `obj\` in `FrontEnd` + `FrontEnd.Tests` pointed at it. Fix: deleted those 2 `obj` folders, unloaded
  `FrontEnd.Tests` (like `FrontEnd`, needs Windows app components). Then Rebuild All: 13 succeeded.
- Ben's preferences saved to memory: casual lowercase commit messages, runs tests in VS (no `dotnet`
  commands), explain code block by block with input → output, small modular steps.

---

## Where we left off (2026-11-12) — superseded by CARS-2272 section above

Debrief with Danny done on 2026-11-12 (Slack huddle, #motherboard, 4:42–5:00 PM EST). CARS-2252 is
separate work, not part of this.

### Done 2026-11-15

- **Commented on CARS-1861**: short summary, the 5 files, fields used for Session Storage, other
  data for possible future artifacts, link to CARS-2272.
- **Created CARS-2272 "Firefox Session Storage artifact"**, assigned to Ben. Scope = the draft
  below (hunter reads all files, read `storage` everywhere, new artifact, dedupe, notes on test data
  and Firefox 160 encryption).
- **Open vs closed tab and tab URL/title: not included** in the artifact (Ben's call). Listed only
  as possible future artifacts.
- `default-release` set back as the default Firefox profile.

CARS-1861 research is wrapped up. Next real work = CARS-2272.

### What was decided in the debrief

- **One follow-up ticket**, not the 6 proposed in the debrief. It covers: make the existing hunter
  read all the snapshot files, plus a new Firefox Session Storage artifact with dedupe.
- **Parse all files, dedupe.** Accepted that ~95% of items repeat across files; reading all of them
  means nothing is missed (the recovery file is ~15 s old, `previous` can be days old).
- **One hit per key/value pair**, with a source fragment saying which file it came from.
- **Fragments:** Website, Key, Value, Last Accessed (the tab's `lastAccessed`), Source.
- Maybe a customer note (or wording in the Source fragment) explaining what each file is, e.g.
  recovery = autosave every ~15 s.
- Unzipping (LZ4) already exists in our code, no new work there.

**To check with Danny:** the fragment list leaves out **open vs closed tab** and the **tab's page
URL / title**. Both are easy to get. Confirm whether that was on purpose.

### Follow-up ticket scope (draft)

1. Hunter registration: add the root `sessionstore.jsonlz4` (today it's missed; only `sessionstore.js`,
   `sessionstore.bak` and the `sessionstore-backups\` folder are registered,
   `FirefoxSessionStoreParsedHunter.cs:33-35`). Probably also root `sessionstore.bak-<date>` (old
   Firefox).
2. Unzip `upgrade.jsonlz4-<build>` files too (today unzipping only runs if the name ends in `lz4`,
   `FirefoxSessionStoreParsedHunter.cs:71`).
3. Read each tab's `storage` from `windows[].tabs[]` and `windows[]._closedTabs[].state` (also
   `_closedWindows[]` tabs and `lastSessionState`).
4. New Firefox Session Storage artifact: Website, Key, Value, Last Accessed, Source. Dedupe across
   files (lead: Chrome Session Storage uses `.Dedupe()`, `Chrome/SessionStorage.cs:24-29`).
5. Test data: our captures (`D:\code\ff-sessionstorage-test\captures\`), since AR2 only has 2014
   Firefox. Watch out for `broken_text` (`"abc\ud800def"`), the C# reader must not crash on it.

Extra to mention in the ticket: Firefox 160+ can encrypt these files (`mozEnc0` header, off by
default). Spot and log it rather than fail silently.

### Field list for the ticket comment (draft)

Each tab in the file looks like this (from `decoded-demo-2\sessionstore.jsonlz4.json`, lines 9–57):
`entries`, `lastAccessed`, `hidden`, `searchMode`, `userContextId`, `attributes`, `index`,
`storage`, `image`, `requestedIndex`. Meanings checked in Firefox's
[TabState.sys.mjs](https://searchfox.org/mozilla-central/source/browser/components/sessionstore/TabState.sys.mjs)
(the code that writes each tab) and our testing.

**Used for Session Storage:**

| Field | Meaning | Used as |
|---|---|---|
| `storage` | Session Storage: `{ website: { key: value } }` | Website, Key, Value |
| `lastAccessed` | When the tab was last selected (ms since 1970, UTC) | Last Accessed |
| (the file itself) | Which snapshot it came from | Source |

**Not Session Storage, could be useful for other artifacts later:**

| Field / part | Meaning | Possible artifact |
|---|---|---|
| `windows[].tabs[]` | Tabs open when the file was saved | Open tabs |
| `entries[]` (+ `index`) | Tab's back/forward pages (URL, title); `index` = page shown now, counted from 1 | Tab history |
| `_closedTabs[]` (+ `closedAt`) | Recently closed tabs, with close time | Closed tabs |
| `_closedWindows[]` | Recently closed windows | Closed windows |
| `lastSessionState`, `previous.jsonlz4` | The previous session | Previous session |
| `formdata` | Text typed into web forms, not submitted (no passwords / card numbers) | Form data |
| `userTypedValue` | Address bar text typed but not entered | Typed URLs |
| `cookies[]` (top level) | Session cookies | Session cookies |
| `session.startTime` / `lastUpdate` | When the session started / file was last saved | Context |
| `hidden`, `pinned`, `userContextId` | Hidden tab, pinned tab, container number (0 = normal) | Extra columns on open tabs |
| `attributes`, `image`, `searchMode`, `requestedIndex`, scroll, window size | Layout details Firefox needs to redraw tabs | Not useful |

### Corrections to the huddle AI notes

| AI notes say | Actually |
|---|---|
| `sessionstore.json.LZ4`, `recovery.json`, `upgrade.json` | `sessionstore.jsonlz4`, `recovery.jsonlz4`, `upgrade.jsonlz4-<build>` |
| "`previous.bak.LZ4` (prior snapshot)" | Two files: `recovery.baklz4` = autosave before the latest, `previous.jsonlz4` = close snapshot from the run before |
| "Current hunter reads only the most recent snapshot" | Nearly the opposite: it reads the backups folder but **misses** the root `sessionstore.jsonlz4` (the newest after close) and can't unzip `upgrade` files |
| "storage under tabs with window/tab IDs" | Storage is under each tab, grouped by website. No tab ID, just position |

Action item owners were blank in the AI notes. Check who has each.

### Demo files from 2026-11-12 (still useful)

- `D:\code\ff-sessionstorage-test\decoded-demo\`: decoded before Ben closed Firefox (8 tabs).
- `D:\code\ff-sessionstorage-test\decoded-demo-2\`: decoded after closing with only the 2 localhost
  tabs open. Main file: 2 open tabs, 7 closed. Line 27/50 = open 8001 tab + storage, 115 =
  `_closedTabs`, 1215–1251 = closed 8001 tab that kept its storage, 1111 = closed size-test tab with
  **no** storage (over the 2048 limit). `previous.jsonlz4` = the main file from the day before
  (Firefox renamed it on start).
- Duplicates: `Ctrl+Shift+F` `p8001_short_text` in `decoded-demo-2` = 8 hits in 4 files.
- Decoder takes a **folder** (it finds every mozLz4 file below it, including the bookmarks backup,
  which isn't a session file): `D:/code/tools/ccl-venv/Scripts/python.exe -I D:/code/tools/ff-sessionstore-dump/dump_sessionstore.py <folder> <output folder>`

### Proof links (checked 2026-11-12)

- What Session Storage is: [MDN Window.sessionStorage](https://developer.mozilla.org/en-US/docs/Web/API/Window/sessionStorage)
  ("a unique page session gets created and assigned to that particular tab", "survives over page
  reloads and restores", "Closing the tab/window ends the session and clears the data").
- File layout: [session.schema.json](https://searchfox.org/mozilla-central/source/browser/components/sessionstore/session.schema.json)
  (`definitions` → `tab` → `properties` → `storage`). Gives the shape only, no descriptions.
- Field meanings: [TabState.sys.mjs](https://searchfox.org/mozilla-central/source/browser/components/sessionstore/TabState.sys.mjs)
  (calls `storage` "session storage data", `lastAccessed` = "when the tab was last selected",
  `index` = "1-based index of the active entry").

---

## Summary (start here, plain words, 2026-11-09)

**The ticket:** check whether Magnet Axiom correctly pulls "Session Storage" out of Firefox, and
build something if it doesn't. Vedant later widened it: look at **everything** in the same Firefox
file, the way Chrome has "Current Session" / "Last Session" artifacts.

**Background**
- Firefox keeps a **session file**: a saved snapshot of your open windows and tabs, so it can bring
  them back after a crash or restart. It's rewritten every ~15 s while Firefox runs, and again when it
  closes. Older copies are kept in a backups folder.
- **Session Storage** is a website feature: a site can stick small notes (`name = value`) on **one
  tab**, e.g. "checkout step = 2". They're meant to vanish when the tab closes. (Local Storage, done
  in CARS-1860/2225/2252, is the same idea, but it's shared by all tabs and stays forever.)
- Firefox copies each tab's Session Storage **into the session file**, so they come back on restore.
  That's how they end up on disk.

**What we did:** read CCL's free reader, read our code, made a test website on 2 local ports,
captured a fresh Firefox profile while running, after closing, and after restarting, decoded the
files ourselves, compared with CCL, checked the AR2 test data, and read Firefox's own source code.

**What we found**
1. **Session Storage:** Axiom gets **none** of it from Firefox. The data sits in files we already
   read, and we skip that part.
2. **How it behaves:** each tab keeps its own notes. Closed tabs keep theirs (for up to 14 days).
   Only the latest value is kept. Deleted notes are gone. If a site stores more than **2048
   characters** in a tab, Firefox saves **nothing** for that site. Private windows are never saved.
   A user setting can turn it off for https sites.
3. **The file holds much more than Session Storage:** open tabs with the time each was last used,
   recently closed tabs and windows with the time they were closed, the previous session, **text the
   user typed into web forms but didn't submit** (passwords and card numbers excluded), half-typed
   address bar text, and session cookies.
4. **Our existing Firefox session artifact is weak and out of date.** It's one flat list of URL +
   title + referrer, with no times and no "open / closed / previous session". And it has 3 bugs: it
   skips today's main file (`sessionstore.jsonlz4`), it can't open the `upgrade.jsonlz4-…` backups,
   and the referrer is always blank on modern Firefox.
5. **Firefox history that matters for a parser:** plain JSON before Firefox 56, compressed after.
   Backups folder since Firefox 33. The 2048 limit since Firefox 55 (before that, big values were
   kept). **New in Firefox 160: the file can be encrypted** (off by default).
6. **AR2 test data:** only 22 Session Storage items, all from 2014 Firefox. Nothing modern. So we'd
   need new test data, and our captures can serve.
7. **CCL's reader** finds the same Session Storage we do, but misses the "previous session" part.

**Answer to the ticket:** not up to date. Session Storage isn't supported at all, the existing
session artifact has bugs, and the file supports several more useful artifacts.

**Terms (clarified for Ben):**
- **Session Storage** = a *specific* thing, not an umbrella: the per-tab `name = value` notes a
  website saves (the web feature `sessionStorage`). In the file it's the `"storage"` part of a tab.
- **Session file / Session Store** = the whole Firefox snapshot file (`sessionstore.jsonlz4` etc.).
  Session Storage is one small part inside it.
- **Session** on its own = one run of the browser, start to close ("current session", "last session").

- "Session Store" and "session file" are the **same thing**: Firefox's name for that file.
- Desk analogy: **session** = one working day. **Session file** = a photo of your desk with all the
  open folders. **Session Storage** = sticky notes on each folder, which show up in the photo.
- Session Storage examples: checkout step, which page of a form you're on, a half-written message, a
  search filter. Dark mode is usually **Local Storage** (sites want it to stick around tomorrow).
- The session file is **one file** (`sessionstore.jsonlz4`, a compressed JSON text file) plus a
  folder of copies (`sessionstore-backups\`). On Ben's test profile:
  ```
  C:\Users\bprobert\AppData\Roaming\Mozilla\Firefox\Profiles\0qwa47l9.cars1861\
     sessionstore.jsonlz4                ← THE session file (written when Firefox closes)
     sessionstore-backups\
         recovery.jsonlz4                   (every ~15 s while running)
         recovery.baklz4                    (the copy before that)
         previous.jsonlz4                   (from the last time Firefox closed)
         upgrade.jsonlz4-20261022150525     (copy from when Firefox updated)
  ```
- Chrome on Ben's PC (checked): `%LOCALAPPDATA%\Google\Chrome\User Data\Default\Sessions\`
  (`Session_…`, `Tabs_…`) and `...\Default\Session Storage\` (LevelDB: `CURRENT`, `.log`, `.ldb`).

**Chrome vs Firefox, where each piece lives and what Axiom has:**

| Piece | Chrome on disk | Axiom has (Chrome) | Firefox on disk | Axiom has (Firefox) |
|---|---|---|---|---|
| Tab snapshot (session file) | `...\Chrome\User Data\Default\Sessions\Session_<time>` + `Tabs_<time>` | Current Session, Current Tabs, Last Session, Last Tabs (4 artifacts) | `...\Firefox\Profiles\<profile>\sessionstore.jsonlz4` + `sessionstore-backups\*` | Firefox SessionStore Artifacts (1 flat list, URL/title/referrer only) |
| Session Storage | **separate** folder `...\Default\Session Storage\` (a LevelDB database) | Chrome Session Storage | **inside** the same session file (each tab's `"storage"`) | **nothing** |

Key difference: Chrome keeps Session Storage in its own folder. Firefox tucks it inside the tab
snapshot file.

**What we have vs what we want (one tab from our capture):**
```
tab
  entries: url "http://localhost:8001/...", title "SS test 8001"  <- our hunter reads this
  lastAccessed: 1794237158602                                     <- ignored
  storage: { "http://localhost:8001": { "p8001_short_text": "hello from port 8001", ... } }
                                                                  <- ignored  = Session Storage
  formdata: ...                                                   <- ignored
```
- Today → 1 row in "Firefox SessionStore Artifacts": Title `SS test 8001`, URL `http://localhost:8001/...`.
- Want → Session Storage rows: Website `http://localhost:8001`, Key `p8001_short_text`, Value
  `hello from port 8001`, open/closed tab, source file. Plus (Vedant) better tab/session artifacts.

**Proposed next steps** (to agree with Vedant):
1. Small bug-fix ticket for the existing Firefox session hunter.
2. A parser that reads the Firefox session file (old, compressed, spots encrypted).
3. New artifacts on top: open tabs, previous session, closed tabs/windows, Session Storage, form data.
4. Write the AC 1 format document.

---

## Ticket: CARS-1861 "Investigate FireFox Session Storage"

**Ticket text**

> Investigate if the FireFox Session Storage hunters are up to date. See
> `ccl_mozilla_reader/ccl_mozilla_reader/ccl_moz_sessionstorage.py` (cclgroupltd/ccl_mozilla_reader on
> GitHub) and reference the Mozilla source code itself.
>
> AC:
> - Document the file type and investigate with Mozilla source code if it up to date
> - Develop the parser and artifact if a new one is needed
> - If current hunter is up to date, no thing new needed
> - Do a multi ticket approach

---

## What the ticket is asking (plain words)

**Background**
- **Session Storage** is a small store where a website can save data in the browser, but only for
  one tab. When the tab closes, the data is meant to go away. Its sibling is **Local Storage**, which
  stays after the browser closes (that was CARS-1860 / CARS-2225 / CARS-2252, see
  `Firefox-Local-Storage-MASTER.md`).
- Firefox still writes Session Storage to disk, so it can bring tabs back after a crash or restart.
  That's why it matters for forensics. It can hold leftover site data from tabs the user had open.
- ~~We already have hunters that pull Firefox Session Storage out of evidence.~~ **Wrong** (Claude
  assumed this from the ticket wording before checking the code). We have **no** Firefox Session
  Storage hunter. We only have Firefox **Session Store** hunters (tabs: title/URL/referrer), which read
  the same files but skip the storage part. See "Our current code" below. A hunter is our code that
  finds and extracts one kind of data.
- Worth saying when reporting back: the ticket's wording assumes Firefox Session Storage hunters
  exist. They don't.
- **ccl_mozilla_reader** is a free Python tool from CCL Group, a forensics company.
  `ccl_moz_sessionstorage.py` is their reader for Firefox Session Storage. It's a recent reference for
  how the format works today.
- **Mozilla source code** is Firefox's own code. It's the final word on how Firefox writes the data,
  and on whether that changed between versions.

**The question behind the ticket:** Firefox may have changed how or where it saves Session Storage
since our hunters were written. Do our hunters still match what current Firefox writes?

**Each AC**
1. **Document the file type and check it against the Mozilla source.** Write down which file(s)
   Firefox uses, where they live in the profile, and how the data inside is laid out (compression,
   structure). Confirm from Firefox's code, not just CCL's tool.
2. **Build a new parser and artifact if needed.** If our hunters miss a newer format or location,
   write the code that reads it (parser) and the output the examiner sees (artifact).
3. **If our hunter is up to date, nothing new is needed.** Closing with "no changes" is a valid
   outcome, as long as AC 1 backs it up.
4. **Multi-ticket approach.** Investigation and documentation first. If new work is needed, split it
   into follow-up tickets rather than doing it all under CARS-1861.

---

## What we have to do (plan)

Same shape as Local Storage (CARS-1860 research → CARS-2225 FileFormats parser → CARS-2252 hunters +
artifact).

**Step 1: Look at what we have today**
- Find our current Firefox Session Storage hunter(s), artifact and any parser.
- Note which files they read, which Firefox versions they were written for, and what fields they
  output.

**Step 2: Find out what Firefox does now**
- Read CCL's `ccl_moz_sessionstorage.py`: which files it reads and how it decodes them.
- Check Firefox's own source code to confirm the format and spot any changes over versions.
- Make test data: open a test page in a recent Firefox that sets Session Storage, then grab the
  profile files.

**Step 3: Compare**
- Put our hunters side by side with CCL and Mozilla. List what matches, what's missing, what's wrong.
- Optionally check existing AR2 data for Firefox Session Storage results.

**Step 4: Write it up (AC 1)**
- A format doc: file names, locations, layout, which Firefox versions.
- A short "is our hunter up to date?" verdict with the evidence.

**Step 5: Decide (AC 2 / AC 3)**
- **Up to date:** close CARS-1861 with the doc, no code.
- **Gaps found:** create follow-up tickets (multi-ticket), for example:
  - FileFormats parser ticket (if the file format needs a new reader)
  - Lib ticket for hunters + artifact (+ art-json, strings, tests)

CARS-1861 itself is research and documentation only. Code goes in the follow-up tickets.

---

## Status

- [x] Step 1: current hunters
- [x] Step 2: CCL + Mozilla source + test data (3 captures) + AR2 check, all done 2026-11-09
- [x] Step 3: comparison (CCL vs ours vs Mozilla, existing hunter bugs found)
- Vedant's add-on: whole-file inventory done, see "Vedant's add-on"
- [ ] Step 4: write-up (debrief section written 2026-11-11, see "Debrief (for presenting)"; full
  AC 1 format doc still to write)
- [x] Debrief with Danny, 2026-11-12. Decided: one follow-up ticket (see "Where we left off")
- [x] Step 5: commented on CARS-1861 + created follow-up CARS-2272 (2026-11-15)
- [x] Housekeeping: `default-release` set back as the default Firefox profile (2026-11-15)

---

## What is Session Storage?

- A website feature (`sessionStorage` in JavaScript). Lets a site save small **key = value** text
  items in the browser, e.g. `cart_step = 3` or `draft_message = "hi..."`.
- **Belongs to one tab + one website.** Two tabs on the same site each get their own copy.
- **Meant to vanish when the tab closes.** That's the difference from Local Storage, which stays
  until cleared.
- Cookies are sent to the server with every request. Session/Local Storage stay in the browser, and
  only the page's own JavaScript reads them.
- **Why it's on disk anyway:** Firefox saves your open tabs so it can restore them after a crash or
  restart. It saves each tab's Session Storage along with the tab, so "restore" brings the site back
  the way it was. That saved copy is what we can recover.

### Session Storage vs Local Storage

Both are key = value text items a website saves in the browser, both are only readable by that same
website, and both are only read by the page's JavaScript (never sent to the server like cookies).
The difference is **how long they live and who shares them**:

| | Session Storage | Local Storage |
|---|---|---|
| Lifetime | Until the **tab** closes | Until cleared (survives browser restart) |
| Shared between tabs? | **No**, each tab has its own copy | **Yes**, all tabs on that site share one |
| Typical use | Short-lived: form progress, "step 2 of checkout", one-time tokens | Long-lived: settings, dark mode, cached data, login state |
| Where Firefox puts it on disk | Inside the tab-restore file `sessionstore.jsonlz4` (per tab) | `storage\default\<website>\ls\data.sqlite` (per website) |
| Forensic angle | Shows what a site held **in a specific open/recently closed tab** | Shows what a site kept **over time** |

Example: open the same shop in two tabs. Local Storage "theme = dark" is the same in both.
Session Storage "checkout_step = 2" can be 2 in one tab and 4 in the other.

**Watch the two names:**

| Term | What it is |
|---|---|
| **Session Store** | Firefox's file that saves your open windows/tabs (`sessionstore.jsonlz4`) |
| **Session Storage** | The website key/value items. Firefox saves them *inside* the Session Store file |

---

## CCL `ccl_moz_sessionstorage.py` (v0.2, Alex Caithness, 2024)

Source: https://github.com/cclgroupltd/ccl_mozilla_reader/blob/main/ccl_mozilla_reader/ccl_moz_sessionstorage.py

**Files it reads** (all in the profile folder):
- `sessionstore.jsonlz4` (profile root)
- everything in `sessionstore-backups\` whose extension contains `jsonlz4`, or is `.baklz4`
  (e.g. `recovery.jsonlz4`, `recovery.baklz4`, `previous.jsonlz4`, `upgrade.jsonlz4-<build id>`)

**How it decodes:**
1. File is **mozLz4**: Mozilla's wrapper around LZ4 compression (header `mozLz40\0` + 4-byte size +
   LZ4 data). Decompress → JSON text.
2. JSON walk:
   ```
   windows[]
     tabs[]            -> tab["storage"]                    (open tab)
     _closedTabs[]     -> closed_tab["state"]["storage"]    (recently closed tab)
   ```
3. `storage` looks like `{ "<host/origin>": { "<key>": "<value>", ... }, ... }`.

**What each record holds:** host, key, value, `is_closed_tab` (true if from `_closedTabs`), source file.

**What it does NOT read** (to check if these matter): `_closedWindows`, tab history entries, any
timestamps. No time per item. Possibly Firefox has more places it keeps storage. Confirm in Mozilla
source.

---

## Our current code (Step 1 findings)

**We have no Firefox Session Storage artifact.** A search for `sessionstorage` only finds the
**Chrome** one (`Magnet.Artifacts/Chrome/SessionStorage.cs`).

What we do have is **Firefox Session Store**, which is about tabs, not storage:

| File | What it does |
|---|---|
| `Magnet.Artifacts/Firefox/FirefoxSessionStore.cs` | Artifact "Firefox SessionStore Artifacts". Fragments: Title, URL, Referrer URL |
| `Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStoreParsedHunter.cs` | Registers `sessionstore.js`, `sessionstore.bak`, anything under `sessionstore-backups\`. Decompresses mozLz4 if the name ends in `lz4` |
| `Magnet.Artifacts/Firefox/Hunters/SessionStoreParser.cs` | Walks the JSON, returns every object with both `url` and `title`. **Ignores `storage`** |
| `Magnet.Artifacts/Firefox/Hunters/FirefoxSessionStoreCarvedHunter.cs` | Carves `{"url":"http` text from unallocated space. URL/Title/Referrer only |

So the Session Storage key/values inside these files are **never output** today.

**Side notes on the existing Session Store hunter** (not this ticket's main point, but worth noting):
- Registers `sessionstore.js` (the old pre-Firefox-56 name). The current name is
  `sessionstore.jsonlz4`, which is **not** registered in the profile root. Only the backups
  folder is picked up. (Confirmed: whole-name match, see finding 14.)
- CFL typo: `"sessionstore.back"` vs registered `"sessionstore.bak"`
  (`FirefoxSessionStoreParsedHunter.cs:39`).
- Skips `about:` pages.

**Chrome Session Storage schema, for comparison** (`Chrome/SessionStorage.cs`):
Key, Value, Origin, Session ID, State, Sequence Number. `[NoConnections]`, `WebDisplayOrderCapability`.

---

## Ground truth: capture from Ben's Firefox

Use a **fresh test profile** so no personal browsing gets into test data.

### Tools (built 2026-11-06)

| What | Where |
|---|---|
| Test page | `D:\code\ff-sessionstorage-test\make_test_sessionstorage.html` |
| Captures go in | `D:\code\ff-sessionstorage-test\captures\{1-running,2-closed,3-restarted}\` |
| Decoder (Claude's check, Ben can run it too) | `D:\code\tools\ff-sessionstore-dump\dump_sessionstore.py` |
| CCL's reader (second opinion) | `D:\code\tools\ccl_mozilla_reader` (venv `D:\code\tools\ccl-venv`, has `lz4`) |

**Test page:** one page, served on two ports (8000 and 8001 = two different websites). Every key starts
with `p8000_` / `p8001_` so you can tell which site wrote it. The page shows its own Session and Local
Storage live.

| Button | Writes | Checks |
|---|---|---|
| 1. Write Basic Records | `short_text`, `unicode_text`, `empty_value`, `json_value`, `written_at` | Basic saving, text encoding, empty values, time written (to match file times) |
| 2. Write Size Records | `size_1000` … `size_20000` (x's) | Where Firefox's size cut-off is (`dom_storage_limit`) |
| 3. Write Local Storage Control | `local_only` in **Local** Storage | Must **not** appear in session files |
| 4. Write Then Delete One | `deleted_item` then removes it | Removed items don't linger |
| 5. Edit Value (×3) | `edited_item` = version 1, 2, 3 | Only latest kept, or old versions too? |
| 6. Write Broken Text | `broken_text` = `abc` + half an emoji + `def` | How invalid text lands in the JSON |

**Decoder:** `D:/code/tools/ccl-venv/Scripts/python.exe -I D:/code/tools/ff-sessionstore-dump/dump_sessionstore.py <captures folder> <output folder>`.
Unpacks every mozLz4 file to readable JSON and lists every `storage` object found **anywhere** in
it, with its path. That catches places CCL's fixed walk would miss.

### Capture steps (given to Ben)

**A. Start the two websites** (two terminals, leave both running):
```
py -m http.server 8000 --directory "D:/code/ff-sessionstorage-test"
py -m http.server 8001 --directory "D:/code/ff-sessionstorage-test"
```

**B. Make the test profile**
1. Normal Firefox → `about:support` → note **Version**.
2. `about:profiles` → **Create a New Profile** → Next → name `cars1861` → Finish.
3. On the `cars1861` entry: **Launch profile in new browser**. Do everything below in that window.
4. Settings → General → Startup → tick **Open previous windows and tabs**.
5. `about:config` → accept → note (don't change) `browser.sessionstore.privacy_level`,
   `browser.sessionstore.interval`, `browser.sessionstore.dom_storage_limit` (or "not found").
6. `about:profiles` → `cars1861` → **Root Directory → Open Folder**. Keep this Explorer window open.

**C. Make the data** (one tab each):

| Tab | Address | Do |
|---|---|---|
| A | `http://localhost:8000/make_test_sessionstorage.html` | Buttons 1, 2, 3, 4, 5 (×3), 6 |
| B | `http://localhost:8001/make_test_sessionstorage.html` | Button 1 |
| C | `http://localhost:8001/make_test_sessionstorage.html` (second tab, same site) | Wait a few seconds, button 1 |
| D | `http://localhost:8000/make_test_sessionstorage.html` | Button 1, then **close this tab** |
| E | `https://example.com` | F12 → Console → `sessionStorage.setItem("https_test", "hello from https");` |

Then check F12 → **Storage** → **Session Storage** on a couple of tabs, note the clock time, and
**wait 1 minute** (Firefox saves on a timer).

**D. Capture 1, running:** copy the profile's `sessionstore-backups\` folder to
`captures\1-running\`. Firefox stays open.

**E. Capture 2, closed:** Firefox menu → **Exit**. Wait ~10 s. Copy `sessionstore.jsonlz4` (profile
root) **and** `sessionstore-backups\` to `captures\2-closed\`.

**F. Capture 3, restarted:** normal Firefox → `about:profiles` → `cars1861` → **Launch profile in
new browser**. Tabs A, B, C, E should come back. On tab A and tab B, check the page's Session Storage
table: did the items come back? Note it. Wait 1 minute. Copy `sessionstore-backups\` to
`captures\3-restarted\`. Then Exit.

**Where the folder is:** profile **Root Directory**, not "Local Directory":
`C:\Users\bprobert\AppData\Roaming\Mozilla\Firefox\Profiles\<profile>\sessionstore-backups\`.
Test profile = `0qwa47l9.cars1861`. The folder only appears once Firefox has saved at least once
(~15 s after browsing).

**First attempt went wrong (2026-11-09):** Ben forgot to click "Launch profile in new browser"
(the button works fine). Only one Firefox process was running (no `-P`), so all test tabs landed in Ben's **normal**
profile (`u0mt223f.default-release`). The `cars1861` folder only held `parent.lock` + `times.json`.
Side effect: `profiles.ini` `[Install…] Default=` now points to `cars1861`. **Reset it after testing**
(normal Firefox → `about:profiles` → `default-release` → Set as default profile).
Early sign anyway: the normal profile's `recovery.jsonlz4` (written while running) did contain the
`p8000_`/`p8001_` keys and `https_test`. Not used as test data, because it holds personal browsing.

**Reliable launch** (separate process, own profile):
```
"C:\Program Files\Mozilla Firefox\firefox.exe" -P cars1861 -no-remote
```
Check `about:profiles` says **"This is the profile in use"** on `cars1861` before starting.

**G. Report back:** version, the 3 settings, whether items survived the restart, and anything odd.

**H. Look at it yourself:** run the decoder (above) with `D:\code\ff-sessionstorage-test\captures`
and output `D:\code\ff-sessionstorage-test\decoded`, open the `.json` files in VS Code, search
`"storage"`. Claude runs the same decoder + CCL independently and we compare.

---

## Findings

1. We have **no Firefox Session Storage artifact**. The data is inside files we already read for
   Session Store (tabs), but `storage` is ignored. So this is likely the "new parser + artifact"
   path, not "already up to date". To confirm with ground truth + Mozilla source.

### Capture 1 (running), 2026-11-09

Ben's settings: `privacy_level = 0`, `interval = 15000` (idle `36000000`), `dom_storage_limit = 2048`.
Decoded by Claude to `D:\code\ff-sessionstorage-test\decoded-claude\1-running\`.

Files in `sessionstore-backups\` while running: `recovery.jsonlz4` (newest), `recovery.baklz4`
(the one before), `previous.jsonlz4` + `upgrade.jsonlz4-20261022150525` (from an earlier start of
this profile at 09:59, 1 tab, no test data). All have the `mozLz40\0` header. Top-level JSON has
`version: ["sessionrestore", 1]`.

| Tab | In file? | Storage saved |
|---|---|---|
| A, port 8000, all buttons | `tabs[3]` | **Nothing for localhost:8000** (see 2) |
| B, port 8001 | `tabs[4]` | all 5 basic items, `written_at 15:12:36.303Z` |
| C, port 8001 again | `tabs[5]` | all 5 basic items, `written_at 15:12:48.733Z` (own copy per tab ✔) |
| D, port 8000, closed | `_closedTabs[0].state` | all 5 basic items. `closedAt` = 2026-11-09 15:12:59.292Z |
| E, https://example.com | `tabs[6]` | `https_test` ✔ |
| Local Storage control | — | not present ✔ (Tab A dropped anyway, so retest) |

**2. The size limit drops the whole website, not just the big item.** Tab A wrote ~30,000
characters, so Firefox saved **none** of localhost:8000's items in that tab. Mozilla source:
- `modules/libpref/init/StaticPrefList.yaml`: `browser.sessionstore.dom_storage_limit`, default
  `2048`, "Maximum number of bytes of DOMSessionStorage data we collect per origin."
- `dom/storage/SessionStorageManager.cpp`, `BackgroundSessionStorageManager::GetData`:
  `if (record->mCache->GetOriginQuotaUsage() > aSizeLimit) { continue; }`, so the whole origin is
  skipped.
- Called from `docshell/base/CanonicalBrowsingContext.cpp` `UpdateSessionStoreSessionStorage`.
- Forensic meaning: only sites using **≤ ~2 KB** of session storage per tab end up on disk. Whether
  that's counted in bytes or characters: **characters** (key + value), see Mozilla source findings.

**3. A tab keeps storage for every website it visited, not just the current page.** Every tab that
started on `about:newtab` still holds an item from
`https://prod-games-particle.merino.prod.webservices.mozgcp.net^partitionKey=(about,…)`. That's
Firefox's own new-tab crossword widget (an embedded frame). It's still there after the tab navigated
to localhost. This matches the web rule: storage belongs to the tab + site, not the page. Forensic
meaning: a tab's storage can show sites visited **earlier in that tab**.

**4. The website name can carry extra parts after `^`.** E.g. `^partitionKey=%28about%2C…%29`
(storage of a site embedded inside another site). Probably also `^userContextId=N` for containers,
like Local Storage. CCL passes the string through as "host" unchanged.

**5. More places hold storage than CCL reads.** Seen: `$.lastSessionState.windows[].tabs[].storage`
(the previous session, kept in the recovery file). CCL only reads `windows[].tabs` and
`windows[]._closedTabs`. Also to check: `_closedWindows`.

**6. Times exist that CCL ignores.** Closed tabs have `closedAt` (ms since 1970, UTC). Tabs have
`lastAccessed`. The file has `session.lastUpdate` / `startTime`. No time per storage item.

**Next:** retest buttons 3–6 in a new port-8000 tab **without** button 2 (Tab F), then E (closed) + F
(restarted).

### Capture 2 (closed) + 3 (restarted), 2026-11-09

Tab F (port 8000, buttons 1, 3, 4, 5×3, 6, no size button) = `tabs[7]`:

| Test | Result |
|---|---|
| Basic items | ✔ all saved |
| `edited_item` clicked 3× | Only `version 3`. **No older versions kept** |
| `deleted_item` | Not in any file ✔ |
| `local_only` (Local Storage) | Not in any file ✔. Session files hold Session Storage only |
| `broken_text` | Written as JSON escape `"abc\ud800def"`. Python/CCL read it back as a lone surrogate. Our C# reader must not crash on it |
| `unicode_text` | `héllo wörld 日本 🦊` intact ✔ |

**7. Which file holds what:**

| Moment | Files | Note |
|---|---|---|
| Running | `sessionstore-backups\recovery.jsonlz4` (newest) + `recovery.baklz4` (one save older) | Rewritten every ~15 s while something changes |
| After clean exit | `sessionstore.jsonlz4` in the **profile root** (written at exit, 10:26:49) | Same tabs/storage as recovery, **without** `lastSessionState` |
| After restart | root `sessionstore.jsonlz4` gone, `sessionstore-backups\previous.jsonlz4` appears | `previous` = the last session |
| Always | `upgrade.jsonlz4-<build id>` | Snapshot from when Firefox updated; can be old |

**8. The same items repeat across files.** CCL returned 88 records for capture 2, mostly the same
items found in 3–4 files. An artifact will need dedupe, or show one row per file (source matters
forensically: older files can hold items that newer ones lost, see 9).

**9. Storage can disappear after a restart, and older files keep it.** After restart, the
`example.com` tab (`tabs[6]`) and the new-tab widget items have **no storage** in `recovery.jsonlz4` /
`previous.jsonlz4`. But `recovery.baklz4` from the same capture still has `https_test`. Localhost
tabs kept theirs. Cause unknown (see 11: browser agrees with the file, example.com showed nothing).

**10. CCL vs our decoder:** same items for `windows[].tabs` and `_closedTabs` in all 3 captures. CCL
misses `lastSessionState` (here only held the widget item, but in real use it can hold a whole
previous session). CCL strips nothing from the host (keeps `^partitionKey=…`). CCL loaded with the
same trick as `ccl-compare` (skip package `__init__`, needs Python 3.10+ otherwise).

**Open questions for Ben:**
- After the restart, did tabs B and F show their items? Did tab E show `https_test`? **Answered in
  11:** B and F yes, E no.
- Did Firefox start twice? **Yes** (Ben, 2026-11-09). So capture 3 = after the 2nd restart, and
  `previous.jsonlz4` = the 1st restarted session, not the original one. Storage loss in finding 9 may
  be from the double restart. Retest as a single restart if it matters.
- Tab names: Ben didn't track the letters. To re-check, he goes by the address bar instead.

**11. After restart, the browser matches the file. Firefox restores the notes into the page.**
Ben reopened `cars1861` a 3rd time (~10:47, screenshots ~11:49), servers running:
- `SS test 8001` tab: page table + F12 → Session Storage show all 5 `p8001_` items, same
  `written_at 15:12:36.303Z` as the file.
- Last `SS test 8000` tab (Tab F): all 7 `p8000_` items incl. `edited_item = version 3` and
  `broken_text` (shows as `abc�def`).
- `example.com`: "No data present". Matches the file, where `https_test` was already gone after the
  restarts.

So the file is what Firefox uses to restore Session Storage on restart. (Ben's first "no data" was
on the example.com tab.) Live files copied to `captures\4-reopened-check\`.

**Still open:** why example.com lost its storage over the restarts but localhost didn't. Ideas: https
vs http, the double restart, or the tab not being loaded during the first restart. Low priority.
Could retest with one restart only.

### AR2 `Computer:Firefox` check (2026-11-09)

Ben asked: is it worth parsing something temporary, and does AR2 even have it?
Evidence `D:\data\Computer\Firefox\evidence` (9 zips). Session files exist in only 2 zips. Extracted
(session files only) to `D:\temp\CARS1861\ar2-session-files\`.

| Zip / Firefox | Session files | Session Storage items |
|---|---|---|
| `data from Jack.zip`, Firefox 22 + 34 | 28 (`sessionstore.js/.bak`, `recovery.js`, temp copies) | **0** |
| `firefox.zip`, Firefox 29 | 4 | 12 (`google.ca`, open + closed tab, repeats across 3 files) |
| `firefox.zip`, Firefox 32 | 2 | 10 (`myspace`, `app.box.com`, `cnet`, `twitter` open; `youtube` closed tab) |
| `firefox.zip`, Firefox 68.0.1 | 11 (`.js` + `.jsonlz4` both) | **0** |
| `firefox.zip`, Mac | 2 | **0** |
| other 7 zips (incl. `Firefox_IndexedDb_152`) | none | — |

**Total: 22 items in 5 files, all from Firefox 29/32 (2014).** Nothing from any modern Firefox.

**12. Old format = same layout, just not compressed.** Firefox 29/32 `sessionstore.js` /
`.bak` / `previous.js` are plain JSON with the same `windows[].tabs[].storage` and
`_closedTabs[].state.storage`. So one JSON walk covers old and new. Only the outer wrapper differs
(mozLz4 or not).

**13. Old Firefox had no 2 KB limit.** Firefox 32 kept `cnet.com` with ~11,000 chars in one tab and
`twitter.com` `ScribeTransport` at 4,319 chars. Modern Firefox would drop both. When the limit was
added: Firefox 45 (10,000,000 chars), cut to 2048 in Firefox 55. See Mozilla source findings.

**Worth it? (Claude's view, for Ben to decide)**
- For: not as temporary as it sounds. It's written to disk, survives restarts, stays in closed tabs
  and backups. Real AR2 examples: YouTube remote session in a closed tab, Box history, Google. The data
  is in files we **already parse**, so it's cheap to add. We already ship Chrome Session Storage.
- Against: modern Firefox only keeps sites under 2 KB per tab, so big sites get dropped. No time per
  item. Lots of duplicates across backup files. Values are mostly app-internal. **AR2 has zero modern
  examples**, so new test evidence would be needed (our captures could be it).
- Likely verdict: low-to-medium value, low cost → one small follow-up ticket, low priority. Not "no
  work needed", since today we output nothing.

---

## Vedant's add-on (2026-11-09)

> "the json file for firefox that has session storage also had information about session (see chrome
> current or last session) so investigate that too and see what other artifacts are possible, forgot
> to add the note to that ticket"

So the scope grows: not just Session Storage, but **everything** in the session file, compared to
Chrome's session artifacts.

### What Chrome has today (for comparison)

4 artifacts, all the same schema (URL, Last Visited, Title, Visit Count, Redirect URL):
`Chrome Current Session`, `Chrome Current Tabs`, `Chrome Last Session`, `Chrome Last Tabs`
(`Magnet.Artifacts/Chrome/CurrentSession.cs`, `LastSession.cs`, hunters in `Chrome/Hunters/`).
Current vs last is decided by which file (newest `Session_<time>` = current). Also
`Chrome Session Storage` (separate).

### What Firefox has today

**One** artifact, `Firefox SessionStore Artifacts`: Title, URL, Referrer URL. Every `url`+`title`
object in the file, flattened. **No** time, no open vs closed, no current vs last session.
AR2 baseline: 351 rows (`data from Jack.zip` 120, `firefox.zip` 231), about half from the carver.

**14. Bugs / gaps in the existing Session Store hunter** (`FirefoxSessionStoreParsedHunter.cs`):
- **Today's main file is never read.** Registered names are `sessionstore.js` / `sessionstore.bak` +
  regex `sessionstore-backups\\.+`. Filename registration is a whole-name match (`TestRegistrar`
  uses a dictionary keyed by name), so `sessionstore.jsonlz4` in the profile root (written at
  every clean exit since Firefox 56-ish) is skipped. AR2 has no root `.jsonlz4` file, so AR2 can't
  catch it.
- **`upgrade.jsonlz4-<build>` files are never decoded.** `Decompress` only runs if the name
  `EndsWith("lz4")`. `upgrade.jsonlz4-20190717172542` doesn't, so the raw compressed bytes go to the
  JSON parser, which fails (logged at Debug only). AR2 Firefox 68 has 2 such files with **3 real URLs
  each**, and the baseline has **0 rows** from them.
- **Referrer is always empty on modern Firefox.** Parser looks for a key ending in `referrer`.
  Modern files use `referrerInfo` (a base64 blob) instead. Firefox 32 still had `referrer`.
- CFL typo `sessionstore.back` (only feeds "commonly found locations", doesn't stop parsing).
- **Likely 4th (found 2026-11-11, from reading the code, not run):** `sessionstore.bak-<date>` in
  the profile root (old Firefox upgrade backup, e.g. AR2 FF29 `sessionstore.bak-20140421221237`)
  matches neither the exact names nor the backups-folder regex, so it's skipped.

Exact lines: bug 1 `FirefoxSessionStoreParsedHunter.cs:33-35`, bug 2 `FirefoxSessionStoreParsedHunter.cs:71`,
bug 3 `SessionStoreParser.cs:48` (+ `ExtractString` at :58), typo `FirefoxSessionStoreParsedHunter.cs:39`.
Bugs 1 and 2 also matter for any **new** artifact built on this hunter (Session Storage included):
it would miss the same files until they're fixed.

### Everything in the session file (field inventory)

Full list: `D:\temp\CARS1861\field-inventory.txt` (our Firefox 152 capture vs AR2 Firefox 68 vs 32).

| Candidate artifact | Where in JSON | What it gives | Times | Value |
|---|---|---|---|---|
| **Open tabs** (≈ Chrome Current Tabs) | `windows[].tabs[]`: current page = `entries[index-1]` | URL, title, pinned/hidden, container (`userContextId`), tab group | `lastAccessed` (ms) | High |
| **Tab history** (≈ Chrome Current Session) | `tabs[].entries[]` (+ `children[]` = frames) | Back/forward pages per tab, in order | none per page | Medium |
| **Recently closed tabs** | `windows[]._closedTabs[]` | URL/title + full history of the closed tab, position | `closedAt` (ms) | **High** |
| **Recently closed windows** | `_closedWindows[]` | All tabs of a closed window | `closedAt` | High |
| **Last session** (≈ Chrome Last Session/Tabs) | `previous.jsonlz4`, and `lastSessionState` inside recovery | Same as above, for the previous run | same | High |
| **Session Storage** | `tabs[].storage`, `_closedTabs[].state.storage` | website key/values | none | Medium |
| **Form data (typed, not submitted)** | `tabs[].formdata` `{url, id:{field:value}, xpath:{…}}` | Text the user typed into page fields. Our capture: `about-config-search = "browser.sessionstore.dom_storage_limit"` | none | **High** |
| **Typed in address bar, not entered** | `userTypedValue` (seen in FF68 closed tab) | Half-typed URL/search | none | Medium |
| **Session cookies** | `cookies[]` (FF68: host, name, value, path, secure, httponly, expiry, originAttributes) | Cookies that live only for the session | `expiry` | Medium |
| **Tab groups** | `savedGroups`, `windows[].groups/closedGroups` (FF152) | Group names the user made | ? | Low–Med |
| Session info | `session.startTime`, `lastUpdate`, `recentCrashes` | When the browser session started / last saved, crash count | ms | Low (but good context) |
| Window layout, scroll, sidebar, zoom | `windows[].width/height/...`, `tabs[].scroll` | Layout only | — | Low |

**What Axiom shows today from all of that:** only the URL + title of pages, as one flat list, no
times. Everything else in the table above is ❌. Biggest misses, in order: closed tabs/windows with
close time, tab last-used time, typed form text, previous session kept separate, Session Storage.
One limit for everything: **individual pages have no time**, only tabs (last used), closed items
(when closed) and the whole file (when saved).

### Can Firefox give us Chrome's 4 artifacts? (mostly yes)

| Chrome artifact | Firefox equivalent |
|---|---|
| Current Tabs | `windows[].tabs[]` in the newest session file, current page of each tab |
| Current Session | every page in each tab's `entries[]` (back/forward history) |
| Last Tabs / Last Session | the same, from `previous.jsonlz4` or `lastSessionState` |

- **Decision needed:** Firefox has no "current"/"last" file names. Which copy counts as current
  (`recovery.jsonlz4` while running, `sessionstore.jsonlz4` after exit, `previous.jsonlz4` the run
  before)? Chrome's code uses "newest file = current".
- Chrome's columns vs Firefox: URL ✅, Title ✅, Last Visited ⚠️ only per **tab** (`lastAccessed`),
  Visit Count ❌ not stored, Redirect URL ❓ possibly `originalURI` (not confirmed what it means).
- Firefox extras Chrome's 4 don't have: closed tabs/windows with close time, form data, Session
  Storage.

### Is parsing Session Storage easy, since we already read the file? (partly)

- Easy part already done: the hunter finds the file, unpacks it, reads the JSON. `storage` itself is
  a simple website → name → value map.
- The catch: `SessionStoreParser` doesn't follow the file's structure. It searches the whole JSON for
  anything with `url` + `title` and flattens them. It never knows which tab, or open vs closed vs
  previous session. Bolting on "also grab `storage`" would lose that context.
- Work, roughly: (1) fix bugs 1 and 2, (2) rewrite the parser to walk windows → tabs → entries,
  closed tabs, closed windows, previous session (**main job**), (3) read `storage` per tab (easy after
  2), (4) dedupe across the backup copies.
- Step 2 is exactly what Vedant's Chrome-style artifacts need too. Build that reader **once**, then
  Session Storage, current/last tabs, closed tabs and form data are each a fairly small artifact on
  top. Recommendation: one structured parser feeding all of them, not a patch on the old one.

---

## Mozilla source findings (2026-11-09)

Read from `mozilla-firefox/firefox` `main` + Bugzilla by a research agent. Claude re-checked the
starred (★) ones in source. Line numbers drift over time.

**Files and when they're written** (`browser/components/sessionstore/SessionFile.sys.mjs:57-147`,
`SessionWriter.sys.mjs`):

| File | When |
|---|---|
| `sessionstore.jsonlz4` (profile root) | Written at clean exit. **Moved** to `previous.jsonlz4` on the first save after the next start |
| `sessionstore-backups/recovery.jsonlz4` | Every ~15 s while running (via `.tmp`). Deleted at exit if restore-on-start is off |
| `sessionstore-backups/recovery.baklz4` | The previous `recovery.jsonlz4` |
| `sessionstore-backups/previous.jsonlz4` | The last clean-exit file |
| `sessionstore-backups/upgrade.jsonlz4-<buildID>` | Copy taken after a Firefox update. ★ Keeps **3** (`maxUpgradeBackups`) |

Firefox reads them in the order clean → recovery → recovery.baklz4 → previous → upgrade.

**Version history:**
- **Firefox 33** (Bug 883609, 2014): `sessionstore-backups/` folder appears. Before that,
  `sessionstore.js` + `sessionstore.bak` sat in the profile root.
- **Firefox 56** (Bug 934967, 2017): `.js` → `.jsonlz4` (mozLz4). Firefox still reads the old names.
- **Firefox 45** (Bug 1216250, 2015): session storage limit first added, at 10,000,000 chars.
  **Firefox 55** (Bug 1362058, 2017) cut it to **2048**. Matches AR2: Firefox 32 kept 11,000 chars.
- **Firefox 55** (Bug 912717): cookies moved from each window to top level `cookies[]`.
- ★ **Firefox 160 (Bug 2044019, Oct 2026): optional encryption** of session files. Header
  `mozEnc0\0` wrapping the mozLz4 data. Off by default (`browser.sessionstore.encryption.available`
  / `.enabled` = false, `firefox.js:1573-1574`). A parser should spot `mozEnc0` and report it, not
  fail silently. Its stated aim is to protect the session cookies.

**mozLz4 header** (`xpcom/ioutils/IOUtils.h:770-787`): `mozLz40\0` + 4-byte little-endian
decompressed size + raw LZ4 block. Matches what we decoded.

**JSON layout:** full schema in-tree at `browser/components/sessionstore/session.schema.json`.
Built in `SessionStore.sys.mjs` `getCurrentState()`, tabs in `TabState.sys.mjs`, history entries in
`toolkit/modules/sessionstore/SessionHistory.sys.mjs` `serializeEntry`.
- **Times are all ms since 1970 UTC** (`Date.now()`): `session.startTime`, `session.lastUpdate`,
  tab `lastAccessed`, `closedAt` on closed tabs and windows. **History entries have no times.**
- Back history trimmed to **10** pages at exit (`max_serialize_back`), forward kept in full.
- Closed tabs are dropped after **14 days** (`forget_closed_after`).
- `lastSessionState` = a whole previous session, kept when it hasn't been restored yet (e.g.
  restore-on-start is off). Cleared on restore. FF68 AR2 data has one.

**Session Storage:**
- Shape `{ "<origin>": { "<key>": "<value>" } }`, tab level only (not under `entries[].children`).
  Embedded frames show up as extra origins in the same tab (that's our crossword widget).
- Origin = `principal.GetOrigin()` = address + optional `^` suffix: `userContextId`,
  `privateBrowsingId`, `firstPartyDomain`, `partitionKey`, … (`caps/OriginAttributes.cpp`).
- Also inside `_closedTabs[].state`, `_closedWindows[]` tabs, and `lastSessionState`.
- ★ **The 2048 limit counts UTF-16 characters (key + value), not bytes.**
  `dom/storage/SessionStorageCache.cpp:130-134` adds `aKey.Length()` + `aValue.Length()` on strings.
  The pref comment and docs say "bytes", which is wrong.

**privacy_level** (`toolkit/modules/sessionstore/PrivacyLevel.sys.mjs`, ★ default 0):
0 = save extra data for all sites, 1 = only for **http** (not https) sites, 2 = never. Applies to
session storage, form data, session cookies. **Not** to URLs or history. So on a machine set to 1,
https sites have no session storage in the file.

**Private browsing:** private windows and their closed tabs are stripped before writing
(`SessionSaver.sys.mjs:252`). Private session storage never reaches the file.

**Cookies** (`SessionCookies.sys.mjs`): still saved today, **session cookies only**, top-level
`cookies[]`: host, name, value, path, secure, httponly, expiry, originAttributes, sameSite,
schemeMap, isPartitioned. Our FF152 capture had none (test pages set none).

**Form data** (`toolkit/components/sessionstore/SessionStoreUtils.cpp`): `formdata {url, id:{elementId:
value}, xpath:{xpath: value}, innerHTML, children}`. **Excluded:** password fields (and fields that
were ever password type), hidden/button/submit inputs, **anything that passes a credit-card number
check**, autocomplete=off, unchanged defaults. Limit 2,097,152 chars per field.

### How to read the decoded JSON yourself (VS Code)

**Best example to start with:** `decoded-claude\2-closed\sessionstore.jsonlz4.json`, line ~1116
(the page the tab showed: `http://localhost:8001/...`, title `SS test 8001`) and lines 1136–1146
(that tab's `storage`, with the `p8001_...` items under `"http://localhost:8001"`). Skip the
`prod-games-particle.merino...` entries. That's Firefox's own new-tab widget, not our test.

1. Open e.g. `D:\code\ff-sessionstorage-test\decoded-claude\2-closed\sessionstore.jsonlz4.json`
   (already decoded. To make your own copy, run the decoder command into `decoded\`).
2. `Ctrl+F` → `"storage"` (with quotes) and press Enter to step through each hit.
3. Each hit sits inside a tab. Scroll up a little from it to that tab's `"entries"` to see which
   pages the tab showed (`"url"`).
4. Shape:
   ```
   windows[0]
     tabs[ ]            one per open tab
       entries[ ]       the tab's back/forward pages ("url", "title")
       storage { "http://localhost:8001": { "p8001_short_text": "hello from port 8001", ... } }
     _closedTabs[ ]     recently closed tabs: closedAt + state.entries + state.storage
   ```
5. Fold sections with the small arrows in the margin, or `Ctrl+K Ctrl+0` to fold all, then open only
   `windows`.
6. Try `Ctrl+F` → `p8000_edited_item`: you should see only `"version 3"` (old values aren't kept).

**Decoder note:** the decoder sets its output to UTF-8 (fixed 2026-11-09) so the emoji and the
half-emoji test values print instead of crashing.

**Running CCL's reader** (Python 3.9 can't import CCL's package normally, so skip its `__init__`):
```python
import sys, pathlib, types
pkg = types.ModuleType('ccl_mozilla_reader'); pkg.__path__ = [r'D:/code/tools/ccl_mozilla_reader/ccl_mozilla_reader']
sys.modules['ccl_mozilla_reader'] = pkg
from ccl_mozilla_reader.ccl_moz_sessionstorage import SessionStorage
recs = list(SessionStorage(pathlib.Path(r'D:/code/ff-sessionstorage-test/captures/2-closed')).iter_all_records())
```
Run with `D:/code/tools/ccl-venv/Scripts/python.exe -I`.

---

## Chat 2026-11-11: clarifications for Ben

The debrief section near the top replaces the earlier "Debrief plan" outline (which proposed a
separate `CARS-1861-research.md` + renaming this file to `-depth`; not done, Ben asked for a debrief
section in this file instead). Live file to open when presenting:
`decoded-claude\2-closed\sessionstore.jsonlz4.json`. Mention, but don't open, the AR2 Firefox 68
file (real session cookies + `lastSessionState`, real-looking user data).

### Ben's understanding of Session Storage (checked)

Ben: "key value pairs like Local Storage, but temporary, for the session. Dark mode = Local Storage.
Onboarding step / checkout step = Session Storage, kept on reload but not next time the browser
opens. Key value pairs about each tab or each website." **Mostly right.** Adjustments:
- "Session" = life of **one tab**, not the whole browser. Reload → kept. Close tab → gone. Same site
  in a second tab → its own empty set.
- **Per tab AND per website**: each tab has its own set for every website it visited. Two tabs on
  one shop can hold `checkout_step = 2` and `= 4`.
- Twist: when Firefox reopens tabs at start-up, it puts the notes back (finding 11). So less
  temporary on Firefox than it sounds.

### Session Store vs Session Storage (Ben asked if they're the same)

Not the same. **Session Store** = Firefox's name for the **whole set** of snapshot files (not only
the root `sessionstore.jsonlz4`). **Session Storage** = the website notes, stored **inside** them under
`"storage"`. Our artifact "Firefox **SessionStore** Artifacts" reads the snapshot files but only
outputs page URL + title, never `"storage"`.

"State" (as in "current state") = **a snapshot of the browser**: which windows, tabs, pages, plus
each tab's extras (Session Storage, typed form text…).

### Each file, using Ben's live test profile (checked 2026-11-11, Firefox not running)

| File | Last written | What it is |
|---|---|---|
| `sessionstore.jsonlz4` (root) | 11/9 13:29 | Snapshot when Firefox closed. Moved to `previous.jsonlz4` at next start |
| `sessionstore-backups\recovery.jsonlz4` | 11/9 11:49:30 | Autosave while running (~15 s, only when something changed). Last one before close |
| `sessionstore-backups\recovery.baklz4` | 11/9 11:49:15 | The autosave before that (15 s older). Spare if the newest is damaged |
| `sessionstore-backups\previous.jsonlz4` | 11/9 11:25 | Close snapshot from the run before |
| `sessionstore-backups\upgrade.jsonlz4-20261022150525` | 11/9 09:59 | Copy made the first time a new Firefox version ran on this profile. Number = that Firefox's build date/time (2026-10-22 15:05:25). Tiny, profile was new |
| `sessionCheckpoints.json` (root) | 11/9 13:29 | **Not a snapshot.** Firefox's note of how far start-up/shutdown got (crash detection). No browsing data |

**Correction:** Claude earlier said `recovery.jsonlz4` only exists while running. **Wrong.** Firefox
deletes `recovery.jsonlz4` + `recovery.baklz4` at close **only if "Open previous windows and tabs"
is off**. Ben turned it on in the test profile, so they stay. Source:
[SessionWriter.sys.mjs](https://searchfox.org/mozilla-central/source/browser/components/sessionstore/SessionWriter.sys.mjs),
`if (options.performShutdownCleanup && !exn)` with comment *"During shutdown, if auto-restore is
disabled, we need to remove possibly sensitive data that has been stored purely for crash
recovery"*, then `IOUtils.remove(recoveryBackup)` / `IOUtils.remove(recovery)`. (The path comments in
`SessionFile.sys.mjs` just say "removed during clean shutdown", which is the auto-restore-off case.)

**Most important file = the newest snapshot**: root `sessionstore.jsonlz4` after a clean close,
`recovery.jsonlz4` if running or crashed. Older files matter because they can hold items the newest
lost. The upgrade file can be months old on a real machine, so it can show old tabs/storage.

### Do all files hold the same information? (same layout, different moment)

Every file is a **complete snapshot, same layout**, so Session Storage (and tabs etc.) can be read
from any of them the same way. Contents differ by when each was taken. Counts by
`D:\code\tools\ff-sessionstore-dump\ar2_inventory.py <folder>` (counts tabs, pages, closed tabs/windows,
storage items, form data, typed URL, cookies, `lastSessionState` per file; counts include
`lastSessionState`):

| Capture 2 (just closed) | Tabs | Storage items |
|---|---|---|
| `sessionstore.jsonlz4` | 8 | 31 |
| `recovery.jsonlz4` | 8 (+1 previous run in `lastSessionState`) | 31 (+1) |
| `recovery.baklz4` | 8 (+1) | 24 (+1) |
| `previous.jsonlz4` | 1 | 1 (09:59 new-tab page) |
| `upgrade.jsonlz4-…` | 1 | 1 (same 09:59 moment) |

Live profile now (after the restarts): root, `recovery`, `recovery.baklz4`, `previous` all **8 tabs /
23 items, identical**. Upgrade 1/1. The 8 fewer (31 → 23) are the `example.com` + new-tab widget
items lost over the restarts (finding 9).

**The 88 CCL rows (finding 8) = duplicates across files**, not within one: 31 + 31 + 24 + 1 + 1 = 88
(CCL skips `lastSessionState`). Within one file the same key can appear in two tabs (both 8001 tabs
have `p8001_short_text`, different `written_at` 15:12:36 vs 15:12:48). That's **not** a duplicate:
separate tabs, separate copies. Exception: `lastSessionState` inside `recovery` can repeat
`previous.jsonlz4`.

### What Axiom does today, in the code

- Artifact [FirefoxSessionStore.cs:31-43](../Magnet.Artifacts/Firefox/FirefoxSessionStore.cs): 3
  columns (Title, URL, Referrer URL), two hunters (parsed + carved).
- Parsed hunter `FirefoxSessionStoreParsedHunter.cs`:
  - `:33-35` which files: exact names `sessionstore.js`, `sessionstore.bak` + anything in
    `sessionstore-backups\`. Misses root `sessionstore.jsonlz4` and (likely) `sessionstore.bak-<date>`.
  - `:69-97` unpacks only if the name ends in `lz4` (`:71`), else reads as text (`:48`) → upgrade
    files reach the JSON reader still compressed.
  - `:50-66` skips `about:` pages, one row per item. Row location = JSON path (`:65`), e.g.
    `windows[0]._closedTabs[0].state.entries[2]`: the **only** clue to open/closed/previous.
- JSON reader `SessionStoreParser.cs`:
  - `:72-110` doesn't follow the structure. Digs the whole JSON for any object with `url` + `title`.
    `storage` (`{website:{name:value}}`), `formdata`, `cookies`, `lastAccessed`, `closedAt` never
    match → never output. **This is where Session Storage is skipped.**
  - `:44-51` reads `url`, `title`, key ending in `referrer` (modern = `referrerInfo` → blank).
  - Every page in every file = a row, so repeats across files.
- Carved hunter `FirefoxSessionStoreCarvedHunter.cs:30-34, 47-124`: searches raw bytes (incl. deleted
  space) for `{"url":"http`, grabs URL + title/referrer next to it. Modern files are compressed, so
  probably only finds old uncompressed copies (inferred, not tested).

### AR2 per profile (full inventory, 2026-11-11)

| AR2 profile | Files | Inside |
|---|---|---|
| Jack, FF 22 | root `.js`/`.bak` + 10 copies in `Local\Temp\tmp…\` | 2 tabs, 15 pages, 4 cookies, previous session |
| Jack, FF 34 | backups folder (`.js`) + root `.bak` | 2 tabs, 5 pages, 1 cookie, previous session |
| firefox.zip, FF 29 | root `.js`/`.bak`/`.bak-20140421…`, `previous.js`, `upgrade.js-20151216…` | 10 closed tabs, 12 Session Storage items, 2 cookies |
| firefox.zip, FF 32 | root `.js`/`.bak` | 10 open tabs, 1 closed, 10 Session Storage items |
| firefox.zip, FF 68 | old `.js` leftovers + `.jsonlz4` | 4 closed tabs, 15 cookies, 1 half-typed address, previous session |
| firefox.zip, Mac | root `.js`/`.bak` | 1 closed window (the only one in AR2) |
| `FirefoxSessionStore\sessionstore.js` | loose file | 2 tabs, 2 closed, 3 cookies |

AR2 has **no** form data, nothing newer than FF 68, no root `sessionstore.jsonlz4`, no encrypted
files. Caution: AR2 Firefox versions come from **folder names**, which aren't reliable. The "29.0"
profile has `upgrade.js-20151216…` (a Dec 2015 Firefox ran on it later). The `upgrade` file's build
date is better proof of which Firefox wrote a profile.

### Proof for the version history (for presenting)

| Claim | Proof | Checked by Claude |
|---|---|---|
| 5 file names + purpose | [SessionFile.sys.mjs](https://searchfox.org/mozilla-central/source/browser/components/sessionstore/SessionFile.sys.mjs) `Paths`: `clean` "written during a clean shutdown. After startup, it is renamed `cleanBackup`" (= `previous.jsonlz4`); load order clean → recovery → recoveryBackup → cleanBackup → upgradeBackup | ✔ 2026-11-11 |
| Backups folder from **Firefox 33** | [Bug 883609](https://bugzilla.mozilla.org/show_bug.cgi?id=883609) "Make backups useful", milestone Firefox 33. Before: `sessionstore.js` / `.bak` / `.bak-$buildid` in root | ✔ 2026-11-11 |
| `.jsonlz4` from **Firefox 56** | [Bug 934967](https://bugzilla.mozilla.org/show_bug.cgi?id=934967) "Read/write data with lz4", fixed Firefox 56; reviewer asked for ".jsonlz4"; old `.js` still read as fallback; Mozilla's "own wrapper" so plain lz4 tools may not open it | ✔ 2026-11-11 |
| recovery kept unless auto-restore off | SessionWriter.sys.mjs (above) | ✔ 2026-11-11 |
| 2048 limit counts characters, 3 upgrade copies, Firefox 160 encryption | see Mozilla source findings (★) | ✔ 2026-11-09 |
| Limit history (FF45 10M → FF55 2048), cookies moved FF55 | Bugs 1216250, 1362058, 912717 | ✘ research agent only. Check before presenting |

AR2 agrees: old profiles have only root `.js`/`.bak`, FF 34 has the backups folder with `.js`, FF 68
has `.jsonlz4`.

### How to find the key value pairs (Ben's main need)

- **Live:** open the site → F12 → **Storage** → **Session Storage** → the website.
- **On disk:** decode (command in Debrief point 4), open the JSON in VS Code, `Ctrl+F` `"storage"`.
  Example `decoded-claude\2-closed\sessionstore.jsonlz4.json`: line 1116 page URL, 1117 title
  `SS test 8001`, 1131 `lastAccessed`, **1136 `"storage"`**, 1140 website `http://localhost:8001`,
  1143 `p8001_short_text = "hello from port 8001"`. Skip line 1137 (Firefox's new-tab widget).
- Decode the live profile: output to e.g. `D:/code/ff-sessionstorage-test/decoded-now`.

### What to parse: all files, remove duplicates (recommended)

| Option | Result | Problem |
|---|---|---|
| Only the newest file | Clean | Misses items only in older files (e.g. `https_test` only in `recovery.baklz4`) |
| All files, one row per item per file | Nothing missed | Noisy: 88 rows for ~31 real items |
| **All files, remove duplicates** | Nothing missed, one row per item | Needs a "same item" rule |

Matches `.ai/shared-rules/development-rules.md` rule 12 (dedupe in the hunter, don't discard hits).
To decide with Vedant: what counts as the same item (probably website + key + value + same tab; two
tabs with the same key are **not** duplicates), and how to keep the source file(s). Lead: Chrome
Session Storage marks every column `.Dedupe()` (`Magnet.Artifacts/Chrome/SessionStorage.cs:24-29`).
Not yet checked how that decides "identical" or handles the source file.

### What a Firefox Session Storage row could hold

| Column | Example (8001 tab) | From |
|---|---|---|
| Website | `http://localhost:8001` | storage |
| Key | `p8001_short_text` | storage |
| Value | `hello from port 8001` | storage |
| Tab page URL + title | `http://localhost:8001/make_test_sessionstorage.html`, `SS test 8001` | the tab |
| Tab last used | 2026-11-09 15:12:38 UTC (`lastAccessed` 1794237158602) | the tab |
| Open / closed tab (+ closed time) | open | position in file / `closedAt` |
| Current / previous session | current | file / `lastSessionState` |
| Source file | `sessionstore.jsonlz4` | file |

- **Tab last used** = `lastAccessed`, roughly the last time the user switched to / looked at the tab.
  Not when the page loaded or when an item was written. All items in a tab share it. Name the column
  "Tab Last Accessed", not "Created".
- **No write time per item** in Firefox. **Chrome doesn't have one either**: our Chrome Session
  Storage has Key, Value, Origin, Session ID, State, Sequence Number, no time
  (`Chrome/SessionStorage.cs:24-29`). Sequence Number = write **order** (bigger = later), not a date.
- Also not available: old values, deleted items.

### Other artifacts (not Session Storage)

Open tabs, closed tabs/windows, previous session, typed form text, half-typed address bar text and
session cookies are **not Session Storage**. They're other information in the same files, for
**separate follow-up artifacts** (Vedant's add-on). Same tab structure, so build one proper reader
first, then each artifact is a small piece on top.

---

## CARS-2252 side work done in this same chat (2026-11-10/11)

Not CARS-1861, but it happened here, so it's logged here too. (Could also go in
`Firefox-Local-Storage-MASTER.md`.)

- **FileFormats bump:** `Directory.Packages.props:49` `Magnet.FileFormats` `7.8.2-PullRequest108255.11`
  → **`8.0.0`** (after the CARS-2225 FileFormats PR merged). Only that file. `packages.lock.json`
  files are gitignored. 8.0.0 is a major version, so outside breaking changes are possible.
  Commit: `Update Magnet.FileFormats to 8.0.0`.
- **PR title:** `Add Firefox Local Storage artifact (new and old formats)`. Ben already had the
  description.
- **"Azure Artifacts Native Build Validation" not clickable:** because of 2 merge conflicts. The
  build runs on a test merge into `fury`, so it waits until conflicts are gone. Fix = merge
  `origin/fury` into the branch.
- **Merge conflicts resolved:**
  - `Directory.Packages.props`: `fury` had FileFormats `7.9.0`, kept **`8.0.0`**.
  - `LogEvents.ParsingData.cs`: both sides added an event with **EventId 2047**. Kept `fury`'s
    `FieldValueInvalid` at **2047**, moved Ben's `ValuesNotConverted` to **2048** (free, no docs list
    event IDs, only caller uses the name). Commit: `Merge fury into CARS-2252`.
- **Pipeline build error** `FirefoxLocalStorageWebappsStoreHunter.cs(115,123) CS1503: cannot convert
  IFragmentName to string`. Not caused by the merge: it came in with commit `b4e570c56b` ("log once
  per database…"), first build since. `FragmentNames.Origin` is typed `IFragmentName` (interface),
  and the `implicit operator string` only exists on the `FragmentName` class. Fix: pass
  `FragmentNames.Origin.FriendlyValue`. Commit: `Fix build error in log call`.
- **Remote AR2 scenario:** `Computer:Firefox;macOS:Firefox` (`Computer:Firefox` verified from the
  local run. `macOS:Firefox` assumed from the S3 folder name). Note: Firefox Logins `<Encrypted
  Data>` rows on master-password data need the options file, not our change.
- **Remote AR2 result:** same as the local run shown at the debrief. Dispatch:
  https://artifactregression.magnetapps.net/?diffSource=Remote&dispatch=1975433%20-%20BP%20-%20CARS-2252%20-%201
- **Message to Nina:** "Hey Nina, I ran the AR2 test after merging the FileFormats PR, and the results
  match the local run I showed at the debrief. Here's the link for reference: <link>. Am I good to
  merge?"
- Also open on the PR at the time: "Comments must be resolved" (5/7 resolved). Blocks completing,
  not the build.
