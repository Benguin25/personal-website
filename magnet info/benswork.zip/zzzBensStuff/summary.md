# Work Term Summary: Magnet Forensics (Artifacts team)

Sep to Nov 2026. Repos: `lib-magnet-artifacts` (the artifacts library behind Magnet Axiom) and
`pkg-magnet-fileformats` (shared file-format parsers).

Each piece of work is listed in order with what the ticket asked, what I did, how I tested it, and what came out of it.

---

## Big picture

- **What the team does:** builds "artifacts" for Magnet Axiom, a digital forensics tool. An artifact is one kind of
  evidence (cookies, logins, scheduled tasks, browser storage…) pulled from a device image and shown to an examiner
  as a table.
- **My work fell into 3 areas:**
  1. **Generic Chromium browsers** (Brave, Vivaldi, Avast, DuckDuckGo…): new artifacts, shared base code, and
     decryption fixes
  2. **Windows date/time accuracy**: making sure timestamps are labelled correctly as UTC or local
  3. **Firefox browser storage**: research, then new artifacts for Local Storage and Session Storage, split across
     the FileFormats package and the artifacts library
- **How work was done:** Jira tickets, branches off `fury`, Azure DevOps PRs reviewed by teammates, Artifact
  Regression (AR/AR2, which reruns every artifact on curated evidence and compares against a baseline), unit tests,
  blackbox tests, and debriefs (dev + testing) presented to the team.

| # | Ticket | Title | Area | Outcome |
|---|---|---|---|---|
| 1 | CARS-1544 | Chromium Based Browsers Shortcuts | Chromium | Merged (PR !103516) |
| 2 | CARS-1531 | Chromium Based Browsers Cookies + decryption | Chromium | Merged (PR !104659) |
| 3 | CARS-2176 | Chromium decryption safety net + Chrome cookie fix | Chromium | Merged (PR !105250) |
| 4 | CARS-2082 | Scheduled Tasks: fix Local/UTC created time | Date/time | Worked on with Veronica, on her PR (!99280) |
| 5 | CARS-2194 | Scheduled Tasks: Registered + Last Run UTC from the registry | Date/time | Merged (PR !106835) |
| 6 | CARS-1946 | UserAssist: remove wrong `LastRunLocalTime` | Date/time | Merged (PR !107399) |
| 7 | CARS-1860 | Research: Firefox Local Storage | Firefox | Research done, debriefed |
| 8 | CARS-2225 | FileFormats parser for Firefox Local Storage | Firefox | Merged (FileFormats PR !108255) |
| 9 | CARS-2252 | Firefox Local Storage artifact (new + old formats) | Firefox | Merged (PR !109076) |
| 10 | CARS-1861 | Research: Firefox Session Storage | Firefox | Research done, debriefed |
| 11 | CARS-2285 | FileFormats parsers for Firefox session files | Firefox | Approved (PR !111540), merging with CARS-2272 |
| 12 | CARS-2272 | Firefox Session Storage artifact + Session Store fixes | Firefox | In progress (PR !110739) |
| — | CARS-1934 | ICS Calendar: local times labelled as UTC | Date/time | Up next, not started |

---

## 1. Chromium browsers

Chrome, Edge and Opera already had their own artifacts. Lots of other browsers are built on the same Chromium code
(Brave, Vivaldi, Avast, DuckDuckGo) and store data the same way, but Axiom didn't support them. The goal of this epic
("Generic Chromium Round 2") was one reusable artifact per data type that covers all of them.

### CARS-1544: Chromium Based Browsers Shortcuts (Sep 2026)

- **Ask:** a generic Shortcuts artifact (what the user typed in the address bar → the page they picked), matching
  Chrome's, plus a field for which browser it came from, plus a reusable base hunter so future browser-specific
  work is faster.
- **What I did:**
  - New artifact `Chromium Based Browsers Shortcuts` (Windows + macOS) with a `Browser Name` field worked out from the
    file path
  - Moved the shared SQL query into `ShortcutBaseHunter`, and changed the existing browser-specific shortcut hunters to
    use it
  - Skipped browsers that already have their own artifact, so hits aren't duplicated
  - Registered the artifact, added strings, and documented the columns in the art-json files for customers
- **Testing:** AR showed **44 new hits** (new artifact, so all additive). Checked a Vivaldi row by hand against the
  database.

### CARS-1531: Chromium Based Browsers Cookies + decryption (Sep to Oct 2026)

- **Ask:** a generic Cookies artifact with a shared reader, then get decryption working and investigate the `v10`,
  `v20` and `v30` encryption versions.
- **What I did:**
  - New artifact `Chromium Based Browsers Cookies` plus `CookiesBaseHunter`, following the Shortcuts pattern
  - Added Windows decryption. Learned how Chromium encrypts values: a master key in `Local State`, locked by Windows
    DPAPI (`v10` = locked to the user; `v20` "App-Bound" = locked by the computer and then the user; `v30` not
    supported, logs a warning)
  - **Bug fix 1, `v20` for non-Chrome browsers:** our code assumed every browser wraps its key like Chrome (61 bytes,
    an extra Chrome-only layer). Other browsers store a plain 32-byte key, so decryption silently failed and showed
    `<Encrypted Data>`. Fix: if the key is exactly 32 bytes, use it as-is. This also fixed Brave **passwords** in
    Logins, which use the same code
  - **Bug fix 2, junk at the start of cookies:** from cookie database version 24, Chromium puts a 32-byte hash of the
    website in front of the value. Read the version from the `meta` table and cut it off
  - Limited cookie decryption to Windows evidence (reviewer request)
  - Co-wrote `ChromiumEncryption.md` with my manager (version table, key layouts, where it lives in our code)
- **Testing:** full AR2: **+393 cookie hits** across Test Browser, Avast, Vivaldi, Brave and DuckDuckGo; 3 Brave
  passwords that used to show `<Encrypted Data>` now decrypt; Google Analytics cookie artifacts +11 each (built from
  cookies); nothing else changed. Also made my own Brave test evidence to test what happens when registry files are
  missing.
- **Found along the way:** with no SYSTEM/SECURITY registry files, `v20` decryption crashes the whole Logins hunter.
  This bug was already on `fury`, so it went into its own ticket (CARS-2176).

### CARS-2176: Chromium decryption safety net + Chrome cookie hash fix (Oct 2026)

- **Ask:** when the registry files are missing, 14 Chromium hunters (Logins, Credit Cards, Autofill, Signal Desktop)
  crash and return **nothing**. Make them keep going and show `<Encrypted Data>` for values they can't unlock. Also
  apply the 32-byte hash fix to Chrome's own cookie hunter.
- **What I did:**
  - Catch decryption errors in the shared `DecryptChromiumBlob`, so one bad value doesn't kill the whole hunter
  - Added null checks in `DPAPIDecryptor.FindMasterKey` (manager request)
  - Passed the cookie database version to Chrome's cookie decrypter and stripped the hash for version 24+
  - Built a **synthetic test evidence zip** for the missing-registry case and uploaded it to the AR2 data set, so the
    pipeline tests this case from now on
- **Testing:** missing-registry evidence went from 0 Logins to 3 (shown as `<Encrypted Data>`). Normal Chromium run:
  9,616 = 9,616 hits, no change. Chrome: 152 cookies changed, each one just losing the 32 junk bytes.

---

## 2. Windows date/time accuracy

Part of the "Artifacts DateTime Bugs" epic. In forensics, a time shown as UTC when it's really local (or the other way
round) puts events at the wrong point on the timeline.

### CARS-2082: Scheduled Tasks created time (Oct 2026)

- **Ask:** the Scheduled Tasks table only had a "Created - Local" column, saved as text. Make it UTC where possible,
  saved as a real date, and make sure each label is correct.
- **What I did** (on a coworker's branch, alongside her changes):
  - Worked out which clock each source uses:
    - `.job` files → the file system's created time → always UTC
    - XML `<Date>` with an offset (e.g. `-08:00`) → convertible to UTC
    - XML `<Date>` with no offset → **local**. Proved it by making a test task on my own laptop and exporting it
  - Kept **both** columns (UTC and Local, both real dates), each task fills the right one
  - Split the XML date formats into "with offset" and "without offset" lists. Fixed a missing format
    (`2014-11-05T00:00:00` with no fractions wasn't being read)
  - Fixed false date warnings that AR2 showed in the logs
  - Added the table to the Super Timeline, updated art-json descriptions, and fixed a blackbox test allow list
    (schema change → new version ID)
  - Wrote unit tests (offset, offset + fractions, no offset, no fractions, invalid)
  - Drafted the follow-up registry ticket (became CARS-2194)
- **Testing:** local AR: 430 hits = baseline, 134 changed as expected (12 `.job` → UTC, 40 offset XML → UTC,
  82 no-offset XML → Local), 0 log errors.

### CARS-2194: Scheduled Tasks registry times (Oct 2026)

- **Ask (discovery):** what can we get from the SOFTWARE registry file to fill the gap from CARS-2082 (tasks with
  only a local created time)?
- **Research:**
  - Each task has a binary value `DynamicInfo` under `TaskCache\Tasks\{GUID}`. No official Microsoft docs, so I
    compared 3 community sources (Zimmerman, G DATA, libyal) and tested them against tasks I made and ran myself,
    decoding the bytes by hand
  - Found G DATA's label for bytes 28-35 ("last successful run") is wrong: it changed after a failed run, so it's the
    last run's end time
  - Found the "created" time in the registry is really the time the task was **registered on that PC**. Built-in
    Windows tasks showed `<Date>` 2006 but registry dates of 2009 / 2012 / 2015 depending on the Windows version.
    Took this to the team. Other tools (Zimmerman, Plaso, RegRipper, Velociraptor) also keep the two separate
- **Decision:** add a new **Registered Date/Time - UTC** column instead of overwriting Created
- **What I did:**
  - New columns: Registered (UTC) and Last Run (UTC), with the registry key as their location
  - Read the SOFTWARE file (+ its transaction logs) once per evidence and cached it with `MultiArtifactStateService`
  - Helpers to read a FILETIME at a byte offset and to map a task file path to its SOFTWARE path
  - Left out Last Run Result on purpose: its position moves between Windows versions, so reading the wrong spot would
    show "success" for failed tasks
  - Wrote `ScheduledTasks.md` (format notes, sources, decisions) and unit tests using real bytes from my test task
  - Handled review comments from 3 reviewers (record instead of tuple, own file, merged two helpers)
- **Testing:** local AR: 430 hits = baseline, 393 changed, 0 warnings. Registered times on Windows 10 / 8.1 / 7 /
  Vista. Checked the 25 tasks with no registry entry in RegEdit: they really aren't there. Also confirmed `.job` Last
  Run is local (CARS-2082 could only suspect it).
- **Debugging win:** local AR broke after merging `fury`. Tracked it to an old `Magnet.FileFormats` DLL in the AR
  tool through the exception's `LoaderExceptions`.

### CARS-1946: UserAssist `LastRunLocalTime` (Oct 2026)

- **Ask:** `LastRunLocalTime` used `DateTime.FromFileTime`, which converts to the **examiner's** time zone, not the
  evidence computer's. Fix it or delete it.
- **What I found:** UserAssist only stores one UTC FILETIME. The local value wasn't part of the format, was never shown
  to examiners, and nothing read it.
- **What I did:** deleted it. Expected no change in AR.

---

## 3. Firefox browser storage

Websites can save small `name = value` items in the browser. Chrome support existed, but Firefox stores these
completely differently and Axiom didn't read them. Each feature followed the same 3 steps: **research ticket →
FileFormats parser → library artifact.**

### CARS-1860: Research, Firefox Local Storage (Oct 2026)

- Mapped both storage formats:
  - **New** (current Firefox): one folder per website with `ls\data.sqlite` + a binary `.metadata-v2` file (the real
    website address + a last-used time)
  - **Old** (Firefox 22 to 68): one shared `webappsstore.sqlite`, website stored backwards
    (`moc.rettiwt.:https:443` = `https://twitter.com`)
- Tested on my own Firefox and the AR2 evidence (Firefox 22 to 152). Read Firefox's source code to confirm there are
  only 2 text types (UTF-8, raw UTF-16) and 2 compression types (none, Snappy)
- Checked CCL Group's open-source reader: it matches current Firefox, but reads one rare case wrong and doesn't support
  the old format
- Limits: no per-item timestamp; deleted items are really deleted (in the new format)

### CARS-2225: FileFormats parser, Firefox Local Storage (Oct to Nov 2026)

- Built the parser in `pkg-magnet-fileformats`: reads `data.sqlite` (UTF-8/UTF-16, Snappy decompression) and the
  binary `.metadata-v2`, returns entries + metadata
- Wrote the format README, unit tests and test data. Two rounds of PR review
- Looked into what the `.metadata-v2` "last accessed" time really means: the last time Firefox opened or released the
  site's storage (for the whole site), not user activity

### CARS-2252: Firefox Local Storage artifact (Nov 2026)

- **What I did:** one artifact (Key, Value, Origin, Last Accessed), two hunters:
  - New format: calls the FileFormats parser
  - Old format: a `SqliteIntelligentHunter` that handles both table layouts (`scope` / `originKey`), plus a helper to
    flip the backwards website name and drop default ports
- **Testing:** AR2 `Computer:Firefox`: **+266 new hits, 0 missing, nothing else changed**. The 120 new-format hits match
  both the FileFormats runner and CCL's tool. Checked the empty values by opening the database.
- **Finding:** the old format can **recover deleted items** (the SQLite hunter recovers old copies from free space),
  which the research had only ruled out for the new format.

### CARS-1861: Research, Firefox Session Storage (Nov 2026)

- **Ask:** does Axiom pull Session Storage from Firefox correctly? Later widened to "what else is in the same file?"
- **Method:** built a test website on 2 local ports, captured a fresh Firefox profile while running, after closing and
  after restarting, decoded the files myself, compared with CCL's reader and the AR2 data, and read Firefox's source
- **Findings:**
  - Axiom got **none** of Firefox's Session Storage, even though it already opened the files that hold it
  - Behaviour: one set of items per tab, closed tabs keep theirs for up to 14 days, a site over 2048 characters gets
    nothing saved, private windows are never saved, Firefox 160 can encrypt the file
  - The session files also hold open/closed tabs with times, the previous session, **unsubmitted form text**, and
    session cookies, which could become future artifacts
  - The existing Firefox "SessionStore" artifact had **3 bugs**: skipped the main `sessionstore.jsonlz4`, couldn't open
    `upgrade.jsonlz4-…` backups, and a referrer that is always blank on modern Firefox
  - AR2 only had 22 Session Storage items, all from 2014, so we need new test data

### CARS-2285: FileFormats parsers for Firefox session files (Nov 2026)

- Built a session file reader in FileFormats (mozLz4-compressed, plain JSON, and skipping encrypted files) and a
  Session Storage parser (key, value, origin, last accessed, location)
- Moved the existing Session Store (tabs: URL + title) parser from the library into FileFormats too, so the reader
  could be internal. Copied it exactly rather than rewriting working code
- Handled review comments: built on the shared `ISessionStorageEntry` interface, inlined small helpers, returned a
  result object so tab/session info can be added later without breaking the interface. Kept Newtonsoft JSON (switching
  to System.Text.Json would have changed every location string; agreed with reviewers as a follow-up)

### CARS-2272: Firefox Session Storage artifact (Nov 2026, in progress)

- **What I did:**
  - New `Firefox Session Storage` artifact: Key, Value, Origin, Last Accessed, Sources
  - Shared session file registration for both Session Storage and Session Store, now including `sessionstore.jsonlz4`
  - **Merger:** the same item shows up in up to 5 session files (snapshots taken at different times). The hunter reads
    every file for a profile once and merges matching items, listing every file it came from under Sources
  - Switched both hunters to the FileFormats parsers and removed the old library code (reader, parsers, LZ4 data format)
  - Art-json descriptions, unit tests for the merger, docs
- **Testing (AR2):** Session Storage **+17** (merging works: 5 items in two files gave 5 hits, not 10). Session Store
  **+34 / −28**: new hits from the files it used to miss, and the 28 "missing" are the same hits with a title encoding
  fix (`Magnet ForensicsÂ®` → `Magnet Forensics®`). macOS: no changes, as expected.
- **Next:** merge the FileFormats PR, point the library at the released package, rerun AR2, merge the library PR.

---

## Skills and things I learned

- **C# / .NET 8** in a large production codebase: hunters, artifact schemas, dependency injection, structured logging,
  `SqliteIntelligentHunter`, the `.editorconfig` and analyzer rules
- **Forensic reasoning:** UTC vs local time, where a value really comes from, not trusting labels in community docs
  without testing them, keeping forensically important values (e.g. recovered deleted rows)
- **Reverse engineering formats:** decoding binary registry values and Firefox files by hand, reading Chromium and
  Firefox source code to confirm behaviour
- **Cryptography in practice:** Windows DPAPI, Chromium App-Bound encryption, AES-GCM key layouts
- **Testing:** unit tests (xUnit, FluentAssertions), Artifact Regression / AR2, blackbox tests, building my own test
  evidence (my own browser, my own scheduled tasks, a synthetic zip for the pipeline)
- **Working across two repos:** FileFormats package + library, prerelease packages, avoiding version mismatches
- **Teamwork:** code reviews, splitting out-of-scope bugs into their own tickets, drafting tickets, dev and testing
  debriefs, design decisions with my manager and teammates

---

## Sources

All from my notes in `zzzBensStuff/`: `CARS-1544.md`, `CARS-1531.md`, `CARS-2176.md`, `CARS-2082.md`
(+ `CARS-2082-AR-local-results.csv`), `CARS-2194.md`, `CARS-2194-research.md`, `CARS-1946.md`, `CARS-1934.md`,
`CARS-1860-research-depth.md`, `Firefox-Local-Storage-MASTER.md`, `Firefox-Session-Storage-Notes.md`, plus my merged
commits on `fury` (`git log --author=Probert`).
