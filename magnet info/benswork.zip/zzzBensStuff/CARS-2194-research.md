# CARS-2194 Research: `DynamicInfo`

`DynamicInfo` is a binary value in the SOFTWARE registry file, one per scheduled task:
`Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{GUID}\DynamicInfo`

There is no official Microsoft documentation for it.

---

## What the sources say

| Bytes | Zimmerman | G DATA | libyal |
|---|---|---|---|
| 0-3 | Version | Magic, "currently 0x3" | Unknown, value 3 |
| 4-11 | Created | Created | "last registered or update time?" |
| 12-19 | Last start | Last run | "launch time?" |
| 20-23 | Task state | Task state, "always zero" on recent Windows | "flags?" |
| 24-27 | Last action result | Last error code | Unknown |
| 28-35 | Last stop | Last *successful* run | Unknown time |

- **Zimmerman:** Eric Zimmerman, Registry Explorer TaskCache plugin. https://github.com/EricZimmerman/RegistryPlugins/blob/master/RegistryPlugin.TaskCache/TaskCache.cs
- **G DATA:** Luca Ebach, "Windows Registry Analysis – Today's Episode: Tasks" (2022). https://cyber.wtf/2022/06/01/windows-registry-analysis-todays-episode-tasks/
- **libyal:** Joachim Metz, winreg-kb. https://github.com/libyal/winreg-kb/blob/main/docs/sources/system-keys/Task-scheduler.md

The sources agree on everything except **bytes 28-35** (last stop vs last successful run). libyal also says it's 28 bytes on Vista/7 (no bytes 28-35) and 36 bytes on Win8/10.

---

## What my tests showed

Made scheduled tasks on my computer (Win11), ran them, and read `DynamicInfo` in RegEdit.

**`test-timezone`** (XML `<Date>` = `2026-10-08T14:49:22`, local Eastern)
- Bytes 4-11 = 2026-10-08 18:49:22 UTC = `<Date>` + 4h → created time, in UTC
- Bytes 24-27 = `0x800710E0` (run refused), bytes 28-35 empty

**`cars-flip`** (succeeds on run 1, fails with exit code 5 on run 2)

| Bytes | Run 1 (success) | Run 2 (exit code 5) |
|---|---|---|
| 0-3 | 3 | 3 |
| 4-11 | 16:53:36 UTC | same |
| 12-19 | 16:53:47.890 UTC | 16:59:16.834 UTC |
| 20-23 | 0 | 0 |
| 24-27 | `0x0` | `0x5` |
| 28-35 | 16:53:48.129 UTC (0.2 s after start) | 16:59:17.406 UTC (0.6 s after start) |

- Created (bytes 4-11) = registry `Date` `12:53:36` + 4h, and didn't change when the task ran
- Bytes 28-35 **changed after the failed run**, so it's not "last successful run". It's always just after the start, so it's when the run ended

---

## Conclusion

| Bytes | Represents |
|---|---|
| 0-3 | Version (always 3) |
| 4-11 | Created time (UTC) |
| 12-19 | Last run start time (UTC) |
| 20-23 | Task state (unused, always 0) |
| 24-27 | Last run result (0 = success, otherwise the exit code or a Windows error code) |
| 28-35 | Last run end time (UTC), even if the run failed. Empty if a run never finished. Not on Vista/7 (per libyal) |

Zimmerman's names are right. G DATA's "last successful run" for bytes 28-35 is wrong.

Not tested: whether created changes when a task is edited, and the Vista/7 size (can check with the AR2 zips).

---

## Worked example: `cars-flip`

I made a task called `cars-flip` on 2026-10-15 at 12:53 PM Eastern (EDT, UTC-4). Its `<Date>` is `2026-10-15T12:53:36`. That's local time with no offset, so in UTC it's **16:53:36**.

I ran it once (it succeeded), then again at about 12:59 PM Eastern, when it failed with exit code 5. After the second run, `DynamicInfo` was:

```
03 00 00 00  B8 1B C1 B8 C5 5C DD 01  69 AB 5F 83 C6 5C DD 01  00 00 00 00  05 00 00 00  BD DE B6 83 C6 5C DD 01
```

How to read it:
- **Byte order:** numbers are stored backwards (little-endian), so `05 00 00 00` is 5.
- **Times:** each time is a Windows FILETIME, which counts 100-nanosecond ticks since 1601-01-01 UTC.

| Bytes | Raw | Number | Means |
|---|---|---|---|
| 0-3 | `03 00 00 00` | 3 | Version |
| 4-11 | `B8 1B C1 B8 C5 5C DD 01` | `0x01DD5CC5B8C11BB8` | **Created: 2026-10-15 16:53:36.895 UTC** (12:53:36 PM Eastern). Matches `<Date>` + 4h |
| 12-19 | `69 AB 5F 83 C6 5C DD 01` | `0x01DD5CC6835FAB69` | **Last run start: 2026-10-15 16:59:16.834 UTC** (12:59:16 PM Eastern) |
| 20-23 | `00 00 00 00` | 0 | Task state (unused) |
| 24-27 | `05 00 00 00` | 5 | **Last run result: 5** (the exit code) |
| 28-35 | `BD DE B6 83 C6 5C DD 01` | `0x01DD5CC683B6DEBD` | **Last run end: 2026-10-15 16:59:17.406 UTC** (0.6 s after it started) |
